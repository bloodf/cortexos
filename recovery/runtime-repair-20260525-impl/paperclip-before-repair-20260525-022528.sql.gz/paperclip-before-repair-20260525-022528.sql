--
-- PostgreSQL database dump
--

\restrict p9Jm9JWAwuXowgti1nl0RQKeK4ShgdOGgqkeODLEH5DCrKrv9mxhV5nZAMXkVoZ

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-1.pgdg26.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.workspace_runtime_services DROP CONSTRAINT IF EXISTS workspace_runtime_services_started_by_run_id_heartbeat_runs_id_;
ALTER TABLE IF EXISTS ONLY public.workspace_runtime_services DROP CONSTRAINT IF EXISTS workspace_runtime_services_project_workspace_id_project_workspa;
ALTER TABLE IF EXISTS ONLY public.workspace_runtime_services DROP CONSTRAINT IF EXISTS workspace_runtime_services_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.workspace_runtime_services DROP CONSTRAINT IF EXISTS workspace_runtime_services_owner_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.workspace_runtime_services DROP CONSTRAINT IF EXISTS workspace_runtime_services_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.workspace_runtime_services DROP CONSTRAINT IF EXISTS workspace_runtime_services_execution_workspace_id_execution_wor;
ALTER TABLE IF EXISTS ONLY public.workspace_runtime_services DROP CONSTRAINT IF EXISTS workspace_runtime_services_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.workspace_operations DROP CONSTRAINT IF EXISTS workspace_operations_heartbeat_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.workspace_operations DROP CONSTRAINT IF EXISTS workspace_operations_execution_workspace_id_execution_workspace;
ALTER TABLE IF EXISTS ONLY public.workspace_operations DROP CONSTRAINT IF EXISTS workspace_operations_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_user_id_user_id_fk;
ALTER TABLE IF EXISTS ONLY public.secret_access_events DROP CONSTRAINT IF EXISTS secret_access_events_secret_id_company_secrets_id_fk;
ALTER TABLE IF EXISTS ONLY public.secret_access_events DROP CONSTRAINT IF EXISTS secret_access_events_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.secret_access_events DROP CONSTRAINT IF EXISTS secret_access_events_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.secret_access_events DROP CONSTRAINT IF EXISTS secret_access_events_heartbeat_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.secret_access_events DROP CONSTRAINT IF EXISTS secret_access_events_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.routines DROP CONSTRAINT IF EXISTS routines_updated_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.routines DROP CONSTRAINT IF EXISTS routines_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.routines DROP CONSTRAINT IF EXISTS routines_parent_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.routines DROP CONSTRAINT IF EXISTS routines_goal_id_goals_id_fk;
ALTER TABLE IF EXISTS ONLY public.routines DROP CONSTRAINT IF EXISTS routines_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.routines DROP CONSTRAINT IF EXISTS routines_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.routines DROP CONSTRAINT IF EXISTS routines_assignee_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_triggers DROP CONSTRAINT IF EXISTS routine_triggers_updated_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_triggers DROP CONSTRAINT IF EXISTS routine_triggers_secret_id_company_secrets_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_triggers DROP CONSTRAINT IF EXISTS routine_triggers_routine_id_routines_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_triggers DROP CONSTRAINT IF EXISTS routine_triggers_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_triggers DROP CONSTRAINT IF EXISTS routine_triggers_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_runs DROP CONSTRAINT IF EXISTS routine_runs_trigger_id_routine_triggers_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_runs DROP CONSTRAINT IF EXISTS routine_runs_routine_id_routines_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_runs DROP CONSTRAINT IF EXISTS routine_runs_linked_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_runs DROP CONSTRAINT IF EXISTS routine_runs_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_revisions DROP CONSTRAINT IF EXISTS routine_revisions_routine_id_routines_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_revisions DROP CONSTRAINT IF EXISTS routine_revisions_restored_from_revision_id_routine_revisions_i;
ALTER TABLE IF EXISTS ONLY public.routine_revisions DROP CONSTRAINT IF EXISTS routine_revisions_created_by_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_revisions DROP CONSTRAINT IF EXISTS routine_revisions_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.routine_revisions DROP CONSTRAINT IF EXISTS routine_revisions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_lead_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_goal_id_goals_id_fk;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.project_workspaces DROP CONSTRAINT IF EXISTS project_workspaces_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.project_workspaces DROP CONSTRAINT IF EXISTS project_workspaces_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.project_goals DROP CONSTRAINT IF EXISTS project_goals_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.project_goals DROP CONSTRAINT IF EXISTS project_goals_goal_id_goals_id_fk;
ALTER TABLE IF EXISTS ONLY public.project_goals DROP CONSTRAINT IF EXISTS project_goals_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.principal_permission_grants DROP CONSTRAINT IF EXISTS principal_permission_grants_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_webhook_deliveries DROP CONSTRAINT IF EXISTS plugin_webhook_deliveries_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_state DROP CONSTRAINT IF EXISTS plugin_state_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_migrations DROP CONSTRAINT IF EXISTS plugin_migrations_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_managed_resources DROP CONSTRAINT IF EXISTS plugin_managed_resources_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_managed_resources DROP CONSTRAINT IF EXISTS plugin_managed_resources_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_logs DROP CONSTRAINT IF EXISTS plugin_logs_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_jobs DROP CONSTRAINT IF EXISTS plugin_jobs_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_job_runs DROP CONSTRAINT IF EXISTS plugin_job_runs_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_job_runs DROP CONSTRAINT IF EXISTS plugin_job_runs_job_id_plugin_jobs_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_entities DROP CONSTRAINT IF EXISTS plugin_entities_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_database_namespaces DROP CONSTRAINT IF EXISTS plugin_database_namespaces_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_config DROP CONSTRAINT IF EXISTS plugin_config_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_company_settings DROP CONSTRAINT IF EXISTS plugin_company_settings_plugin_id_plugins_id_fk;
ALTER TABLE IF EXISTS ONLY public.plugin_company_settings DROP CONSTRAINT IF EXISTS plugin_company_settings_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.labels DROP CONSTRAINT IF EXISTS labels_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.join_requests DROP CONSTRAINT IF EXISTS join_requests_invite_id_invites_id_fk;
ALTER TABLE IF EXISTS ONLY public.join_requests DROP CONSTRAINT IF EXISTS join_requests_created_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.join_requests DROP CONSTRAINT IF EXISTS join_requests_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_project_workspace_id_project_workspaces_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_parent_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_goal_id_goals_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_execution_workspace_id_execution_workspaces_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_execution_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_checkout_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_assignee_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_work_products DROP CONSTRAINT IF EXISTS issue_work_products_runtime_service_id_workspace_runtime_servic;
ALTER TABLE IF EXISTS ONLY public.issue_work_products DROP CONSTRAINT IF EXISTS issue_work_products_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_work_products DROP CONSTRAINT IF EXISTS issue_work_products_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_work_products DROP CONSTRAINT IF EXISTS issue_work_products_execution_workspace_id_execution_workspaces;
ALTER TABLE IF EXISTS ONLY public.issue_work_products DROP CONSTRAINT IF EXISTS issue_work_products_created_by_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_work_products DROP CONSTRAINT IF EXISTS issue_work_products_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_holds DROP CONSTRAINT IF EXISTS issue_tree_holds_root_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_holds DROP CONSTRAINT IF EXISTS issue_tree_holds_released_by_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_holds DROP CONSTRAINT IF EXISTS issue_tree_holds_released_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_holds DROP CONSTRAINT IF EXISTS issue_tree_holds_created_by_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_holds DROP CONSTRAINT IF EXISTS issue_tree_holds_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_holds DROP CONSTRAINT IF EXISTS issue_tree_holds_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_hold_members DROP CONSTRAINT IF EXISTS issue_tree_hold_members_parent_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_hold_members DROP CONSTRAINT IF EXISTS issue_tree_hold_members_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_hold_members DROP CONSTRAINT IF EXISTS issue_tree_hold_members_hold_id_issue_tree_holds_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_hold_members DROP CONSTRAINT IF EXISTS issue_tree_hold_members_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_hold_members DROP CONSTRAINT IF EXISTS issue_tree_hold_members_assignee_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_tree_hold_members DROP CONSTRAINT IF EXISTS issue_tree_hold_members_active_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_thread_interactions DROP CONSTRAINT IF EXISTS issue_thread_interactions_source_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_thread_interactions DROP CONSTRAINT IF EXISTS issue_thread_interactions_source_comment_id_issue_comments_id_f;
ALTER TABLE IF EXISTS ONLY public.issue_thread_interactions DROP CONSTRAINT IF EXISTS issue_thread_interactions_resolved_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_thread_interactions DROP CONSTRAINT IF EXISTS issue_thread_interactions_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_thread_interactions DROP CONSTRAINT IF EXISTS issue_thread_interactions_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_thread_interactions DROP CONSTRAINT IF EXISTS issue_thread_interactions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_relations DROP CONSTRAINT IF EXISTS issue_relations_related_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_relations DROP CONSTRAINT IF EXISTS issue_relations_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_relations DROP CONSTRAINT IF EXISTS issue_relations_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_relations DROP CONSTRAINT IF EXISTS issue_relations_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_reference_mentions DROP CONSTRAINT IF EXISTS issue_reference_mentions_target_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_reference_mentions DROP CONSTRAINT IF EXISTS issue_reference_mentions_source_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_reference_mentions DROP CONSTRAINT IF EXISTS issue_reference_mentions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_recovery_actions DROP CONSTRAINT IF EXISTS issue_recovery_actions_source_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_recovery_actions DROP CONSTRAINT IF EXISTS issue_recovery_actions_return_owner_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_recovery_actions DROP CONSTRAINT IF EXISTS issue_recovery_actions_recovery_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_recovery_actions DROP CONSTRAINT IF EXISTS issue_recovery_actions_previous_owner_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_recovery_actions DROP CONSTRAINT IF EXISTS issue_recovery_actions_owner_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_recovery_actions DROP CONSTRAINT IF EXISTS issue_recovery_actions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_read_states DROP CONSTRAINT IF EXISTS issue_read_states_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_read_states DROP CONSTRAINT IF EXISTS issue_read_states_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_labels DROP CONSTRAINT IF EXISTS issue_labels_label_id_labels_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_labels DROP CONSTRAINT IF EXISTS issue_labels_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_labels DROP CONSTRAINT IF EXISTS issue_labels_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_inbox_archives DROP CONSTRAINT IF EXISTS issue_inbox_archives_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_inbox_archives DROP CONSTRAINT IF EXISTS issue_inbox_archives_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_execution_decisions DROP CONSTRAINT IF EXISTS issue_execution_decisions_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_execution_decisions DROP CONSTRAINT IF EXISTS issue_execution_decisions_created_by_run_id_heartbeat_runs_id_f;
ALTER TABLE IF EXISTS ONLY public.issue_execution_decisions DROP CONSTRAINT IF EXISTS issue_execution_decisions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_execution_decisions DROP CONSTRAINT IF EXISTS issue_execution_decisions_actor_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_documents DROP CONSTRAINT IF EXISTS issue_documents_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_documents DROP CONSTRAINT IF EXISTS issue_documents_document_id_documents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_documents DROP CONSTRAINT IF EXISTS issue_documents_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_comments DROP CONSTRAINT IF EXISTS issue_comments_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_comments DROP CONSTRAINT IF EXISTS issue_comments_created_by_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_comments DROP CONSTRAINT IF EXISTS issue_comments_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_comments DROP CONSTRAINT IF EXISTS issue_comments_author_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_attachments DROP CONSTRAINT IF EXISTS issue_attachments_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_attachments DROP CONSTRAINT IF EXISTS issue_attachments_issue_comment_id_issue_comments_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_attachments DROP CONSTRAINT IF EXISTS issue_attachments_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_attachments DROP CONSTRAINT IF EXISTS issue_attachments_asset_id_assets_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_approvals DROP CONSTRAINT IF EXISTS issue_approvals_linked_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_approvals DROP CONSTRAINT IF EXISTS issue_approvals_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_approvals DROP CONSTRAINT IF EXISTS issue_approvals_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.issue_approvals DROP CONSTRAINT IF EXISTS issue_approvals_approval_id_approvals_id_fk;
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS invites_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.inbox_dismissals DROP CONSTRAINT IF EXISTS inbox_dismissals_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_runs DROP CONSTRAINT IF EXISTS heartbeat_runs_wakeup_request_id_agent_wakeup_requests_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_runs DROP CONSTRAINT IF EXISTS heartbeat_runs_retry_of_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_runs DROP CONSTRAINT IF EXISTS heartbeat_runs_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_runs DROP CONSTRAINT IF EXISTS heartbeat_runs_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_watchdog_decisions DROP CONSTRAINT IF EXISTS heartbeat_run_watchdog_decisions_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_watchdog_decisions DROP CONSTRAINT IF EXISTS heartbeat_run_watchdog_decisions_evaluation_issue_id_issues_id_;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_watchdog_decisions DROP CONSTRAINT IF EXISTS heartbeat_run_watchdog_decisions_created_by_run_id_heartbeat_ru;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_watchdog_decisions DROP CONSTRAINT IF EXISTS heartbeat_run_watchdog_decisions_created_by_agent_id_agents_id_;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_watchdog_decisions DROP CONSTRAINT IF EXISTS heartbeat_run_watchdog_decisions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_events DROP CONSTRAINT IF EXISTS heartbeat_run_events_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_events DROP CONSTRAINT IF EXISTS heartbeat_run_events_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_events DROP CONSTRAINT IF EXISTS heartbeat_run_events_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.goals DROP CONSTRAINT IF EXISTS goals_parent_id_goals_id_fk;
ALTER TABLE IF EXISTS ONLY public.goals DROP CONSTRAINT IF EXISTS goals_owner_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.goals DROP CONSTRAINT IF EXISTS goals_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.finance_events DROP CONSTRAINT IF EXISTS finance_events_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.finance_events DROP CONSTRAINT IF EXISTS finance_events_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.finance_events DROP CONSTRAINT IF EXISTS finance_events_heartbeat_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.finance_events DROP CONSTRAINT IF EXISTS finance_events_goal_id_goals_id_fk;
ALTER TABLE IF EXISTS ONLY public.finance_events DROP CONSTRAINT IF EXISTS finance_events_cost_event_id_cost_events_id_fk;
ALTER TABLE IF EXISTS ONLY public.finance_events DROP CONSTRAINT IF EXISTS finance_events_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.finance_events DROP CONSTRAINT IF EXISTS finance_events_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.feedback_votes DROP CONSTRAINT IF EXISTS feedback_votes_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.feedback_votes DROP CONSTRAINT IF EXISTS feedback_votes_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.feedback_exports DROP CONSTRAINT IF EXISTS feedback_exports_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.feedback_exports DROP CONSTRAINT IF EXISTS feedback_exports_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.feedback_exports DROP CONSTRAINT IF EXISTS feedback_exports_feedback_vote_id_feedback_votes_id_fk;
ALTER TABLE IF EXISTS ONLY public.feedback_exports DROP CONSTRAINT IF EXISTS feedback_exports_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.execution_workspaces DROP CONSTRAINT IF EXISTS execution_workspaces_source_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.execution_workspaces DROP CONSTRAINT IF EXISTS execution_workspaces_project_workspace_id_project_workspaces_id;
ALTER TABLE IF EXISTS ONLY public.execution_workspaces DROP CONSTRAINT IF EXISTS execution_workspaces_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.execution_workspaces DROP CONSTRAINT IF EXISTS execution_workspaces_derived_from_execution_workspace_id_execut;
ALTER TABLE IF EXISTS ONLY public.execution_workspaces DROP CONSTRAINT IF EXISTS execution_workspaces_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.environments DROP CONSTRAINT IF EXISTS environments_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.environment_leases DROP CONSTRAINT IF EXISTS environment_leases_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.environment_leases DROP CONSTRAINT IF EXISTS environment_leases_heartbeat_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.environment_leases DROP CONSTRAINT IF EXISTS environment_leases_execution_workspace_id_execution_workspaces_;
ALTER TABLE IF EXISTS ONLY public.environment_leases DROP CONSTRAINT IF EXISTS environment_leases_environment_id_environments_id_fk;
ALTER TABLE IF EXISTS ONLY public.environment_leases DROP CONSTRAINT IF EXISTS environment_leases_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_updated_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_locked_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.document_revisions DROP CONSTRAINT IF EXISTS document_revisions_document_id_documents_id_fk;
ALTER TABLE IF EXISTS ONLY public.document_revisions DROP CONSTRAINT IF EXISTS document_revisions_created_by_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.document_revisions DROP CONSTRAINT IF EXISTS document_revisions_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.document_revisions DROP CONSTRAINT IF EXISTS document_revisions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.cost_events DROP CONSTRAINT IF EXISTS cost_events_project_id_projects_id_fk;
ALTER TABLE IF EXISTS ONLY public.cost_events DROP CONSTRAINT IF EXISTS cost_events_issue_id_issues_id_fk;
ALTER TABLE IF EXISTS ONLY public.cost_events DROP CONSTRAINT IF EXISTS cost_events_heartbeat_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.cost_events DROP CONSTRAINT IF EXISTS cost_events_goal_id_goals_id_fk;
ALTER TABLE IF EXISTS ONLY public.cost_events DROP CONSTRAINT IF EXISTS cost_events_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.cost_events DROP CONSTRAINT IF EXISTS cost_events_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_user_sidebar_preferences DROP CONSTRAINT IF EXISTS company_user_sidebar_preferences_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_skills DROP CONSTRAINT IF EXISTS company_skills_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_secrets DROP CONSTRAINT IF EXISTS company_secrets_provider_config_id_company_secret_provider_conf;
ALTER TABLE IF EXISTS ONLY public.company_secrets DROP CONSTRAINT IF EXISTS company_secrets_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_secrets DROP CONSTRAINT IF EXISTS company_secrets_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_secret_versions DROP CONSTRAINT IF EXISTS company_secret_versions_secret_id_company_secrets_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_secret_versions DROP CONSTRAINT IF EXISTS company_secret_versions_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_secret_provider_configs DROP CONSTRAINT IF EXISTS company_secret_provider_configs_created_by_agent_id_agents_id_f;
ALTER TABLE IF EXISTS ONLY public.company_secret_provider_configs DROP CONSTRAINT IF EXISTS company_secret_provider_configs_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_secret_bindings DROP CONSTRAINT IF EXISTS company_secret_bindings_secret_id_company_secrets_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_secret_bindings DROP CONSTRAINT IF EXISTS company_secret_bindings_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_memberships DROP CONSTRAINT IF EXISTS company_memberships_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_logos DROP CONSTRAINT IF EXISTS company_logos_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.company_logos DROP CONSTRAINT IF EXISTS company_logos_asset_id_assets_id_fk;
ALTER TABLE IF EXISTS ONLY public.cli_auth_challenges DROP CONSTRAINT IF EXISTS cli_auth_challenges_requested_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.cli_auth_challenges DROP CONSTRAINT IF EXISTS cli_auth_challenges_board_api_key_id_board_api_keys_id_fk;
ALTER TABLE IF EXISTS ONLY public.cli_auth_challenges DROP CONSTRAINT IF EXISTS cli_auth_challenges_approved_by_user_id_user_id_fk;
ALTER TABLE IF EXISTS ONLY public.budget_policies DROP CONSTRAINT IF EXISTS budget_policies_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.budget_incidents DROP CONSTRAINT IF EXISTS budget_incidents_policy_id_budget_policies_id_fk;
ALTER TABLE IF EXISTS ONLY public.budget_incidents DROP CONSTRAINT IF EXISTS budget_incidents_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.budget_incidents DROP CONSTRAINT IF EXISTS budget_incidents_approval_id_approvals_id_fk;
ALTER TABLE IF EXISTS ONLY public.board_api_keys DROP CONSTRAINT IF EXISTS board_api_keys_user_id_user_id_fk;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS assets_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS assets_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.approvals DROP CONSTRAINT IF EXISTS approvals_requested_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.approvals DROP CONSTRAINT IF EXISTS approvals_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.approval_comments DROP CONSTRAINT IF EXISTS approval_comments_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.approval_comments DROP CONSTRAINT IF EXISTS approval_comments_author_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.approval_comments DROP CONSTRAINT IF EXISTS approval_comments_approval_id_approvals_id_fk;
ALTER TABLE IF EXISTS ONLY public.agents DROP CONSTRAINT IF EXISTS agents_reports_to_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.agents DROP CONSTRAINT IF EXISTS agents_default_environment_id_environments_id_fk;
ALTER TABLE IF EXISTS ONLY public.agents DROP CONSTRAINT IF EXISTS agents_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_wakeup_requests DROP CONSTRAINT IF EXISTS agent_wakeup_requests_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_wakeup_requests DROP CONSTRAINT IF EXISTS agent_wakeup_requests_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_task_sessions DROP CONSTRAINT IF EXISTS agent_task_sessions_last_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_task_sessions DROP CONSTRAINT IF EXISTS agent_task_sessions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_task_sessions DROP CONSTRAINT IF EXISTS agent_task_sessions_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_runtime_state DROP CONSTRAINT IF EXISTS agent_runtime_state_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_runtime_state DROP CONSTRAINT IF EXISTS agent_runtime_state_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_config_revisions DROP CONSTRAINT IF EXISTS agent_config_revisions_created_by_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_config_revisions DROP CONSTRAINT IF EXISTS agent_config_revisions_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_config_revisions DROP CONSTRAINT IF EXISTS agent_config_revisions_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_api_keys DROP CONSTRAINT IF EXISTS agent_api_keys_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.agent_api_keys DROP CONSTRAINT IF EXISTS agent_api_keys_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.activity_log DROP CONSTRAINT IF EXISTS activity_log_run_id_heartbeat_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.activity_log DROP CONSTRAINT IF EXISTS activity_log_company_id_companies_id_fk;
ALTER TABLE IF EXISTS ONLY public.activity_log DROP CONSTRAINT IF EXISTS activity_log_agent_id_agents_id_fk;
ALTER TABLE IF EXISTS ONLY public.account DROP CONSTRAINT IF EXISTS account_user_id_user_id_fk;
DROP INDEX IF EXISTS public.workspace_runtime_services_run_idx;
DROP INDEX IF EXISTS public.workspace_runtime_services_company_workspace_status_idx;
DROP INDEX IF EXISTS public.workspace_runtime_services_company_updated_idx;
DROP INDEX IF EXISTS public.workspace_runtime_services_company_project_status_idx;
DROP INDEX IF EXISTS public.workspace_runtime_services_company_execution_workspace_status_i;
DROP INDEX IF EXISTS public.workspace_operations_company_workspace_started_idx;
DROP INDEX IF EXISTS public.workspace_operations_company_run_started_idx;
DROP INDEX IF EXISTS public.user_sidebar_preferences_user_uq;
DROP INDEX IF EXISTS public.secret_access_events_secret_created_idx;
DROP INDEX IF EXISTS public.secret_access_events_run_idx;
DROP INDEX IF EXISTS public.secret_access_events_consumer_idx;
DROP INDEX IF EXISTS public.secret_access_events_company_created_idx;
DROP INDEX IF EXISTS public.routines_company_status_idx;
DROP INDEX IF EXISTS public.routines_company_project_idx;
DROP INDEX IF EXISTS public.routines_company_assignee_idx;
DROP INDEX IF EXISTS public.routine_triggers_public_id_uq;
DROP INDEX IF EXISTS public.routine_triggers_public_id_idx;
DROP INDEX IF EXISTS public.routine_triggers_next_run_idx;
DROP INDEX IF EXISTS public.routine_triggers_company_routine_idx;
DROP INDEX IF EXISTS public.routine_triggers_company_kind_idx;
DROP INDEX IF EXISTS public.routine_runs_trigger_idx;
DROP INDEX IF EXISTS public.routine_runs_trigger_idempotency_idx;
DROP INDEX IF EXISTS public.routine_runs_linked_issue_idx;
DROP INDEX IF EXISTS public.routine_runs_dispatch_fingerprint_idx;
DROP INDEX IF EXISTS public.routine_runs_company_routine_idx;
DROP INDEX IF EXISTS public.routine_revisions_routine_revision_uq;
DROP INDEX IF EXISTS public.routine_revisions_company_routine_created_idx;
DROP INDEX IF EXISTS public.projects_company_idx;
DROP INDEX IF EXISTS public.project_workspaces_project_source_type_idx;
DROP INDEX IF EXISTS public.project_workspaces_project_remote_ref_idx;
DROP INDEX IF EXISTS public.project_workspaces_project_primary_idx;
DROP INDEX IF EXISTS public.project_workspaces_company_shared_key_idx;
DROP INDEX IF EXISTS public.project_workspaces_company_project_idx;
DROP INDEX IF EXISTS public.project_goals_project_idx;
DROP INDEX IF EXISTS public.project_goals_goal_idx;
DROP INDEX IF EXISTS public.project_goals_company_idx;
DROP INDEX IF EXISTS public.principal_permission_grants_unique_idx;
DROP INDEX IF EXISTS public.principal_permission_grants_company_permission_idx;
DROP INDEX IF EXISTS public.plugins_status_idx;
DROP INDEX IF EXISTS public.plugins_plugin_key_idx;
DROP INDEX IF EXISTS public.plugin_webhook_deliveries_status_idx;
DROP INDEX IF EXISTS public.plugin_webhook_deliveries_plugin_idx;
DROP INDEX IF EXISTS public.plugin_webhook_deliveries_key_idx;
DROP INDEX IF EXISTS public.plugin_state_plugin_scope_idx;
DROP INDEX IF EXISTS public.plugin_migrations_status_idx;
DROP INDEX IF EXISTS public.plugin_migrations_plugin_key_idx;
DROP INDEX IF EXISTS public.plugin_migrations_plugin_idx;
DROP INDEX IF EXISTS public.plugin_managed_resources_resource_idx;
DROP INDEX IF EXISTS public.plugin_managed_resources_plugin_idx;
DROP INDEX IF EXISTS public.plugin_managed_resources_company_plugin_resource_uq;
DROP INDEX IF EXISTS public.plugin_managed_resources_company_idx;
DROP INDEX IF EXISTS public.plugin_logs_plugin_time_idx;
DROP INDEX IF EXISTS public.plugin_logs_level_idx;
DROP INDEX IF EXISTS public.plugin_jobs_unique_idx;
DROP INDEX IF EXISTS public.plugin_jobs_plugin_idx;
DROP INDEX IF EXISTS public.plugin_jobs_next_run_idx;
DROP INDEX IF EXISTS public.plugin_job_runs_status_idx;
DROP INDEX IF EXISTS public.plugin_job_runs_plugin_idx;
DROP INDEX IF EXISTS public.plugin_job_runs_job_idx;
DROP INDEX IF EXISTS public.plugin_entities_type_idx;
DROP INDEX IF EXISTS public.plugin_entities_scope_idx;
DROP INDEX IF EXISTS public.plugin_entities_plugin_idx;
DROP INDEX IF EXISTS public.plugin_entities_external_idx;
DROP INDEX IF EXISTS public.plugin_database_namespaces_status_idx;
DROP INDEX IF EXISTS public.plugin_database_namespaces_plugin_idx;
DROP INDEX IF EXISTS public.plugin_database_namespaces_namespace_idx;
DROP INDEX IF EXISTS public.plugin_config_plugin_id_idx;
DROP INDEX IF EXISTS public.plugin_company_settings_plugin_idx;
DROP INDEX IF EXISTS public.plugin_company_settings_company_plugin_uq;
DROP INDEX IF EXISTS public.plugin_company_settings_company_idx;
DROP INDEX IF EXISTS public.labels_company_name_idx;
DROP INDEX IF EXISTS public.labels_company_idx;
DROP INDEX IF EXISTS public.join_requests_pending_human_user_uq;
DROP INDEX IF EXISTS public.join_requests_pending_human_email_uq;
DROP INDEX IF EXISTS public.join_requests_invite_unique_idx;
DROP INDEX IF EXISTS public.join_requests_company_status_type_created_idx;
DROP INDEX IF EXISTS public.issues_title_search_idx;
DROP INDEX IF EXISTS public.issues_open_routine_execution_uq;
DROP INDEX IF EXISTS public.issues_identifier_search_idx;
DROP INDEX IF EXISTS public.issues_identifier_idx;
DROP INDEX IF EXISTS public.issues_description_search_idx;
DROP INDEX IF EXISTS public.issues_company_status_idx;
DROP INDEX IF EXISTS public.issues_company_project_workspace_idx;
DROP INDEX IF EXISTS public.issues_company_project_idx;
DROP INDEX IF EXISTS public.issues_company_parent_idx;
DROP INDEX IF EXISTS public.issues_company_origin_idx;
DROP INDEX IF EXISTS public.issues_company_monitor_due_idx;
DROP INDEX IF EXISTS public.issues_company_execution_workspace_idx;
DROP INDEX IF EXISTS public.issues_company_assignee_user_status_idx;
DROP INDEX IF EXISTS public.issues_company_assignee_status_idx;
DROP INDEX IF EXISTS public.issues_active_stranded_issue_recovery_uq;
DROP INDEX IF EXISTS public.issues_active_stale_run_evaluation_uq;
DROP INDEX IF EXISTS public.issues_active_productivity_review_uq;
DROP INDEX IF EXISTS public.issues_active_liveness_recovery_leaf_uq;
DROP INDEX IF EXISTS public.issues_active_liveness_recovery_incident_uq;
DROP INDEX IF EXISTS public.issue_work_products_company_updated_idx;
DROP INDEX IF EXISTS public.issue_work_products_company_provider_external_id_idx;
DROP INDEX IF EXISTS public.issue_work_products_company_issue_type_idx;
DROP INDEX IF EXISTS public.issue_work_products_company_execution_workspace_type_idx;
DROP INDEX IF EXISTS public.issue_tree_holds_company_status_mode_idx;
DROP INDEX IF EXISTS public.issue_tree_holds_company_root_status_idx;
DROP INDEX IF EXISTS public.issue_tree_hold_members_hold_issue_uq;
DROP INDEX IF EXISTS public.issue_tree_hold_members_hold_depth_idx;
DROP INDEX IF EXISTS public.issue_tree_hold_members_company_issue_idx;
DROP INDEX IF EXISTS public.issue_thread_interactions_source_comment_idx;
DROP INDEX IF EXISTS public.issue_thread_interactions_issue_idx;
DROP INDEX IF EXISTS public.issue_thread_interactions_company_issue_status_idx;
DROP INDEX IF EXISTS public.issue_thread_interactions_company_issue_idempotency_uq;
DROP INDEX IF EXISTS public.issue_thread_interactions_company_issue_created_at_idx;
DROP INDEX IF EXISTS public.issue_relations_company_type_idx;
DROP INDEX IF EXISTS public.issue_relations_company_related_issue_idx;
DROP INDEX IF EXISTS public.issue_relations_company_issue_idx;
DROP INDEX IF EXISTS public.issue_relations_company_edge_uq;
DROP INDEX IF EXISTS public.issue_reference_mentions_company_target_issue_idx;
DROP INDEX IF EXISTS public.issue_reference_mentions_company_source_mention_record_uq;
DROP INDEX IF EXISTS public.issue_reference_mentions_company_source_mention_null_record_uq;
DROP INDEX IF EXISTS public.issue_reference_mentions_company_source_issue_idx;
DROP INDEX IF EXISTS public.issue_reference_mentions_company_issue_pair_idx;
DROP INDEX IF EXISTS public.issue_recovery_actions_company_source_status_idx;
DROP INDEX IF EXISTS public.issue_recovery_actions_company_recovery_issue_idx;
DROP INDEX IF EXISTS public.issue_recovery_actions_company_owner_status_idx;
DROP INDEX IF EXISTS public.issue_recovery_actions_active_source_uq;
DROP INDEX IF EXISTS public.issue_recovery_actions_active_fingerprint_uq;
DROP INDEX IF EXISTS public.issue_read_states_company_user_idx;
DROP INDEX IF EXISTS public.issue_read_states_company_issue_user_idx;
DROP INDEX IF EXISTS public.issue_read_states_company_issue_idx;
DROP INDEX IF EXISTS public.issue_labels_label_idx;
DROP INDEX IF EXISTS public.issue_labels_issue_idx;
DROP INDEX IF EXISTS public.issue_labels_company_idx;
DROP INDEX IF EXISTS public.issue_inbox_archives_company_user_idx;
DROP INDEX IF EXISTS public.issue_inbox_archives_company_issue_user_idx;
DROP INDEX IF EXISTS public.issue_inbox_archives_company_issue_idx;
DROP INDEX IF EXISTS public.issue_execution_decisions_stage_idx;
DROP INDEX IF EXISTS public.issue_execution_decisions_company_issue_idx;
DROP INDEX IF EXISTS public.issue_documents_document_uq;
DROP INDEX IF EXISTS public.issue_documents_company_issue_updated_idx;
DROP INDEX IF EXISTS public.issue_documents_company_issue_key_uq;
DROP INDEX IF EXISTS public.issue_comments_issue_idx;
DROP INDEX IF EXISTS public.issue_comments_company_issue_created_at_idx;
DROP INDEX IF EXISTS public.issue_comments_company_idx;
DROP INDEX IF EXISTS public.issue_comments_company_author_issue_created_at_idx;
DROP INDEX IF EXISTS public.issue_comments_body_search_idx;
DROP INDEX IF EXISTS public.issue_attachments_issue_comment_idx;
DROP INDEX IF EXISTS public.issue_attachments_company_issue_idx;
DROP INDEX IF EXISTS public.issue_attachments_asset_uq;
DROP INDEX IF EXISTS public.issue_approvals_issue_idx;
DROP INDEX IF EXISTS public.issue_approvals_company_idx;
DROP INDEX IF EXISTS public.issue_approvals_approval_idx;
DROP INDEX IF EXISTS public.invites_token_hash_unique_idx;
DROP INDEX IF EXISTS public.invites_company_invite_state_idx;
DROP INDEX IF EXISTS public.instance_user_roles_user_role_unique_idx;
DROP INDEX IF EXISTS public.instance_user_roles_role_idx;
DROP INDEX IF EXISTS public.instance_settings_singleton_key_idx;
DROP INDEX IF EXISTS public.inbox_dismissals_company_user_item_idx;
DROP INDEX IF EXISTS public.inbox_dismissals_company_user_idx;
DROP INDEX IF EXISTS public.inbox_dismissals_company_item_idx;
DROP INDEX IF EXISTS public.heartbeat_runs_company_status_process_started_idx;
DROP INDEX IF EXISTS public.heartbeat_runs_company_status_last_output_idx;
DROP INDEX IF EXISTS public.heartbeat_runs_company_liveness_idx;
DROP INDEX IF EXISTS public.heartbeat_runs_company_agent_started_idx;
DROP INDEX IF EXISTS public.heartbeat_run_watchdog_decisions_company_run_snooze_idx;
DROP INDEX IF EXISTS public.heartbeat_run_watchdog_decisions_company_run_created_idx;
DROP INDEX IF EXISTS public.heartbeat_run_events_run_seq_idx;
DROP INDEX IF EXISTS public.heartbeat_run_events_company_run_idx;
DROP INDEX IF EXISTS public.heartbeat_run_events_company_created_idx;
DROP INDEX IF EXISTS public.goals_company_idx;
DROP INDEX IF EXISTS public.finance_events_company_occurred_idx;
DROP INDEX IF EXISTS public.finance_events_company_kind_occurred_idx;
DROP INDEX IF EXISTS public.finance_events_company_heartbeat_run_idx;
DROP INDEX IF EXISTS public.finance_events_company_direction_occurred_idx;
DROP INDEX IF EXISTS public.finance_events_company_cost_event_idx;
DROP INDEX IF EXISTS public.finance_events_company_biller_occurred_idx;
DROP INDEX IF EXISTS public.feedback_votes_issue_target_idx;
DROP INDEX IF EXISTS public.feedback_votes_company_target_author_idx;
DROP INDEX IF EXISTS public.feedback_votes_company_issue_idx;
DROP INDEX IF EXISTS public.feedback_votes_author_idx;
DROP INDEX IF EXISTS public.feedback_exports_feedback_vote_idx;
DROP INDEX IF EXISTS public.feedback_exports_company_status_idx;
DROP INDEX IF EXISTS public.feedback_exports_company_project_idx;
DROP INDEX IF EXISTS public.feedback_exports_company_issue_idx;
DROP INDEX IF EXISTS public.feedback_exports_company_created_idx;
DROP INDEX IF EXISTS public.feedback_exports_company_author_idx;
DROP INDEX IF EXISTS public.execution_workspaces_company_source_issue_idx;
DROP INDEX IF EXISTS public.execution_workspaces_company_project_workspace_status_idx;
DROP INDEX IF EXISTS public.execution_workspaces_company_project_status_idx;
DROP INDEX IF EXISTS public.execution_workspaces_company_last_used_idx;
DROP INDEX IF EXISTS public.execution_workspaces_company_branch_idx;
DROP INDEX IF EXISTS public.environments_company_status_idx;
DROP INDEX IF EXISTS public.environments_company_name_idx;
DROP INDEX IF EXISTS public.environments_company_driver_idx;
DROP INDEX IF EXISTS public.environment_leases_provider_lease_idx;
DROP INDEX IF EXISTS public.environment_leases_heartbeat_run_idx;
DROP INDEX IF EXISTS public.environment_leases_company_last_used_idx;
DROP INDEX IF EXISTS public.environment_leases_company_issue_idx;
DROP INDEX IF EXISTS public.environment_leases_company_execution_workspace_idx;
DROP INDEX IF EXISTS public.environment_leases_company_environment_status_idx;
DROP INDEX IF EXISTS public.documents_title_search_idx;
DROP INDEX IF EXISTS public.documents_latest_body_search_idx;
DROP INDEX IF EXISTS public.documents_company_updated_idx;
DROP INDEX IF EXISTS public.documents_company_created_idx;
DROP INDEX IF EXISTS public.document_revisions_document_revision_uq;
DROP INDEX IF EXISTS public.document_revisions_company_document_created_idx;
DROP INDEX IF EXISTS public.cost_events_company_provider_occurred_idx;
DROP INDEX IF EXISTS public.cost_events_company_occurred_idx;
DROP INDEX IF EXISTS public.cost_events_company_heartbeat_run_idx;
DROP INDEX IF EXISTS public.cost_events_company_biller_occurred_idx;
DROP INDEX IF EXISTS public.cost_events_company_agent_occurred_idx;
DROP INDEX IF EXISTS public.company_user_sidebar_preferences_user_idx;
DROP INDEX IF EXISTS public.company_user_sidebar_preferences_company_user_uq;
DROP INDEX IF EXISTS public.company_user_sidebar_preferences_company_idx;
DROP INDEX IF EXISTS public.company_skills_company_name_idx;
DROP INDEX IF EXISTS public.company_skills_company_key_idx;
DROP INDEX IF EXISTS public.company_secrets_provider_config_idx;
DROP INDEX IF EXISTS public.company_secrets_company_provider_idx;
DROP INDEX IF EXISTS public.company_secrets_company_name_uq;
DROP INDEX IF EXISTS public.company_secrets_company_key_uq;
DROP INDEX IF EXISTS public.company_secrets_company_idx;
DROP INDEX IF EXISTS public.company_secret_versions_value_sha256_idx;
DROP INDEX IF EXISTS public.company_secret_versions_secret_version_uq;
DROP INDEX IF EXISTS public.company_secret_versions_secret_idx;
DROP INDEX IF EXISTS public.company_secret_versions_fingerprint_idx;
DROP INDEX IF EXISTS public.company_secret_provider_configs_default_uq;
DROP INDEX IF EXISTS public.company_secret_provider_configs_company_provider_idx;
DROP INDEX IF EXISTS public.company_secret_provider_configs_company_idx;
DROP INDEX IF EXISTS public.company_secret_bindings_target_path_uq;
DROP INDEX IF EXISTS public.company_secret_bindings_target_idx;
DROP INDEX IF EXISTS public.company_secret_bindings_secret_idx;
DROP INDEX IF EXISTS public.company_secret_bindings_company_idx;
DROP INDEX IF EXISTS public.company_memberships_principal_status_idx;
DROP INDEX IF EXISTS public.company_memberships_company_status_idx;
DROP INDEX IF EXISTS public.company_memberships_company_principal_unique_idx;
DROP INDEX IF EXISTS public.company_logos_company_uq;
DROP INDEX IF EXISTS public.company_logos_asset_uq;
DROP INDEX IF EXISTS public.companies_issue_prefix_idx;
DROP INDEX IF EXISTS public.cli_auth_challenges_secret_hash_idx;
DROP INDEX IF EXISTS public.cli_auth_challenges_requested_company_idx;
DROP INDEX IF EXISTS public.cli_auth_challenges_approved_by_idx;
DROP INDEX IF EXISTS public.budget_policies_company_window_idx;
DROP INDEX IF EXISTS public.budget_policies_company_scope_metric_unique_idx;
DROP INDEX IF EXISTS public.budget_policies_company_scope_active_idx;
DROP INDEX IF EXISTS public.budget_incidents_policy_window_threshold_idx;
DROP INDEX IF EXISTS public.budget_incidents_company_status_idx;
DROP INDEX IF EXISTS public.budget_incidents_company_scope_idx;
DROP INDEX IF EXISTS public.board_api_keys_user_idx;
DROP INDEX IF EXISTS public.board_api_keys_key_hash_idx;
DROP INDEX IF EXISTS public.assets_company_provider_idx;
DROP INDEX IF EXISTS public.assets_company_object_key_uq;
DROP INDEX IF EXISTS public.assets_company_created_idx;
DROP INDEX IF EXISTS public.approvals_company_status_type_idx;
DROP INDEX IF EXISTS public.approval_comments_company_idx;
DROP INDEX IF EXISTS public.approval_comments_approval_idx;
DROP INDEX IF EXISTS public.approval_comments_approval_created_idx;
DROP INDEX IF EXISTS public.agents_company_status_idx;
DROP INDEX IF EXISTS public.agents_company_reports_to_idx;
DROP INDEX IF EXISTS public.agents_company_default_environment_idx;
DROP INDEX IF EXISTS public.agent_wakeup_requests_company_requested_idx;
DROP INDEX IF EXISTS public.agent_wakeup_requests_company_agent_status_idx;
DROP INDEX IF EXISTS public.agent_wakeup_requests_agent_requested_idx;
DROP INDEX IF EXISTS public.agent_task_sessions_company_task_updated_idx;
DROP INDEX IF EXISTS public.agent_task_sessions_company_agent_updated_idx;
DROP INDEX IF EXISTS public.agent_task_sessions_company_agent_adapter_task_uniq;
DROP INDEX IF EXISTS public.agent_runtime_state_company_updated_idx;
DROP INDEX IF EXISTS public.agent_runtime_state_company_agent_idx;
DROP INDEX IF EXISTS public.agent_config_revisions_company_agent_created_idx;
DROP INDEX IF EXISTS public.agent_config_revisions_agent_created_idx;
DROP INDEX IF EXISTS public.agent_api_keys_key_hash_idx;
DROP INDEX IF EXISTS public.agent_api_keys_company_agent_idx;
DROP INDEX IF EXISTS public.activity_log_run_id_idx;
DROP INDEX IF EXISTS public.activity_log_entity_type_id_idx;
DROP INDEX IF EXISTS public.activity_log_company_created_idx;
ALTER TABLE IF EXISTS ONLY public.workspace_runtime_services DROP CONSTRAINT IF EXISTS workspace_runtime_services_pkey;
ALTER TABLE IF EXISTS ONLY public.workspace_operations DROP CONSTRAINT IF EXISTS workspace_operations_pkey;
ALTER TABLE IF EXISTS ONLY public.verification DROP CONSTRAINT IF EXISTS verification_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sidebar_preferences DROP CONSTRAINT IF EXISTS user_sidebar_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_pkey;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_pkey;
ALTER TABLE IF EXISTS ONLY public.secret_access_events DROP CONSTRAINT IF EXISTS secret_access_events_pkey;
ALTER TABLE IF EXISTS ONLY public.routines DROP CONSTRAINT IF EXISTS routines_pkey;
ALTER TABLE IF EXISTS ONLY public.routine_triggers DROP CONSTRAINT IF EXISTS routine_triggers_pkey;
ALTER TABLE IF EXISTS ONLY public.routine_runs DROP CONSTRAINT IF EXISTS routine_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.routine_revisions DROP CONSTRAINT IF EXISTS routine_revisions_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.project_workspaces DROP CONSTRAINT IF EXISTS project_workspaces_pkey;
ALTER TABLE IF EXISTS ONLY public.project_goals DROP CONSTRAINT IF EXISTS project_goals_project_id_goal_id_pk;
ALTER TABLE IF EXISTS ONLY public.principal_permission_grants DROP CONSTRAINT IF EXISTS principal_permission_grants_pkey;
ALTER TABLE IF EXISTS ONLY public.plugins DROP CONSTRAINT IF EXISTS plugins_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_webhook_deliveries DROP CONSTRAINT IF EXISTS plugin_webhook_deliveries_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_state DROP CONSTRAINT IF EXISTS plugin_state_unique_entry_idx;
ALTER TABLE IF EXISTS ONLY public.plugin_state DROP CONSTRAINT IF EXISTS plugin_state_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_migrations DROP CONSTRAINT IF EXISTS plugin_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_managed_resources DROP CONSTRAINT IF EXISTS plugin_managed_resources_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_logs DROP CONSTRAINT IF EXISTS plugin_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_jobs DROP CONSTRAINT IF EXISTS plugin_jobs_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_job_runs DROP CONSTRAINT IF EXISTS plugin_job_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_entities DROP CONSTRAINT IF EXISTS plugin_entities_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_database_namespaces DROP CONSTRAINT IF EXISTS plugin_database_namespaces_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_config DROP CONSTRAINT IF EXISTS plugin_config_pkey;
ALTER TABLE IF EXISTS ONLY public.plugin_company_settings DROP CONSTRAINT IF EXISTS plugin_company_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.labels DROP CONSTRAINT IF EXISTS labels_pkey;
ALTER TABLE IF EXISTS ONLY public.join_requests DROP CONSTRAINT IF EXISTS join_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.issues DROP CONSTRAINT IF EXISTS issues_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_work_products DROP CONSTRAINT IF EXISTS issue_work_products_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_tree_holds DROP CONSTRAINT IF EXISTS issue_tree_holds_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_tree_hold_members DROP CONSTRAINT IF EXISTS issue_tree_hold_members_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_thread_interactions DROP CONSTRAINT IF EXISTS issue_thread_interactions_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_relations DROP CONSTRAINT IF EXISTS issue_relations_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_reference_mentions DROP CONSTRAINT IF EXISTS issue_reference_mentions_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_recovery_actions DROP CONSTRAINT IF EXISTS issue_recovery_actions_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_read_states DROP CONSTRAINT IF EXISTS issue_read_states_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_labels DROP CONSTRAINT IF EXISTS issue_labels_pk;
ALTER TABLE IF EXISTS ONLY public.issue_inbox_archives DROP CONSTRAINT IF EXISTS issue_inbox_archives_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_execution_decisions DROP CONSTRAINT IF EXISTS issue_execution_decisions_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_documents DROP CONSTRAINT IF EXISTS issue_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_comments DROP CONSTRAINT IF EXISTS issue_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_attachments DROP CONSTRAINT IF EXISTS issue_attachments_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_approvals DROP CONSTRAINT IF EXISTS issue_approvals_pk;
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS invites_pkey;
ALTER TABLE IF EXISTS ONLY public.instance_user_roles DROP CONSTRAINT IF EXISTS instance_user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.instance_settings DROP CONSTRAINT IF EXISTS instance_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.inbox_dismissals DROP CONSTRAINT IF EXISTS inbox_dismissals_pkey;
ALTER TABLE IF EXISTS ONLY public.heartbeat_runs DROP CONSTRAINT IF EXISTS heartbeat_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_watchdog_decisions DROP CONSTRAINT IF EXISTS heartbeat_run_watchdog_decisions_pkey;
ALTER TABLE IF EXISTS ONLY public.heartbeat_run_events DROP CONSTRAINT IF EXISTS heartbeat_run_events_pkey;
ALTER TABLE IF EXISTS ONLY public.goals DROP CONSTRAINT IF EXISTS goals_pkey;
ALTER TABLE IF EXISTS ONLY public.finance_events DROP CONSTRAINT IF EXISTS finance_events_pkey;
ALTER TABLE IF EXISTS ONLY public.feedback_votes DROP CONSTRAINT IF EXISTS feedback_votes_pkey;
ALTER TABLE IF EXISTS ONLY public.feedback_exports DROP CONSTRAINT IF EXISTS feedback_exports_pkey;
ALTER TABLE IF EXISTS ONLY public.execution_workspaces DROP CONSTRAINT IF EXISTS execution_workspaces_pkey;
ALTER TABLE IF EXISTS ONLY public.environments DROP CONSTRAINT IF EXISTS environments_pkey;
ALTER TABLE IF EXISTS ONLY public.environment_leases DROP CONSTRAINT IF EXISTS environment_leases_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.document_revisions DROP CONSTRAINT IF EXISTS document_revisions_pkey;
ALTER TABLE IF EXISTS ONLY public.cost_events DROP CONSTRAINT IF EXISTS cost_events_pkey;
ALTER TABLE IF EXISTS ONLY public.company_user_sidebar_preferences DROP CONSTRAINT IF EXISTS company_user_sidebar_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.company_skills DROP CONSTRAINT IF EXISTS company_skills_pkey;
ALTER TABLE IF EXISTS ONLY public.company_secrets DROP CONSTRAINT IF EXISTS company_secrets_pkey;
ALTER TABLE IF EXISTS ONLY public.company_secret_versions DROP CONSTRAINT IF EXISTS company_secret_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.company_secret_provider_configs DROP CONSTRAINT IF EXISTS company_secret_provider_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.company_secret_bindings DROP CONSTRAINT IF EXISTS company_secret_bindings_pkey;
ALTER TABLE IF EXISTS ONLY public.company_memberships DROP CONSTRAINT IF EXISTS company_memberships_pkey;
ALTER TABLE IF EXISTS ONLY public.company_logos DROP CONSTRAINT IF EXISTS company_logos_pkey;
ALTER TABLE IF EXISTS ONLY public.companies DROP CONSTRAINT IF EXISTS companies_pkey;
ALTER TABLE IF EXISTS ONLY public.cli_auth_challenges DROP CONSTRAINT IF EXISTS cli_auth_challenges_pkey;
ALTER TABLE IF EXISTS ONLY public.budget_policies DROP CONSTRAINT IF EXISTS budget_policies_pkey;
ALTER TABLE IF EXISTS ONLY public.budget_incidents DROP CONSTRAINT IF EXISTS budget_incidents_pkey;
ALTER TABLE IF EXISTS ONLY public.board_api_keys DROP CONSTRAINT IF EXISTS board_api_keys_pkey;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS assets_pkey;
ALTER TABLE IF EXISTS ONLY public.approvals DROP CONSTRAINT IF EXISTS approvals_pkey;
ALTER TABLE IF EXISTS ONLY public.approval_comments DROP CONSTRAINT IF EXISTS approval_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.agents DROP CONSTRAINT IF EXISTS agents_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_wakeup_requests DROP CONSTRAINT IF EXISTS agent_wakeup_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_task_sessions DROP CONSTRAINT IF EXISTS agent_task_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_runtime_state DROP CONSTRAINT IF EXISTS agent_runtime_state_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_config_revisions DROP CONSTRAINT IF EXISTS agent_config_revisions_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_api_keys DROP CONSTRAINT IF EXISTS agent_api_keys_pkey;
ALTER TABLE IF EXISTS ONLY public.activity_log DROP CONSTRAINT IF EXISTS activity_log_pkey;
ALTER TABLE IF EXISTS ONLY public.account DROP CONSTRAINT IF EXISTS account_pkey;
ALTER TABLE IF EXISTS ONLY drizzle.__drizzle_migrations DROP CONSTRAINT IF EXISTS __drizzle_migrations_pkey;
ALTER TABLE IF EXISTS public.heartbeat_run_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS drizzle.__drizzle_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.workspace_runtime_services;
DROP TABLE IF EXISTS public.workspace_operations;
DROP TABLE IF EXISTS public.verification;
DROP TABLE IF EXISTS public.user_sidebar_preferences;
DROP TABLE IF EXISTS public."user";
DROP TABLE IF EXISTS public.session;
DROP TABLE IF EXISTS public.secret_access_events;
DROP TABLE IF EXISTS public.routines;
DROP TABLE IF EXISTS public.routine_triggers;
DROP TABLE IF EXISTS public.routine_runs;
DROP TABLE IF EXISTS public.routine_revisions;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.project_workspaces;
DROP TABLE IF EXISTS public.project_goals;
DROP TABLE IF EXISTS public.principal_permission_grants;
DROP TABLE IF EXISTS public.plugins;
DROP TABLE IF EXISTS public.plugin_webhook_deliveries;
DROP TABLE IF EXISTS public.plugin_state;
DROP TABLE IF EXISTS public.plugin_migrations;
DROP TABLE IF EXISTS public.plugin_managed_resources;
DROP TABLE IF EXISTS public.plugin_logs;
DROP TABLE IF EXISTS public.plugin_jobs;
DROP TABLE IF EXISTS public.plugin_job_runs;
DROP TABLE IF EXISTS public.plugin_entities;
DROP TABLE IF EXISTS public.plugin_database_namespaces;
DROP TABLE IF EXISTS public.plugin_config;
DROP TABLE IF EXISTS public.plugin_company_settings;
DROP TABLE IF EXISTS public.labels;
DROP TABLE IF EXISTS public.join_requests;
DROP TABLE IF EXISTS public.issues;
DROP TABLE IF EXISTS public.issue_work_products;
DROP TABLE IF EXISTS public.issue_tree_holds;
DROP TABLE IF EXISTS public.issue_tree_hold_members;
DROP TABLE IF EXISTS public.issue_thread_interactions;
DROP TABLE IF EXISTS public.issue_relations;
DROP TABLE IF EXISTS public.issue_reference_mentions;
DROP TABLE IF EXISTS public.issue_recovery_actions;
DROP TABLE IF EXISTS public.issue_read_states;
DROP TABLE IF EXISTS public.issue_labels;
DROP TABLE IF EXISTS public.issue_inbox_archives;
DROP TABLE IF EXISTS public.issue_execution_decisions;
DROP TABLE IF EXISTS public.issue_documents;
DROP TABLE IF EXISTS public.issue_comments;
DROP TABLE IF EXISTS public.issue_attachments;
DROP TABLE IF EXISTS public.issue_approvals;
DROP TABLE IF EXISTS public.invites;
DROP TABLE IF EXISTS public.instance_user_roles;
DROP TABLE IF EXISTS public.instance_settings;
DROP TABLE IF EXISTS public.inbox_dismissals;
DROP TABLE IF EXISTS public.heartbeat_runs;
DROP TABLE IF EXISTS public.heartbeat_run_watchdog_decisions;
DROP SEQUENCE IF EXISTS public.heartbeat_run_events_id_seq;
DROP TABLE IF EXISTS public.heartbeat_run_events;
DROP TABLE IF EXISTS public.goals;
DROP TABLE IF EXISTS public.finance_events;
DROP TABLE IF EXISTS public.feedback_votes;
DROP TABLE IF EXISTS public.feedback_exports;
DROP TABLE IF EXISTS public.execution_workspaces;
DROP TABLE IF EXISTS public.environments;
DROP TABLE IF EXISTS public.environment_leases;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.document_revisions;
DROP TABLE IF EXISTS public.cost_events;
DROP TABLE IF EXISTS public.company_user_sidebar_preferences;
DROP TABLE IF EXISTS public.company_skills;
DROP TABLE IF EXISTS public.company_secrets;
DROP TABLE IF EXISTS public.company_secret_versions;
DROP TABLE IF EXISTS public.company_secret_provider_configs;
DROP TABLE IF EXISTS public.company_secret_bindings;
DROP TABLE IF EXISTS public.company_memberships;
DROP TABLE IF EXISTS public.company_logos;
DROP TABLE IF EXISTS public.companies;
DROP TABLE IF EXISTS public.cli_auth_challenges;
DROP TABLE IF EXISTS public.budget_policies;
DROP TABLE IF EXISTS public.budget_incidents;
DROP TABLE IF EXISTS public.board_api_keys;
DROP TABLE IF EXISTS public.assets;
DROP TABLE IF EXISTS public.approvals;
DROP TABLE IF EXISTS public.approval_comments;
DROP TABLE IF EXISTS public.agents;
DROP TABLE IF EXISTS public.agent_wakeup_requests;
DROP TABLE IF EXISTS public.agent_task_sessions;
DROP TABLE IF EXISTS public.agent_runtime_state;
DROP TABLE IF EXISTS public.agent_config_revisions;
DROP TABLE IF EXISTS public.agent_api_keys;
DROP TABLE IF EXISTS public.activity_log;
DROP TABLE IF EXISTS public.account;
DROP SEQUENCE IF EXISTS drizzle.__drizzle_migrations_id_seq;
DROP TABLE IF EXISTS drizzle.__drizzle_migrations;
DROP EXTENSION IF EXISTS pg_trgm;
DROP EXTENSION IF EXISTS fuzzystrmatch;
DROP SCHEMA IF EXISTS drizzle;
--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account (
    id text NOT NULL,
    account_id text NOT NULL,
    provider_id text NOT NULL,
    user_id text NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp with time zone,
    refresh_token_expires_at timestamp with time zone,
    scope text,
    password text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    actor_type text DEFAULT 'system'::text NOT NULL,
    actor_id text NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    agent_id uuid,
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    run_id uuid
);


--
-- Name: agent_api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_config_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_config_revisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    created_by_agent_id uuid,
    created_by_user_id text,
    source text DEFAULT 'patch'::text NOT NULL,
    rolled_back_from_revision_id uuid,
    changed_keys jsonb DEFAULT '[]'::jsonb NOT NULL,
    before_config jsonb NOT NULL,
    after_config jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_runtime_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_runtime_state (
    agent_id uuid NOT NULL,
    company_id uuid NOT NULL,
    adapter_type text NOT NULL,
    session_id text,
    state_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_run_id uuid,
    last_run_status text,
    total_input_tokens bigint DEFAULT 0 NOT NULL,
    total_output_tokens bigint DEFAULT 0 NOT NULL,
    total_cached_input_tokens bigint DEFAULT 0 NOT NULL,
    total_cost_cents bigint DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_task_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_task_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    adapter_type text NOT NULL,
    task_key text NOT NULL,
    session_params_json jsonb,
    session_display_id text,
    last_run_id uuid,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_wakeup_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_wakeup_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    source text NOT NULL,
    trigger_detail text,
    reason text,
    payload jsonb,
    status text DEFAULT 'queued'::text NOT NULL,
    coalesced_count integer DEFAULT 0 NOT NULL,
    requested_by_actor_type text,
    requested_by_actor_id text,
    idempotency_key text,
    run_id uuid,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_at timestamp with time zone,
    finished_at timestamp with time zone,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'general'::text NOT NULL,
    title text,
    status text DEFAULT 'idle'::text NOT NULL,
    reports_to uuid,
    capabilities text,
    adapter_type text DEFAULT 'process'::text NOT NULL,
    adapter_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    budget_monthly_cents integer DEFAULT 0 NOT NULL,
    spent_monthly_cents integer DEFAULT 0 NOT NULL,
    last_heartbeat_at timestamp with time zone,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    runtime_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL,
    icon text,
    pause_reason text,
    paused_at timestamp with time zone,
    default_environment_id uuid
);


--
-- Name: approval_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    approval_id uuid NOT NULL,
    author_agent_id uuid,
    author_user_id text,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    type text NOT NULL,
    requested_by_agent_id uuid,
    requested_by_user_id text,
    status text DEFAULT 'pending'::text NOT NULL,
    payload jsonb NOT NULL,
    decision_note text,
    decided_by_user_id text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    provider text NOT NULL,
    object_key text NOT NULL,
    content_type text NOT NULL,
    byte_size integer NOT NULL,
    sha256 text NOT NULL,
    original_filename text,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: board_api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: budget_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_incidents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    policy_id uuid NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid NOT NULL,
    metric text NOT NULL,
    window_kind text NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end timestamp with time zone NOT NULL,
    threshold_type text NOT NULL,
    amount_limit integer NOT NULL,
    amount_observed integer NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    approval_id uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: budget_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid NOT NULL,
    metric text DEFAULT 'billed_cents'::text NOT NULL,
    window_kind text NOT NULL,
    amount integer DEFAULT 0 NOT NULL,
    warn_percent integer DEFAULT 80 NOT NULL,
    hard_stop_enabled boolean DEFAULT true NOT NULL,
    notify_enabled boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by_user_id text,
    updated_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: cli_auth_challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cli_auth_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    secret_hash text NOT NULL,
    command text NOT NULL,
    client_name text,
    requested_access text DEFAULT 'board'::text NOT NULL,
    requested_company_id uuid,
    pending_key_hash text NOT NULL,
    pending_key_name text NOT NULL,
    approved_by_user_id text,
    board_api_key_id uuid,
    approved_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    budget_monthly_cents integer DEFAULT 0 NOT NULL,
    spent_monthly_cents integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    issue_prefix text DEFAULT 'PAP'::text NOT NULL,
    issue_counter integer DEFAULT 0 NOT NULL,
    require_board_approval_for_new_agents boolean DEFAULT false NOT NULL,
    brand_color text,
    pause_reason text,
    paused_at timestamp with time zone,
    feedback_data_sharing_enabled boolean DEFAULT false NOT NULL,
    feedback_data_sharing_consent_at timestamp with time zone,
    feedback_data_sharing_consent_by_user_id text,
    feedback_data_sharing_terms_version text,
    attachment_max_bytes integer DEFAULT 10485760 NOT NULL
);


--
-- Name: company_logos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_logos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: company_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_memberships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    membership_role text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: company_secret_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_secret_bindings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    secret_id uuid NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    config_path text NOT NULL,
    version_selector text DEFAULT 'latest'::text NOT NULL,
    required boolean DEFAULT true NOT NULL,
    label text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: company_secret_provider_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_secret_provider_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    provider text NOT NULL,
    display_name text NOT NULL,
    status text DEFAULT 'ready'::text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    health_status text,
    health_checked_at timestamp with time zone,
    health_message text,
    health_details jsonb,
    disabled_at timestamp with time zone,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: company_secret_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_secret_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    secret_id uuid NOT NULL,
    version integer NOT NULL,
    material jsonb NOT NULL,
    value_sha256 text NOT NULL,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    provider_version_ref text,
    status text DEFAULT 'current'::text NOT NULL,
    fingerprint_sha256 text NOT NULL,
    rotation_job_id text
);


--
-- Name: company_secrets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_secrets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL,
    provider text DEFAULT 'local_encrypted'::text NOT NULL,
    external_ref text,
    latest_version integer DEFAULT 1 NOT NULL,
    description text,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    key text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    managed_mode text DEFAULT 'paperclip_managed'::text NOT NULL,
    provider_config_id uuid,
    provider_metadata jsonb,
    last_resolved_at timestamp with time zone,
    last_rotated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


--
-- Name: company_skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_skills (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    key text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    description text,
    markdown text NOT NULL,
    source_type text DEFAULT 'local_path'::text NOT NULL,
    source_locator text,
    source_ref text,
    trust_level text DEFAULT 'markdown_only'::text NOT NULL,
    compatibility text DEFAULT 'compatible'::text NOT NULL,
    file_inventory jsonb DEFAULT '[]'::jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: company_user_sidebar_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_user_sidebar_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    user_id text NOT NULL,
    project_order jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: cost_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    issue_id uuid,
    project_id uuid,
    goal_id uuid,
    billing_code text,
    provider text NOT NULL,
    model text NOT NULL,
    input_tokens integer DEFAULT 0 NOT NULL,
    output_tokens integer DEFAULT 0 NOT NULL,
    cost_cents integer NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    heartbeat_run_id uuid,
    biller text DEFAULT 'unknown'::text NOT NULL,
    billing_type text DEFAULT 'unknown'::text NOT NULL,
    cached_input_tokens integer DEFAULT 0 NOT NULL
);


--
-- Name: document_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_revisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    document_id uuid NOT NULL,
    revision_number integer NOT NULL,
    body text NOT NULL,
    change_summary text,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    title text,
    format text DEFAULT 'markdown'::text NOT NULL,
    created_by_run_id uuid
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    title text,
    format text DEFAULT 'markdown'::text NOT NULL,
    latest_body text NOT NULL,
    latest_revision_id uuid,
    latest_revision_number integer DEFAULT 1 NOT NULL,
    created_by_agent_id uuid,
    created_by_user_id text,
    updated_by_agent_id uuid,
    updated_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    locked_at timestamp with time zone,
    locked_by_agent_id uuid,
    locked_by_user_id text
);


--
-- Name: environment_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environment_leases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    environment_id uuid NOT NULL,
    execution_workspace_id uuid,
    issue_id uuid,
    heartbeat_run_id uuid,
    status text DEFAULT 'active'::text NOT NULL,
    lease_policy text DEFAULT 'ephemeral'::text NOT NULL,
    provider text,
    provider_lease_id text,
    acquired_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    released_at timestamp with time zone,
    failure_reason text,
    cleanup_status text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    driver text DEFAULT 'local'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: execution_workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.execution_workspaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    project_workspace_id uuid,
    source_issue_id uuid,
    mode text NOT NULL,
    strategy_type text NOT NULL,
    name text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    cwd text,
    repo_url text,
    base_ref text,
    branch_name text,
    provider_type text DEFAULT 'local_fs'::text NOT NULL,
    provider_ref text,
    derived_from_execution_workspace_id uuid,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    cleanup_eligible_at timestamp with time zone,
    cleanup_reason text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: feedback_exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    feedback_vote_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    project_id uuid,
    author_user_id text NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    vote text NOT NULL,
    status text DEFAULT 'local_only'::text NOT NULL,
    destination text,
    export_id text,
    consent_version text,
    schema_version text DEFAULT 'paperclip-feedback-envelope-v2'::text NOT NULL,
    bundle_version text DEFAULT 'paperclip-feedback-bundle-v2'::text NOT NULL,
    payload_version text DEFAULT 'paperclip-feedback-v1'::text NOT NULL,
    payload_digest text,
    payload_snapshot jsonb,
    target_summary jsonb NOT NULL,
    redaction_summary jsonb,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_attempted_at timestamp with time zone,
    exported_at timestamp with time zone,
    failure_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: feedback_votes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback_votes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    author_user_id text NOT NULL,
    vote text NOT NULL,
    reason text,
    shared_with_labs boolean DEFAULT false NOT NULL,
    shared_at timestamp with time zone,
    consent_version text,
    redaction_summary jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    agent_id uuid,
    issue_id uuid,
    project_id uuid,
    goal_id uuid,
    heartbeat_run_id uuid,
    cost_event_id uuid,
    billing_code text,
    description text,
    event_kind text NOT NULL,
    direction text DEFAULT 'debit'::text NOT NULL,
    biller text NOT NULL,
    provider text,
    execution_adapter_type text,
    pricing_tier text,
    region text,
    model text,
    quantity integer,
    unit text,
    amount_cents integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    estimated boolean DEFAULT false NOT NULL,
    external_invoice_id text,
    metadata_json jsonb,
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    level text DEFAULT 'task'::text NOT NULL,
    status text DEFAULT 'planned'::text NOT NULL,
    parent_id uuid,
    owner_agent_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: heartbeat_run_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heartbeat_run_events (
    id bigint NOT NULL,
    company_id uuid NOT NULL,
    run_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    seq integer NOT NULL,
    event_type text NOT NULL,
    stream text,
    level text,
    color text,
    message text,
    payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: heartbeat_run_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.heartbeat_run_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: heartbeat_run_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.heartbeat_run_events_id_seq OWNED BY public.heartbeat_run_events.id;


--
-- Name: heartbeat_run_watchdog_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heartbeat_run_watchdog_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    run_id uuid NOT NULL,
    evaluation_issue_id uuid,
    decision text NOT NULL,
    snoozed_until timestamp with time zone,
    reason text,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_by_run_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: heartbeat_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heartbeat_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    invocation_source text DEFAULT 'on_demand'::text NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    error text,
    external_run_id text,
    context_snapshot jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    trigger_detail text,
    wakeup_request_id uuid,
    exit_code integer,
    signal text,
    usage_json jsonb,
    result_json jsonb,
    session_id_before text,
    session_id_after text,
    log_store text,
    log_ref text,
    log_bytes bigint,
    log_sha256 text,
    log_compressed boolean DEFAULT false NOT NULL,
    stdout_excerpt text,
    stderr_excerpt text,
    error_code text,
    process_pid integer,
    process_started_at timestamp with time zone,
    retry_of_run_id uuid,
    process_loss_retry_count integer DEFAULT 0 NOT NULL,
    issue_comment_status text DEFAULT 'not_applicable'::text NOT NULL,
    issue_comment_satisfied_by_comment_id uuid,
    issue_comment_retry_queued_at timestamp with time zone,
    process_group_id integer,
    liveness_state text,
    liveness_reason text,
    continuation_attempt integer DEFAULT 0 NOT NULL,
    last_useful_action_at timestamp with time zone,
    next_action text,
    scheduled_retry_at timestamp with time zone,
    scheduled_retry_attempt integer DEFAULT 0 NOT NULL,
    scheduled_retry_reason text,
    last_output_at timestamp with time zone,
    last_output_seq integer DEFAULT 0 NOT NULL,
    last_output_stream text,
    last_output_bytes bigint
);


--
-- Name: inbox_dismissals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inbox_dismissals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    user_id text NOT NULL,
    item_key text NOT NULL,
    dismissed_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: instance_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.instance_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    singleton_key text DEFAULT 'default'::text NOT NULL,
    experimental jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    general jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: instance_user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.instance_user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    role text DEFAULT 'instance_admin'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid,
    invite_type text DEFAULT 'company_join'::text NOT NULL,
    token_hash text NOT NULL,
    allowed_join_types text DEFAULT 'both'::text NOT NULL,
    defaults_payload jsonb,
    expires_at timestamp with time zone NOT NULL,
    invited_by_user_id text,
    revoked_at timestamp with time zone,
    accepted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_approvals (
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    approval_id uuid NOT NULL,
    linked_by_agent_id uuid,
    linked_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    issue_comment_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    author_agent_id uuid,
    author_user_id text,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_run_id uuid,
    author_type text,
    presentation jsonb,
    metadata jsonb
);


--
-- Name: issue_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    document_id uuid NOT NULL,
    key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_execution_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_execution_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    stage_id uuid NOT NULL,
    stage_type text NOT NULL,
    actor_agent_id uuid,
    actor_user_id text,
    outcome text NOT NULL,
    body text NOT NULL,
    created_by_run_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_inbox_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_inbox_archives (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    user_id text NOT NULL,
    archived_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_labels (
    issue_id uuid NOT NULL,
    label_id uuid NOT NULL,
    company_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_read_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_read_states (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    user_id text NOT NULL,
    last_read_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_recovery_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_recovery_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    source_issue_id uuid NOT NULL,
    recovery_issue_id uuid,
    kind text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    owner_type text DEFAULT 'agent'::text NOT NULL,
    owner_agent_id uuid,
    owner_user_id text,
    previous_owner_agent_id uuid,
    return_owner_agent_id uuid,
    cause text NOT NULL,
    fingerprint text NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    next_action text NOT NULL,
    wake_policy jsonb,
    monitor_policy jsonb,
    attempt_count integer DEFAULT 0 NOT NULL,
    max_attempts integer,
    timeout_at timestamp with time zone,
    last_attempt_at timestamp with time zone,
    outcome text,
    resolution_note text,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_reference_mentions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_reference_mentions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    source_issue_id uuid NOT NULL,
    target_issue_id uuid NOT NULL,
    source_kind text NOT NULL,
    source_record_id uuid,
    document_key text,
    matched_text text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_relations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    related_issue_id uuid NOT NULL,
    type text NOT NULL,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT issue_relations_type_check CHECK ((type = 'blocks'::text))
);


--
-- Name: issue_thread_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_thread_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    kind text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    continuation_policy text DEFAULT 'wake_assignee'::text NOT NULL,
    source_comment_id uuid,
    source_run_id uuid,
    title text,
    summary text,
    created_by_agent_id uuid,
    created_by_user_id text,
    resolved_by_agent_id uuid,
    resolved_by_user_id text,
    payload jsonb NOT NULL,
    result jsonb,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key text
);


--
-- Name: issue_tree_hold_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_tree_hold_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    hold_id uuid NOT NULL,
    issue_id uuid NOT NULL,
    parent_issue_id uuid,
    depth integer DEFAULT 0 NOT NULL,
    issue_identifier text,
    issue_title text NOT NULL,
    issue_status text NOT NULL,
    assignee_agent_id uuid,
    assignee_user_id text,
    active_run_id uuid,
    active_run_status text,
    skipped boolean DEFAULT false NOT NULL,
    skip_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_tree_holds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_tree_holds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    root_issue_id uuid NOT NULL,
    mode text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    reason text,
    release_policy jsonb,
    created_by_actor_type text DEFAULT 'system'::text NOT NULL,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_by_run_id uuid,
    released_at timestamp with time zone,
    released_by_actor_type text,
    released_by_agent_id uuid,
    released_by_user_id text,
    released_by_run_id uuid,
    release_reason text,
    release_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issue_work_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_work_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid,
    issue_id uuid NOT NULL,
    execution_workspace_id uuid,
    runtime_service_id uuid,
    type text NOT NULL,
    provider text NOT NULL,
    external_id text,
    title text NOT NULL,
    url text,
    status text NOT NULL,
    review_state text DEFAULT 'none'::text NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    health_status text DEFAULT 'unknown'::text NOT NULL,
    summary text,
    metadata jsonb,
    created_by_run_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: issues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issues (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid,
    goal_id uuid,
    parent_id uuid,
    title text NOT NULL,
    description text,
    status text DEFAULT 'backlog'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    assignee_agent_id uuid,
    created_by_agent_id uuid,
    created_by_user_id text,
    request_depth integer DEFAULT 0 NOT NULL,
    billing_code text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    issue_number integer,
    identifier text,
    hidden_at timestamp with time zone,
    checkout_run_id uuid,
    execution_run_id uuid,
    execution_agent_name_key text,
    execution_locked_at timestamp with time zone,
    assignee_user_id text,
    assignee_adapter_overrides jsonb,
    execution_workspace_settings jsonb,
    project_workspace_id uuid,
    execution_workspace_id uuid,
    execution_workspace_preference text,
    origin_kind text DEFAULT 'manual'::text NOT NULL,
    origin_id text,
    origin_run_id text,
    execution_policy jsonb,
    execution_state jsonb,
    origin_fingerprint text DEFAULT 'default'::text NOT NULL,
    monitor_next_check_at timestamp with time zone,
    monitor_wake_requested_at timestamp with time zone,
    monitor_last_triggered_at timestamp with time zone,
    monitor_attempt_count integer DEFAULT 0 NOT NULL,
    monitor_notes text,
    monitor_scheduled_by text,
    work_mode text DEFAULT 'standard'::text NOT NULL
);


--
-- Name: join_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.join_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invite_id uuid NOT NULL,
    company_id uuid NOT NULL,
    request_type text NOT NULL,
    status text DEFAULT 'pending_approval'::text NOT NULL,
    request_ip text NOT NULL,
    requesting_user_id text,
    request_email_snapshot text,
    agent_name text,
    adapter_type text,
    capabilities text,
    agent_defaults_payload jsonb,
    created_agent_id uuid,
    approved_by_user_id text,
    approved_at timestamp with time zone,
    rejected_by_user_id text,
    rejected_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    claim_secret_hash text,
    claim_secret_expires_at timestamp with time zone,
    claim_secret_consumed_at timestamp with time zone
);


--
-- Name: labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    name text NOT NULL,
    color text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_company_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_company_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    plugin_id uuid NOT NULL,
    settings_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    enabled boolean DEFAULT true NOT NULL
);


--
-- Name: plugin_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_id uuid NOT NULL,
    config_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_database_namespaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_database_namespaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_id uuid NOT NULL,
    plugin_key text NOT NULL,
    namespace_name text NOT NULL,
    namespace_mode text DEFAULT 'schema'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_entities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_entities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_id uuid NOT NULL,
    entity_type text NOT NULL,
    scope_kind text NOT NULL,
    scope_id text,
    external_id text,
    title text,
    status text,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_job_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_job_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id uuid NOT NULL,
    plugin_id uuid NOT NULL,
    trigger text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    duration_ms integer,
    error text,
    logs jsonb DEFAULT '[]'::jsonb NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_id uuid NOT NULL,
    job_key text NOT NULL,
    schedule text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_id uuid NOT NULL,
    level text DEFAULT 'info'::text NOT NULL,
    message text NOT NULL,
    meta jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_managed_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_managed_resources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    plugin_id uuid NOT NULL,
    plugin_key text NOT NULL,
    resource_kind text NOT NULL,
    resource_key text NOT NULL,
    resource_id uuid NOT NULL,
    defaults_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_migrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_id uuid NOT NULL,
    plugin_key text NOT NULL,
    namespace_name text NOT NULL,
    migration_key text NOT NULL,
    checksum text NOT NULL,
    plugin_version text NOT NULL,
    status text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_at timestamp with time zone,
    error_message text
);


--
-- Name: plugin_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_state (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_id uuid NOT NULL,
    scope_kind text NOT NULL,
    scope_id text,
    namespace text DEFAULT 'default'::text NOT NULL,
    state_key text NOT NULL,
    value_json jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugin_webhook_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugin_webhook_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_id uuid NOT NULL,
    webhook_key text NOT NULL,
    external_id text,
    status text DEFAULT 'pending'::text NOT NULL,
    duration_ms integer,
    error text,
    payload jsonb NOT NULL,
    headers jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plugin_key text NOT NULL,
    package_name text NOT NULL,
    package_path text,
    version text NOT NULL,
    api_version integer DEFAULT 1 NOT NULL,
    categories jsonb DEFAULT '[]'::jsonb NOT NULL,
    manifest_json jsonb NOT NULL,
    status text DEFAULT 'installed'::text NOT NULL,
    install_order integer,
    last_error text,
    installed_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: principal_permission_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.principal_permission_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission_key text NOT NULL,
    scope jsonb,
    granted_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_goals (
    project_id uuid NOT NULL,
    goal_id uuid NOT NULL,
    company_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_workspaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    name text NOT NULL,
    cwd text,
    repo_url text,
    repo_ref text,
    metadata jsonb,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source_type text DEFAULT 'local_path'::text NOT NULL,
    default_ref text,
    visibility text DEFAULT 'default'::text NOT NULL,
    setup_command text,
    cleanup_command text,
    remote_provider text,
    remote_workspace_ref text,
    shared_workspace_key text
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    goal_id uuid,
    name text NOT NULL,
    description text,
    status text DEFAULT 'backlog'::text NOT NULL,
    lead_agent_id uuid,
    target_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    color text,
    archived_at timestamp with time zone,
    execution_workspace_policy jsonb,
    pause_reason text,
    paused_at timestamp with time zone,
    env jsonb
);


--
-- Name: routine_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.routine_revisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    routine_id uuid NOT NULL,
    revision_number integer NOT NULL,
    title text NOT NULL,
    description text,
    snapshot jsonb NOT NULL,
    change_summary text,
    restored_from_revision_id uuid,
    created_by_agent_id uuid,
    created_by_user_id text,
    created_by_run_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: routine_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.routine_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    routine_id uuid NOT NULL,
    trigger_id uuid,
    source text NOT NULL,
    status text DEFAULT 'received'::text NOT NULL,
    triggered_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key text,
    trigger_payload jsonb,
    linked_issue_id uuid,
    coalesced_into_run_id uuid,
    failure_reason text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    dispatch_fingerprint text
);


--
-- Name: routine_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.routine_triggers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    routine_id uuid NOT NULL,
    kind text NOT NULL,
    label text,
    enabled boolean DEFAULT true NOT NULL,
    cron_expression text,
    timezone text,
    next_run_at timestamp with time zone,
    last_fired_at timestamp with time zone,
    public_id text,
    secret_id uuid,
    signing_mode text,
    replay_window_sec integer,
    last_rotated_at timestamp with time zone,
    last_result text,
    created_by_agent_id uuid,
    created_by_user_id text,
    updated_by_agent_id uuid,
    updated_by_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: routines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.routines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid,
    goal_id uuid,
    parent_issue_id uuid,
    title text NOT NULL,
    description text,
    assignee_agent_id uuid,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    concurrency_policy text DEFAULT 'coalesce_if_active'::text NOT NULL,
    catch_up_policy text DEFAULT 'skip_missed'::text NOT NULL,
    created_by_agent_id uuid,
    created_by_user_id text,
    updated_by_agent_id uuid,
    updated_by_user_id text,
    last_triggered_at timestamp with time zone,
    last_enqueued_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb NOT NULL,
    latest_revision_id uuid,
    latest_revision_number integer DEFAULT 1 NOT NULL
);


--
-- Name: secret_access_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secret_access_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    secret_id uuid NOT NULL,
    version integer,
    provider text NOT NULL,
    actor_type text NOT NULL,
    actor_id text,
    consumer_type text NOT NULL,
    consumer_id text NOT NULL,
    config_path text,
    issue_id uuid,
    heartbeat_run_id uuid,
    plugin_id uuid,
    outcome text NOT NULL,
    error_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    id text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    token text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    ip_address text,
    user_agent text,
    user_id text NOT NULL
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    image text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: user_sidebar_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sidebar_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    company_order jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: verification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: workspace_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    company_id uuid NOT NULL,
    execution_workspace_id uuid,
    heartbeat_run_id uuid,
    phase text NOT NULL,
    command text,
    cwd text,
    status text DEFAULT 'running'::text NOT NULL,
    exit_code integer,
    log_store text,
    log_ref text,
    log_bytes bigint,
    log_sha256 text,
    log_compressed boolean DEFAULT false NOT NULL,
    stdout_excerpt text,
    stderr_excerpt text,
    metadata jsonb,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_runtime_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_runtime_services (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid,
    project_workspace_id uuid,
    issue_id uuid,
    scope_type text NOT NULL,
    scope_id text,
    service_name text NOT NULL,
    status text NOT NULL,
    lifecycle text NOT NULL,
    reuse_key text,
    command text,
    cwd text,
    port integer,
    url text,
    provider text NOT NULL,
    provider_ref text,
    owner_agent_id uuid,
    started_by_run_id uuid,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    stopped_at timestamp with time zone,
    stop_policy jsonb,
    health_status text DEFAULT 'unknown'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    execution_workspace_id uuid
);


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Name: heartbeat_run_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_events ALTER COLUMN id SET DEFAULT nextval('public.heartbeat_run_events_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	4a168f2905beecf8aba7c8a051028ebae7c603a957520fe84295ef7138bf4447	1771300567463
2	217284002174a0adcbbb99716afcb92411151a947a8a487de7dcb83a70ba5607	1771349039633
3	9cbdf1229ed84d34bdd56f5b8c3b22675ee4bc1365dd64a944e904bc2424a5e1	1771349403162
4	f60c49b6ee7454c996a46b590e78b4c22b534981dc08d65d0dd722a46d337a71	1771456737635
5	86e2f6f9d47ba19103a637d886c302b272aac26ccf9ee9d4a321d8c352433182	1771545600000
6	7040dd156d41369d8429ee83c01274a28cf45e195ffbea967d9b96f3052d72e1	1771545601000
7	2b9151436c1ca83ae56c0a20915d229a8f22a1398db0f5e7219572026b804b22	1771545602000
8	e9f9a84e20db5e428ae9213b248fa51872cb2fb7db627d06d9a4f1506a502ec9	1771545603000
9	d04b3303685364349c205964578bd5c4d62abf81dea54d971168c1bb6baa5b87	1771534160426
10	2c560d142857e22379831a7bcedadd3dd44e02f363b80ca5abdca9eec22c18a5	1771534211029
11	0c2be1ee431b088695ab3d1f1471d50f8fb619701b50b3c6a6beef725307f82d	1771605173513
12	06ef4c6d69108b55a7d618d76d4fb020e51a717d7519995f933b9ae021154659	1771616419708
13	363da95d93bf8f1e3f2c9d046684d66578b494e8cbadba6642432ea6db52b7a2	1771619674673
14	00e91acdaa63469f002158dbda1a2ff7362d41da4de334fe1e198482c8eaf9fb	1771623691139
15	cd2de941d6fc0f7fea6bb44fa41b978e88300e3ef3af68713aa57c6ea2a70241	1771691806349
16	42b5f5c8ea4f81988a6064b2eb8491c74847a4279ee5a5f3255cd69966dc9877	1771865100000
17	949b6579d20aca89afb8efc0375e705a1b6a275e9d7cec5ff9ba2eebf24ef88d	1771955900000
18	7b8bc0a9c03438b78611e5601cba48222bfbc6fcee08aa9594f172f558b5aa29	1771883888199
19	96712cb18db3f02e74ce33aca6d0a2ae52d7216964387b4e507e705ef07837eb	1771897769629
20	d07a384240e032c84ee5efbf040b12e78b3e670398dd39d5cf0157679b2a5b3a	1772029333401
21	2ef0a0fd958cf0c96df485ba8b3fff06dbed85c56a043991231a0d5258eec209	1772032176413
22	e5f5ec21df5031056ed92874dab3c770435ff092e3f8d15e7b07803ff29bf9e5	1772122471656
23	2e627668cc677920c7fd5d02f4532be3e253c9c80790ceb97711792a110122f4	1772186400000
24	484e5c7d805eb96ea50b7f808bba8df2b9a4120f4e1452a97ae18c9468a1944b	1772139727599
25	40ff648f3bc91a9a733f070db7e02649633485db4f91eda404f0612a0ab460d6	1772806603601
26	eb01d64ec77c03859269e370af4850092fe592944f3cf1fa6ad4695cb0b3ab17	1772807461603
27	605fae9ea9f92718a263550180e9102dc8f53d58827b236b8c6a3453cb0e9c64	1773089625430
28	d434c7ec995d048f812a74d248e36797eb77e597c9d4b942808f2ee4c53ef3d8	1773150731736
29	68a66cce12c03e2e46f84d7a0a282e502b9f9d26e9b452e31b79f6c860928640	1773432085646
30	893ff5bd4351dd79a5c51658beac7cbd6c92d1247eb76ac6364c87f763a4c8e2	1773417600000
31	ec7e4985166e9cb3abcb9ccaabf3d79771e96ccbaaf789028f9e5120044af51a	1773670925214
32	7ba5b686d334d3c0efbe6283ed9bb75aab35498c0b1b6fc363716e90b5572256	1773511922713
33	cc46d46a7167c57d3373827e6cf79d0807c093e29fb3ad90ac0092b42dd1deaa	1773542934499
34	d4616d35c778c192e8a46d8b6b5942fd95ede5ed3f8dbc95c276221539fe8b0e	1773664961967
35	b3e8c916f07608ad6ab220df5783c49d6d76e5640042ee1b2a64f8f2dc27189f	1773697572188
36	e79ecacc261720c947b887a45b5ed99bd6bab8d924e887fe98336a24e636ca35	1773698696169
37	f224c54bc3a5cea815854966d5ebab451eecc9fa4d1b9a1880efdf43c424cac4	1773756213455
38	8a8c9b444812583524c2776edac092cb9b8c05ba1ee7fa89241789d9e7a69272	1773756922363
39	359de5cfcaaaa5f4362f47f158e8a4d97d145896f6052ff118f44e23a2bae6b6	1773931592563
40	dd1854c43854dd238055dc6ed9bcd5b06f43feebc0fbb8306766e7292f19bc04	1773926116580
41	0b14055c4f5617b8b944b8e15d51472cd919be335881aa63f942677ad19c56ec	1773927102783
42	5bd65ef2947bd724b0ae5495db4527f4f191225a5fb425925f79294ebce7a03c	1774011294562
43	3772e9aada1d394b95cc588ac8e3756da7a5f57fcad8e9f661f96b4303820f53	1774031825634
44	e1119e9fdc94b36a0d77f806980a6d987b2d2e75b299727d1a5b02c9f8de03c8	1774008910991
45	d0dda5d7787eff4aefe1ece4e6d25b7947acd08c95e80fa34b170fd1474a04ab	1774269579794
46	fe897560c8d543587b37891f0b422b7c334ed9a6a10355c86bd4fbce566c5454	1774530504348
47	278631f7fd69ff46fd4d0b54c876fa81b317f7409c25790adb05c910b9a1dad7	1774960197878
48	31ef6263f4dde97af16f2fbcf520646883295cc852213cfb99062eb504d349f9	1775137972687
49	5b6c43f3d2b5fa8a1998cbf14bcbf6ee0c5067317d539e20b13b6487d48b8d42	1775145655557
50	7d25e72a806b086a94e6f548e764a7393f1e4d917c9afcee4d051e54643028fc	1775349863293
51	0432fd6dda492288eea238a155ffb46e146bbe55efac99ab81a99a290bb528fb	1775487782768
52	b6467b62ce525d470df92b97b0678c2568ae9d1ba8e6ca9d8a48ca2597899501	1775524651831
53	27fb10df284e95ecdf9e4029efa4df1a3b381b4073b9eeffb59b53cf4abc8c48	1775571715162
54	f8ec8fad6aa7bca5068720c2f0a4ea74efbafc40f53ad709fd31b8727412457c	1775604018515
55	f21d1da197bb83eced58f6074e9ac74e003b266afd51eac0cfafe0c2083af1e8	1775750400000
56	d7b227b28f8ea3621cedcee0ec46d06203a9a75872dd48d181bcf8eef8d7cec7	1775825256196
57	f305ae7da5d1b5df1701152ef2fe9b200cc7c1c50814c08cc274ca1e9d9a150b	1776084034244
58	cb435f82a01b567b72e27ceed83e3049502a2b284a08cfd32275e912c2f51741	1776309613598
59	f0b1525c737e32381bb9f5bef42751a08703b3e5cbf67128a13bd4de342bfcfe	1776542245004
60	578ea35e2a3c828dec0c666305b59aaf6f16035be160a53a4bfc6d4b7eb7ad83	1776542246000
61	a1467b361ef79eb72a49d9474111775b2baaec62d86f98591c239658250e4c15	1776717606743
62	da9b4301a9d02f5f44d173c595341d5a651b7a176837118d48df4ce5cd603b23	1776785165389
63	7ccc4880585927e45a2100c9faf0be169f198859e9ccb48102d8cf430138cc9c	1776780000000
64	a5859c4305fdf8719d4d1949d44e7029242286efb46a7ba7c4e5c5343d77ade3	1776780001000
65	9e32e1e4a4dbd752ff087f5672de594668c3485553262a80257ca480286170fb	1776780002000
66	280988e07dea328fe9815cb8c80dd16691ac1427ff9069cd2118038d4b2bb5cc	1776903900000
67	1a5aadd183ecaf557ee23801ceb9725a6d56dab78a4e4df539280b551ed82ef1	1776903901000
68	a1e43ea1a68770252d36ff1a5c00e660dcbea2a05222559ab3d6b4ca84ed2ea9	1776904200000
69	bbcbf800852e0e8f992db48b4653af73cd0478e494cbb71439f0ad664cc12cb8	1776959400000
70	fbc93ff9b93ad70bafe93cc44ac231ef73a6ea91983a4ab2e1b128ea9f8bd4a1	1776780003000
71	132aaa7a1ce516b815c26985a390ef78a1632730b939f82543fa8ea0e7b0246f	1776780004000
72	3b19e1d26124a927d13adc090864357667e3d73dac33a85594fe7bb0fdc610e9	1777131234000
73	008c2aab9a0e319f61018f2e7b4748e1454e24fa974eb404692fb6f4eac17cec	1777305216238
74	cc105a068340f86984758d5b012343d7bfb3bf85fc636d93381361ef6f88270f	1777382021347
75	5b4f58288af4351b14fce3e066255d8075e7a5a9732638b3038c910ecee00866	1777384535070
76	dc1f8c66a5088068819954aadff948e5bde26b2d7c3222f27f0ebb649639f144	1777572332006
77	601931acc7e344c9738f4ff52a64f9aae544c9c60c4292eb73e6fff5cd916f12	1777675301279
78	48fe3461dd7d75e0bf8d66f260f480d5cdad40895314352d5dc41e62cded344e	1777933347806
79	11573ddf41de1208831980dcbfb143922bbb374fe4e20ba5eaa96f6820033767	1778004024976
80	2b5a14a99abf4c6cbd753f52d806b8a999e4fb03a95b00493873f2c1227745a9	1777821410992
81	49c738698d5efa84a54c06def568721654d399427d4ae4ff05fad2646a0a3e1e	1777849000000
82	79676a9996c0a8979ba19812c10393961d361ced758fa14d447d346300d8b334	1778067785040
83	2b6660781a0bc51fb4b255ecf90bd1a533888f6514114f324bd86e3c40b9bcb5	1778067785041
84	a97be2bb8f67b0f5cf2782d43ea01d6ca8117e4b78bf600c9ebf6e9250578685	1778074536410
85	84ea5e794c63599a55fc15fbb4c9eaa098bcc0da4d4195ee515d4c3ce702cf51	1778355326070
86	f9852e06c19b1ff4fcebb34bcda456d2995fb24beeac5b70432deee9b6d7b229	1778787362162
\.


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account (id, account_id, provider_id, user_id, access_token, refresh_token, id_token, access_token_expires_at, refresh_token_expires_at, scope, password, created_at, updated_at) FROM stdin;
nRTVyPRbNUp9rejSruFTXg5Cn6mfIt4V	5ogQZrALdOL170oXtx4PfWowYHz1nwsU	credential	5ogQZrALdOL170oXtx4PfWowYHz1nwsU	\N	\N	\N	\N	\N	\N	f9335ac0909acc40f5f19896c0f27f48:c2e16cb261ebdb285c4fcb8ada40e8354ea775aaae3d947fe91a09f24b30255f68d613d17d9042511a8fc4896ff4bdb367350c535f1f4f3618832a1de1bd9f24	2026-05-22 05:33:01.003+00	2026-05-22 05:33:01.003+00
VPeuUhm5FnMs5BEhVyKbSJkZ9GtX0yoB	uj1RoKPtCeCoaFTK3tAd9wo40wNGWTVR	credential	uj1RoKPtCeCoaFTK3tAd9wo40wNGWTVR	\N	\N	\N	\N	\N	\N	c16bb9a32456147d3bfb82f5ddb81ec3:f9741e3f62da4a5dcd501eeecbbbf1264f2be1193bcc9cc16f1c52c6e6a2f3dac54a5ab5b95a590d9e34ba2d01d8cd4745895955d426ba6ebce76d4e5915fa26	2026-05-22 06:21:04.136+00	2026-05-22 06:21:04.136+00
rc0PeHBPx81sFgHKInDm2N5tl6mvige9	QnbBbjjiyHU8arRsHwRlqgeCTa81b6AY	credential	QnbBbjjiyHU8arRsHwRlqgeCTa81b6AY	\N	\N	\N	\N	\N	\N	fd3207ba656e28f76bc8f8901c3f16db:5f75e309e2f360f0d71b5a5b9a77e8bb5b4eefd590ed5ab23c5e4d1541568ee34d7685b975a034881bca5afc6a47e62afa968382f07615c188860f66cf417f23	2026-05-22 06:21:04.354+00	2026-05-22 06:21:04.354+00
FeZJU0OfnRLlT8HKEVHa9CC00aOqrQOU	ZoKmgSjzpofOZAIZ14yowCr1jBg1nexd	credential	ZoKmgSjzpofOZAIZ14yowCr1jBg1nexd	\N	\N	\N	\N	\N	\N	e978c6489879ac5bd944dcab22e847b7:6fdfffa79cb2b783dbf138b1d4b0ae0c5c0ec6be1b03a65cb909e875d3922bed7e4ccca6341196cfe15edf63aee8a9d165dfd17cd6abc19df663816312ebf3e5	2026-05-22 06:21:04.501+00	2026-05-22 06:21:04.501+00
eQVnRzNwNCzmyK6jmxXQe86drxLfX1nY	js5Gky9lyiODja5qF5wWeTzI6RMnRrJU	credential	js5Gky9lyiODja5qF5wWeTzI6RMnRrJU	\N	\N	\N	\N	\N	\N	c013c9e54079c3458b691b3f9350653c:a288d5e095a850c4753c4535543ae165b8ee3fad06e36f8f3b06578445edecc2355d027b2ef6dc8cbf794f3b28f1f0bc34289c0a27ab96d9d437c6c59bfe45c4	2026-05-22 06:21:04.665+00	2026-05-22 06:21:04.665+00
xf4wo67D9tvVNSYjqqG3WWjTQHdgmfj3	T7ZAtzuszPwagJoN4AzKB5JO5kJYfpko	credential	T7ZAtzuszPwagJoN4AzKB5JO5kJYfpko	\N	\N	\N	\N	\N	\N	7f9f0e36ae3502faf368b4174657fecf:d16b55a603f0d76bf797ef0e12fadbed28a1c1c56233d474c66504476bccba85d5ad695757838f5218c2aba523662fb84a3ffc93a82c57aef0d3ff56ead3756e	2026-05-22 15:33:02.509+00	2026-05-22 15:33:02.509+00
ZqAZVTShGTglxjSiyLvJ2hwQjfRZQpGY	FdBnonvHlAWoP4OhcSz7B5olcnRmy2L1	credential	FdBnonvHlAWoP4OhcSz7B5olcnRmy2L1	\N	\N	\N	\N	\N	\N	a3ff5b4ea8b121b1e371f4ae9be29b9e:8d24f836f9ab80f97191ce94774a31ef0c3c8284eadfc6681058d383f7f537d49d6f04acb2a789c9c037a16e4446abf6c6d73027bedccdc114fc083c5fbc1076	2026-05-22 15:35:45.912+00	2026-05-22 15:35:45.912+00
gn4jhoJYJZmBuXBtjY1DL9CKaZkybITx	f1hueRcBcnBNjUrzMW5EK3YJIqAW2t5b	credential	f1hueRcBcnBNjUrzMW5EK3YJIqAW2t5b	\N	\N	\N	\N	\N	\N	827b0f3731ab6f7d6820f49013193842:54bf030be5a038012a25e7fd0a4fa910eade4c17c340e117d3909efc24cb26bc77b634e4d34c6c290e029983129bf59c8279a3f9df1f47e140f59d3c01ef5a96	2026-05-22 15:42:17.531+00	2026-05-22 15:42:17.531+00
v5hv8JXSTMu0cKjF1Rp0cLzosIZiViQ1	QgbQMlbEdMviH6hm9cFuPrXU6CtvXwYx	credential	QgbQMlbEdMviH6hm9cFuPrXU6CtvXwYx	\N	\N	\N	\N	\N	\N	b77210798cf187304373f1e68676fad7:ff2818ec4a3f175385c156e3d88d9fcb6716e61c124c892619ae8ff81c254d2b0d40d8c85a2b39e86693847e87d7c289f15c2702fc36be63effbe193c287f4f7	2026-05-22 15:51:48.023+00	2026-05-22 15:51:48.023+00
\.


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_log (id, company_id, actor_type, actor_id, action, entity_type, entity_id, agent_id, details, created_at, run_id) FROM stdin;
\.


--
-- Data for Name: agent_api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_api_keys (id, agent_id, company_id, name, key_hash, last_used_at, revoked_at, created_at) FROM stdin;
6c80c15e-79a3-43fc-a355-229c8ab7bcaa	4181a8e7-13c0-46f9-a30e-be8efde4d7cf	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-ENG-WEB-FRONTEND-2	b86e86262f012d381e8420011c303ab0ebc289d9be24cacd8201c6edb753dbf8	\N	\N	2026-05-22 18:22:20.146586+00
d91e7db1-9144-4250-ae29-ccf89e4d531f	90e98495-824e-4ba5-a9cd-df2bd087ee32	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-ENG-API-2	8bfd217c02e77f223dc9443e68e3323a96f9bc5b08f08e2f96fc7f5b8c0ea536	\N	\N	2026-05-22 18:22:20.146586+00
47830f23-3dae-4c0d-b464-8a1e1fe0a525	2ed62f71-2618-4cb9-98ff-21bd4602e5e0	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-ENG-WEB-FRONTEND-2	7c3a83394937c0259a4380acc490a87acf75ed9ff609849fc601466bbd8b7bc9	2026-05-22 21:23:08.007+00	\N	2026-05-22 18:22:20.146586+00
1c78fd8e-e172-4a86-9fc1-66369aac52b2	00922a3c-6ab1-4db1-9a49-7f669af81343	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-ENG-API-2	db664a74f4be9e8d4d306817ef59d3c1e9dabf41addc7be2715c2309d4035747	2026-05-22 21:23:22.243+00	\N	2026-05-22 18:22:20.146586+00
4f86f9cc-fa7d-4d56-969f-4e19e75043be	bd2e77f4-7d34-45e1-bef7-9183831bc851	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-ENG-WEB-FRONTEND-2	d3f1420f06d2d611cd4440a6c6d6c0c4fdf3af1380cbc992648ffc81dd9a6e13	2026-05-22 21:06:33.049+00	\N	2026-05-22 18:22:20.146586+00
7510bc01-b44c-4729-b605-ac331df4dbf1	6aebb64e-38a8-473a-8df3-bcc25824fb7d	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-ENG-API-2	6d3713c850ebcecc864e9c49f6cfe7ec137c41f2349ee260632f5380e6ee7f6e	2026-05-22 21:06:47.335+00	\N	2026-05-22 18:22:20.146586+00
d3d5cae3-3a54-45cd-a6c8-4f7777b87986	07dc95a8-a84a-4a74-9318-740cfdd38866	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-BUG-BOUNTY	fea04a9bee910d8f2b9f7158c6913f0b541385ccf6c6a3070aea71fc4400ad6a	2026-05-22 21:10:50.126+00	\N	2026-05-22 18:02:19.858968+00
442f0057-6a8a-4f9f-aa28-b84114f27736	53ef54cf-6db8-4286-9462-30fff6187413	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-CTO	52081f632908c72fd50411b783ac8d1e6fd939eb38ba8dec2815e473174b78a8	2026-05-22 21:12:04.629+00	\N	2026-05-22 18:02:19.858968+00
d57b57e7-6b23-4374-af04-7a7333a3e280	42e0f410-e62a-4b4b-8aaf-23704301b4af	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-STAFF-RN	82dabbfb2f8bfdf17ec17e9a1076a5a09d9769c8570d0e5bc4d22c4fb2c07e41	2026-05-22 21:13:01.828+00	\N	2026-05-22 18:02:19.858968+00
3287f60d-ee22-476f-b3b3-dc0da94e5c6d	8779a527-cc95-442f-a81e-dc567c0cdca0	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-MKT-CONTENT	f40dd4f60e80df038080adcd0af4853850368424d24e8e3f4c7305528ad82e1a	\N	\N	2026-05-22 18:02:19.858968+00
8bd6b292-d345-4a48-98df-7bff3b6cc133	a3663b65-90db-4964-88ae-e1185b8c4bd6	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-MKT-CREATIVE	1ecab4432093532245639bac94f1625c03b658b224178fcf8ee2216910c7f3bb	\N	\N	2026-05-22 18:02:19.858968+00
3d85f103-6b16-4002-8461-e859e16fad0b	7cf8f19c-28e7-4b88-b24a-4c2626054c1b	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-CRO	1e98b50bb92fef82237419a22d9e9caaaf1fb100147070ea42e83a9ed172a715	2026-05-22 20:54:58.513+00	\N	2026-05-22 18:02:19.858968+00
f7d831b2-cbf2-446d-8797-4ca9253ba697	d46aa59f-a0b7-4850-8741-5c8e284b9e1c	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-CEO	cdbdf2a18b10797313079b511d2a96082fbcc6f4b8e39885260477b11cd589f2	2026-05-22 20:53:51.442+00	\N	2026-05-22 18:02:19.858968+00
b31ed19e-7068-4b13-a32f-e99928c1c286	bef94c85-6d32-4deb-afda-fb5c13584038	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-QA-E2E	69bb57a0106de259df8da020cc4ed6ffe31fcca73c6716dfd6cde867ddf350f5	\N	\N	2026-05-22 18:02:19.858968+00
16d34037-4a99-40c6-a73d-953052ec0a52	86070506-d7cf-4f79-9dab-4b526e8db6a3	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-QA-LEAD	3d0dfafaad4b0f19221e2ce3dcdece9948dd18150021f1040c519fe0d5e2da38	\N	\N	2026-05-22 18:02:19.858968+00
f962c183-f517-47b5-875c-6d93d9262eeb	4553dc21-74a8-4931-8256-da655fef241a	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-CPO	efdde8abc9fe52b025ea830d7fbd16c9878b2da37c8fa73d48940b75adc31378	2026-05-22 21:12:11.8+00	\N	2026-05-22 18:02:19.858968+00
ac3f898b-ba55-4cfc-940f-1260e8103621	06156af6-c717-462e-bc56-ed7d2a688393	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-CTO	e7bc837d94ab309a6efa269e75cfc11256c28858f04599df5f452b1cd5ec2748	2026-05-22 20:53:58.852+00	\N	2026-05-22 18:02:19.858968+00
6ac0c554-47d5-472d-bb2b-3904e80bc1fc	a221acf0-0b12-4d78-940d-9a3061905bbc	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-QA-UNIT	91d0f70bcfd765d4c5a81e8518b7dc5e476336eb85f65a62aa27b95e822d6905	\N	\N	2026-05-22 18:02:19.858968+00
7bcf584e-5004-4522-8877-7b087d18496b	b5016599-e2a6-4d6b-8573-876c769a27ab	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-ENG-API	be11d5e6b1cdaa41ee23f7fe1e9f39ee644e13b6619ae0f27858dc385ef44457	2026-05-22 21:06:40.209+00	\N	2026-05-22 18:02:19.858968+00
2174e7d4-e8b9-423c-a915-45cb817664d3	bf5603f8-b958-4285-88d1-3cea52b185c9	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-CRO	48c650daff266a7f56e90ab3576886c921ecf33908a733dcc660c517351d9a3b	2026-05-22 21:12:18.987+00	\N	2026-05-22 18:02:19.858968+00
9c83366e-70c3-47ec-8a86-745e4110e1c3	9794edb5-d5be-41f9-b600-212ac10a8a8b	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-BUG-BOUNTY	6d23527905c1107e7fadcad76ed8cff5c389a514ddb20d6439c567e0174e9cd2	\N	\N	2026-05-22 18:02:19.858968+00
89620cb1-78c3-4e23-b9d7-cf963dbf55e4	46f7de29-8442-48c5-9060-3012b17428e7	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-CPO	2051e590a49b23d36cd7b228e14376ebed7a02bb5516c6464f7f8ddb495c0c63	2026-05-22 20:54:21.104+00	\N	2026-05-22 18:02:19.858968+00
5af70376-68cd-4688-8af5-5580f0f53cbb	7fdcaea2-71c6-4791-8b28-570f871c8060	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-PM	9ede27dc12bb5a714e935d6c3e456021b6e8b14c1ae1a0e0184766f50900f48e	2026-05-22 21:12:26.121+00	\N	2026-05-22 18:02:19.858968+00
4454ed1c-eec7-4201-8130-520740fed566	64ed9716-6ce3-4747-b534-de1c23208bb1	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-PO	1f7c1f52e2dbbc568e84a25021721710d99091b095327106e7d4f55ecd05e802	2026-05-22 21:12:33.243+00	\N	2026-05-22 18:02:19.858968+00
f5905b6f-c988-42ae-9611-e2f8fb3d4c3c	41f88289-d847-49a9-a8c8-df92b8b35fa8	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-REVIEWER	fdea203c28d8eac31bcd1ce7e6b4092b5357b1bd668fbaac6884003e0c38b454	2026-05-22 21:12:40.428+00	\N	2026-05-22 18:02:19.858968+00
fedc7920-d792-4aa2-b6fa-6e5ea1b618a4	1a85a4a4-d61a-48f8-9f58-4373fd00b9f7	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-ENG-RN-ANDROID	6014e7233fec7d63b39dafc01a411562cda65dd0a62d507ab944a2d400cd49a6	2026-05-22 21:10:07.139+00	\N	2026-05-22 18:02:19.858968+00
75270c8c-d4d0-47ac-a9d0-485312dbac39	0ef004dc-d7f4-459d-85f3-4c73b4008961	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-STAFF-FRONTEND	4d66b027115918343c9d1147ef8d0c0a516611d2425fc44bae25a4a5d07f027c	2026-05-22 21:12:47.603+00	\N	2026-05-22 18:02:19.858968+00
978675cd-667a-4b46-a68e-187001181b0e	3fe44f46-ad69-4c57-bacb-47736ab288f5	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-ENG-WEB-FRONTEND	c57cbcb656a9f0aefddaf13dde2076d0cd2085efe2f45aef059a8a500478750a	2026-05-22 21:18:04.897+00	\N	2026-05-22 18:02:19.858968+00
f488307a-7e87-4e2e-9708-cec3af75d2e9	544b475d-754e-4196-85fe-cac25e2392ed	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-CEO	66612b70b0063b1ef7969349728d14fe83cb358a90624470714ac1a026422112	2026-05-22 21:11:57.491+00	\N	2026-05-22 18:02:19.858968+00
0c850a45-053e-4140-aa38-3c4d330bc221	8d8a5ee1-ebe5-465e-8a18-b17b815ecb60	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-STAFF-BACKEND	eaa4796dc53fd0c1386b481868782775f86f38dbeff5eeb707c53e024a6f13cf	2026-05-22 21:12:54.72+00	\N	2026-05-22 18:02:19.858968+00
4e8afdbf-da35-462f-a612-b2a550b5708f	231e9903-7d58-4eb0-91dd-b0507fe25e3f	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-ENG-API	d881ad051f7a315037732410293068244f30afbba31e6127c8c198f29d08284c	2026-05-22 21:23:15.132+00	\N	2026-05-22 18:02:19.858968+00
bec6bae5-cc38-4a83-a8e8-8ba582fcff9a	c2811a02-1ab3-4caf-873c-c60bfcaf209c	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-ENG-RN-IOS	467f1e0757a89878c81ba6e0b4ab87a151e2b72323309f5e90d26699b3caca38	2026-05-22 21:27:05.09+00	\N	2026-05-22 18:02:19.858968+00
967a1b00-98ca-4b0b-9c74-18d420e6e5d0	b3befd4b-9c97-4d9c-ba70-27387493e4a4	0b96ba9b-87c5-4e69-89ca-188782d40d5f	cortex-ENG-RN-ANDROID	90ed8af016ef578ea951b357031176ce4460b1cdf97a496d27d4cfa9d4fc4f1c	2026-05-22 21:27:12.255+00	\N	2026-05-22 18:02:19.858968+00
33b5ad54-41f3-4034-8923-2121bd8da049	08211152-aaca-4d3a-9b6e-9e8ee8e85665	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-QA-LEAD	f158ae02c36574d1ba584d6e714d28d1b0f93cae9b423f181984f79d502daecf	2026-05-22 21:10:14.347+00	\N	2026-05-22 18:02:19.858968+00
cdb348c6-d85e-4471-9905-af56b9ec2150	576ecd91-110d-4b26-be9b-711f5ec15a82	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-REVIEWER	6baa6b8012c44f6a450347b4e2e0f637aa1d2f3894f26d649a6cf990bf33a13a	2026-05-22 21:00:16.241+00	\N	2026-05-22 18:02:19.858968+00
33ecf3c9-8e2f-402f-a6d9-3acf1d549b8c	26fd450c-04e0-408d-b883-e1efd15dc4d4	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-STAFF-FRONTEND	17d2b407a38633042905b1a124d9418f6ffa87ead78b731678fa76d46c632034	2026-05-22 21:00:23.388+00	\N	2026-05-22 18:02:19.858968+00
6ff04228-e9e9-4633-8b5e-185554fd20cf	06d67702-d4af-48c8-81a4-10a7fb5f3374	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-QA-E2E	b9d84389c1265e1d14168ade11a8f0deaa27aba819d6a2b28317305261f93281	2026-05-22 21:10:21.564+00	\N	2026-05-22 18:02:19.858968+00
743e9f60-b0b3-4c54-a148-bc6446554c86	b348b5be-d356-4428-8138-c595b15bd58a	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-STAFF-BACKEND	f4739acfc788e4240e86e5a5500b6441c72b9a8c585421377e6bed2faddb88e1	2026-05-22 21:00:30.519+00	\N	2026-05-22 18:02:19.858968+00
e32ad9f3-48b0-40fb-b478-983f2f7c46f0	04773188-742c-4eb0-af4a-9af30eff6436	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-PM	4ec7261756b963762a10ecd44ea8973ea632c899d735ea3acb452b329888c055	2026-05-22 21:00:01.911+00	\N	2026-05-22 18:02:19.858968+00
1c7a1778-2c42-4fed-82a4-6be5af66dbed	55428e1c-6601-413e-90b1-d1e528dfa77d	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-PO	1552fd19c4840d31dbbbe5f62183f2a892089c137d9b07ab2c1204d27dc6c539	2026-05-22 21:00:09.068+00	\N	2026-05-22 18:02:19.858968+00
8c810b64-301c-49fd-af7a-308275724bde	8f8c7a52-3eff-4129-a412-7d483d26d493	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-STAFF-RN	c509336e7b56975355df7d1610658a59582dae421069c2b011fec4c46f9e4b9f	2026-05-22 21:00:37.618+00	\N	2026-05-22 18:02:19.858968+00
2e7f3b5f-df56-4ad2-9efa-aa22f27a743c	e9ebf6bb-cd87-459e-9b08-20743bb9b3eb	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-ENG-WEB-FRONTEND	b00f43cbdbd6cc793bb3ca6cc3e308c3e43ed3afd87bf93d555aed4d5ccb8ecc	2026-05-22 21:03:05.251+00	\N	2026-05-22 18:02:19.858968+00
6b2ad037-f62a-45b7-a6ee-1e2cad6dceea	9cec2434-4f85-4444-b328-6f4ccf3e47bb	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-QA-UNIT	2fbcf5656c9f3b7d19d6233972895f2a361c4f4746049b196c565cdee72f9855	2026-05-22 21:10:28.707+00	\N	2026-05-22 18:02:19.858968+00
e797f98a-3dc9-40be-a2cc-e4e9740a3036	bfc1f97a-29ca-461d-8941-c0ce28151bd0	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-ENG-RN-IOS	b2357e90b3e9f92ee10acbf2e8a5c5ee9d6a000f5cd5596bd6aca4f9d7a1344e	2026-05-22 21:06:54.451+00	\N	2026-05-22 18:02:19.858968+00
561d25ff-768d-412e-87f6-9113cbd06ac2	f7dcd701-a2ee-4981-978d-aa64c778f140	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-MKT-CONTENT	0ce307a7c9b1ec9ba61e95054930ceadd73c1351557037850d1f066c9538d316	2026-05-22 21:10:35.833+00	\N	2026-05-22 18:02:19.858968+00
dacaa0c3-3043-4114-99d9-499311bf009e	96cf91f1-f440-4757-81da-b26caf1d9b2d	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-BUG-BOUNTY	f25d059d293ff9af49a34f69b3e18b55bfd284d9242d4f0fc7f8700c7f82369f	\N	\N	2026-05-22 18:02:19.858968+00
a8b0da87-39f3-474c-91fd-c7ac8c394c43	765bdae8-5f6e-45a1-8720-4d564dad87df	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-CEO	a638656d68b52cb4049474cd6dadd4cb11dc4a01ac74dc6b6aefa8021fb75703	\N	\N	2026-05-22 18:02:19.858968+00
9f370fc9-41ba-47a0-97ee-209b6b8518a4	cb4c3d65-ce7f-4a12-95ae-ed3184281b35	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-CPO	3ddc3ae1c64d62d9173cff868841df06fe3f8bee2626afe8190af4a3b52061ef	\N	\N	2026-05-22 18:02:19.858968+00
5fc4cfa9-4358-419f-b6de-fa42eacac82b	9d2511ee-14ed-4c94-8e79-104a1c7af398	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-CRO	7b563945ac64877a78a090740f91e220f6712ca73ff779b04cc40ff22b10df18	\N	\N	2026-05-22 18:02:19.858968+00
ae5af2e2-2ccb-47fb-a92c-6f99b87ede9a	efbb9050-2f00-4d68-b753-707a75b2dc90	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-CTO	1c47c3850c424cc21ab47803bb9a514866f627dfcc19932361de17cb743a14c4	\N	\N	2026-05-22 18:02:19.858968+00
28a2608b-4620-49d8-8d59-69269f83fd35	8207dd61-9518-4e77-b41a-a356904dd507	a24e39b2-2ede-4aec-9471-248458a381fc	cortex-MKT-CREATIVE	d750fb87ec868e59cc7fb32b3e9bddbd64cdd97a518495c6a3da581489295e1a	2026-05-22 21:10:43.014+00	\N	2026-05-22 18:02:19.858968+00
df139ca9-f232-4d31-9d9e-fa14c88d5a8f	be4a3e5b-c754-467b-99ba-06dfac2a77f6	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-ENG-API	5eb4b91aadd9205f160bcdee6a85dbee2da2e39be2fc1ccfe6e2dfbf969d8be4	\N	\N	2026-05-22 18:02:19.858968+00
02a5fcb6-1d95-4d38-a492-cadd92382588	1b025a48-e543-456d-9619-b4b4d9281574	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-ENG-RN-ANDROID	cfa47f2058bd3b3a076687624a5829f72836d6f26bf20c58d29c2bad9e8e07f9	\N	\N	2026-05-22 18:02:19.858968+00
34f95bbe-0230-44f2-9695-cea58e0afbb8	95dd975b-0ad3-4de4-a5b3-1b1aaa83b3c7	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-ENG-RN-IOS	a6694a91e49cd566885761a63c1049c3a0ae03f789ae34e07214b9b29c2c8cc4	\N	\N	2026-05-22 18:02:19.858968+00
6eb4eb33-dc68-4932-a522-5152695c7dc8	44db3c4b-0ea8-4fcb-863c-32bf228949f9	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-ENG-WEB-FRONTEND	e952acf4ea9784ca86b69bdec0f46478587891810ff24d7bdcb2400193142fde	\N	\N	2026-05-22 18:02:19.858968+00
2974d0ac-da79-4545-b0ce-4b022ab622f0	aea0c0af-8e81-448f-93d2-8de16964ec18	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-MKT-CONTENT	89b3fcbcd40d829d7ab0ff7ec26637a70a616ba35e53af024462fa5fbb8232a7	\N	\N	2026-05-22 18:02:19.858968+00
f5edada9-c8f5-4fc6-8568-8105692fe28a	f1b0a00f-699c-4be9-b05f-e074cd8d3242	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-MKT-CREATIVE	3b03d3b4212a10a9c3356ae50b2f8431f55e9a728aaf28db0ace5e01b7faba9d	\N	\N	2026-05-22 18:02:19.858968+00
78a1dc69-9f81-45b7-a2fc-de519b53a5bf	5167d7b6-eea7-4c2b-94d1-2370c87df803	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-PM	84ecd0a5e1bc7c7d3f0137f741f2560416c1629f2a01b9a1cb39ea1d228744bf	\N	\N	2026-05-22 18:02:19.858968+00
48bd8563-8138-47c4-8b22-cee819d91eea	59c0c0f8-8ff6-4774-8149-fd0b6e26c9ab	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-PO	eebac544ecb34c779180f43aaf7353bb4961a6e831a16fb343ba8eb99279119e	\N	\N	2026-05-22 18:02:19.858968+00
1c1dcd86-1cbb-40e7-92ac-17971eaea55e	9cec2434-4f85-4444-b328-6f4ccf3e47bb	a24e39b2-2ede-4aec-9471-248458a381fc	soldado-gomes-hb	b850206e73d979e585c70925d611b1ad7774c33c8f2fc61b6ad17236a290734a	2026-05-22 16:22:08.108+00	\N	2026-05-22 14:53:45.835761+00
f0f1f9fd-9c76-4b4a-b817-f8e31b0c4a89	9e8a9cf6-3bec-475d-b2a5-b2bd665bf895	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-QA-E2E	0e90f08b850471cff2cf9761d5fd603baf0f68933025b2a9ede18d6e1e721908	\N	\N	2026-05-22 18:02:19.858968+00
994f98bc-ff2d-4ccb-a8ec-74ccf4d8fa92	dac3e5f3-c182-4b8a-b77f-59d1a200a2d6	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-QA-LEAD	2e904b4c94aaf0581db835be57a8899bf18de104e9b746c4cc4c2dc42abcbf50	\N	\N	2026-05-22 18:02:19.858968+00
38f72b08-b23f-41e4-92c4-75a23d445174	36a10f57-9138-43e6-ad8c-9cebfe613ac4	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-QA-UNIT	f4d35d065715645a39e80270e23bdc30e5022ee69243089bc464720de6c00eaf	\N	\N	2026-05-22 18:02:19.858968+00
695568a2-78a3-48ed-b67c-f92b2b0b8020	26c45480-1419-4e69-ad84-6bb2f04ce314	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-REVIEWER	470832e82d8722157bc04663f5bfac4105388ece312ebaca24aca45dada8e61c	\N	\N	2026-05-22 18:02:19.858968+00
335148c6-6995-4d68-8983-3ec246c97a3a	54d7d112-b780-432f-ad73-526c956f3834	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-STAFF-BACKEND	a5fdf4e42eee530e431cd6be650154fa07225208dc49dc1d2d70a84e53a5ece8	\N	\N	2026-05-22 18:02:19.858968+00
bb3e4526-23b3-4369-b343-c4139f7d3480	a95963ea-e171-48a0-9560-5e22c9277b58	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-STAFF-FRONTEND	093e2a158ef1125096332448f79735a082d3bc00a8b6187c3d0d31419c98778c	\N	\N	2026-05-22 18:02:19.858968+00
d2ae89c8-1147-409b-bc74-5a4ba27cbbb0	ec9c5b12-9615-4d24-95ed-38989de2a71d	a163ef00-71bb-4412-8943-c109f58a60a7	cortex-STAFF-RN	6f2a9847ff5089b27d6d23bb520080b8f21a0e3e530c303a407d45d18c956742	\N	\N	2026-05-22 18:02:19.858968+00
\.


--
-- Data for Name: agent_config_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_config_revisions (id, company_id, agent_id, created_by_agent_id, created_by_user_id, source, rolled_back_from_revision_id, changed_keys, before_config, after_config, created_at) FROM stdin;
\.


--
-- Data for Name: agent_runtime_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_runtime_state (agent_id, company_id, adapter_type, session_id, state_json, last_run_id, last_run_status, total_input_tokens, total_output_tokens, total_cached_input_tokens, total_cost_cents, last_error, created_at, updated_at) FROM stdin;
e9ebf6bb-cd87-459e-9b08-20743bb9b3eb	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	8bd78826-847f-418e-b95a-bf544b1daf82	succeeded	0	0	0	0	\N	2026-05-22 15:06:03.852338+00	2026-05-22 22:34:53.131+00
576ecd91-110d-4b26-be9b-711f5ec15a82	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	2eac1cd1-c6b7-4b75-bcb5-fff5a515215b	succeeded	0	0	0	0	\N	2026-05-22 14:51:03.89757+00	2026-05-22 22:35:18.142+00
04773188-742c-4eb0-af4a-9af30eff6436	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	9a4f96ed-9949-4b80-ae19-ae65212672cc	succeeded	0	0	0	0	\N	2026-05-22 14:22:51.408532+00	2026-05-22 22:35:43.128+00
55428e1c-6601-413e-90b1-d1e528dfa77d	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	808f8385-eb95-4646-ba6d-84619655b90f	succeeded	0	0	0	0	\N	2026-05-22 14:51:03.812059+00	2026-05-22 22:35:49.392+00
9cec2434-4f85-4444-b328-6f4ccf3e47bb	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	8cd2940f-fbe9-45cf-a772-1994cef44edd	succeeded	0	0	0	0	\N	2026-05-22 15:06:04.894561+00	2026-05-22 22:36:08.145+00
06d67702-d4af-48c8-81a4-10a7fb5f3374	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	c74d7e9b-e89f-4087-9d2d-811d34aff636	succeeded	0	0	0	0	\N	2026-05-22 15:06:03.899946+00	2026-05-22 22:36:14.371+00
765bdae8-5f6e-45a1-8720-4d564dad87df	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	8ef205e1-92fc-4cf8-89d3-568a0bf6805a	succeeded	0	0	0	0	\N	2026-05-22 05:29:51.144542+00	2026-05-22 22:36:20.648+00
efbb9050-2f00-4d68-b753-707a75b2dc90	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	20d22ae5-53df-4cf0-b4d9-45fcc4587769	succeeded	0	0	0	0	\N	2026-05-22 14:51:04.394907+00	2026-05-22 22:36:26.846+00
1b025a48-e543-456d-9619-b4b4d9281574	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	14ba9a9d-e11e-40a1-aa09-9717133f9eba	succeeded	0	0	0	0	\N	2026-05-22 15:06:03.815386+00	2026-05-22 22:36:39.45+00
44db3c4b-0ea8-4fcb-863c-32bf228949f9	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	bfe589f7-2a89-48d8-841e-fa525fc9345f	succeeded	0	0	0	0	\N	2026-05-22 15:06:04.349386+00	2026-05-22 22:36:45.657+00
be4a3e5b-c754-467b-99ba-06dfac2a77f6	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	d6394757-1b20-4197-a6cb-f515ad0276ac	succeeded	0	0	0	0	\N	2026-05-22 15:06:04.415284+00	2026-05-22 22:37:04.389+00
95dd975b-0ad3-4de4-a5b3-1b1aaa83b3c7	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	0e1a0183-7fb7-4b44-a818-575d055ab438	succeeded	0	0	0	0	\N	2026-05-22 15:06:03.693851+00	2026-05-22 22:37:29.362+00
a0e40b7d-50d8-4825-863a-bb07da88219e	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	bfbb16e2-1da1-4b6e-8cb6-12148eca55de	cancelled	0	0	0	0	\N	2026-05-22 14:51:04.610008+00	2026-05-22 17:44:07.921+00
26c45480-1419-4e69-ad84-6bb2f04ce314	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	10cdf99a-dc88-414c-af76-1c38c1d8adcc	succeeded	0	0	0	0	\N	2026-05-22 14:51:04.726465+00	2026-05-22 22:37:35.629+00
59c0c0f8-8ff6-4774-8149-fd0b6e26c9ab	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	d126134f-c7aa-4720-ab5a-da61a82b75d4	succeeded	0	0	0	0	\N	2026-05-22 14:51:04.521768+00	2026-05-22 22:38:00.638+00
5167d7b6-eea7-4c2b-94d1-2370c87df803	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	df62a2de-a10d-4160-9f80-9614172b9dce	succeeded	0	0	0	0	\N	2026-05-22 14:51:04.451725+00	2026-05-22 22:38:06.928+00
36a10f57-9138-43e6-ad8c-9cebfe613ac4	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	23b88a37-7aba-4c4c-b003-6122cb118a48	succeeded	0	0	0	0	\N	2026-05-22 15:06:04.613679+00	2026-05-22 22:38:19.453+00
9e8a9cf6-3bec-475d-b2a5-b2bd665bf895	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	8b83e336-769a-47fe-ab77-90c02abc8aac	succeeded	0	0	0	0	\N	2026-05-22 15:06:05.463344+00	2026-05-22 22:38:25.692+00
06156af6-c717-462e-bc56-ed7d2a688393	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	2e93b383-6ce9-45c5-ab43-1bcdfd0d383d	succeeded	0	0	0	0	\N	2026-05-22 14:51:03.726921+00	2026-05-25 01:31:05.773+00
544b475d-754e-4196-85fe-cac25e2392ed	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	ed805ea5-b13b-419c-a739-1deb5e52f2ee	succeeded	0	0	0	0	\N	2026-05-22 05:29:50.383158+00	2026-05-22 22:31:45.328+00
53ef54cf-6db8-4286-9462-30fff6187413	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	2df4449d-6b00-4edd-8e20-66ffcda87eb7	succeeded	0	0	0	0	\N	2026-05-22 14:51:03.973787+00	2026-05-22 22:31:51.526+00
a3663b65-90db-4964-88ae-e1185b8c4bd6	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	26e6cfbf-2564-486e-907e-2f6431d329a4	succeeded	0	0	0	0	\N	2026-05-22 20:51:07.709641+00	2026-05-22 22:31:57.774+00
42e0f410-e62a-4b4b-8aaf-23704301b4af	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	ceef92ae-4046-452b-aac6-832a6579d46e	succeeded	0	0	0	0	\N	2026-05-22 20:51:04.98588+00	2026-05-22 22:32:03.951+00
b3befd4b-9c97-4d9c-ba70-27387493e4a4	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	0340e7b9-ff95-4156-af07-aadbffafeb3a	succeeded	0	0	0	0	\N	2026-05-22 15:06:04.099256+00	2026-05-22 22:32:10.268+00
0ef004dc-d7f4-459d-85f3-4c73b4008961	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	91249355-cfb1-4cc0-aabe-b689e58e6202	succeeded	0	0	0	0	\N	2026-05-22 20:51:04.852557+00	2026-05-22 22:32:16.513+00
00922a3c-6ab1-4db1-9a49-7f669af81343	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	d92d6aa9-9648-474b-b803-1af1b6e19b8b	succeeded	0	0	0	0	\N	2026-05-22 20:51:05.584767+00	2026-05-22 22:32:22.797+00
c2811a02-1ab3-4caf-873c-c60bfcaf209c	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	f2e5a96e-f52d-4814-807b-17d04f657b0c	succeeded	0	0	0	0	\N	2026-05-22 15:06:05.213759+00	2026-05-22 22:32:35.304+00
3fe44f46-ad69-4c57-bacb-47736ab288f5	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	1f8806a7-739d-4112-98f4-1aa9fe7c9ac6	succeeded	0	0	0	0	\N	2026-05-22 15:06:05.025807+00	2026-05-22 22:32:41.632+00
2ed62f71-2618-4cb9-98ff-21bd4602e5e0	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	cafde7fd-fb19-4934-aa59-c4365417ea35	succeeded	0	0	0	0	\N	2026-05-22 20:51:05.213883+00	2026-05-22 22:32:47.907+00
8d8a5ee1-ebe5-465e-8a18-b17b815ecb60	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	65ab0f8c-9c51-4652-9f6c-f154f1d3a193	succeeded	0	0	0	0	\N	2026-05-22 20:51:04.930559+00	2026-05-22 22:32:54.23+00
8779a527-cc95-442f-a81e-dc567c0cdca0	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	abdb2e6f-0ee7-4d2f-9fc1-4cd34f6dfb7c	succeeded	0	0	0	0	\N	2026-05-22 20:51:07.290132+00	2026-05-22 22:33:00.438+00
bf5603f8-b958-4285-88d1-3cea52b185c9	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	e8239407-2584-4fe3-b095-f1d57a769b74	succeeded	0	0	0	0	\N	2026-05-22 20:51:04.53915+00	2026-05-22 22:33:06.731+00
ccc347d1-0bb9-415f-aba8-83c6821e9707	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	38aeec21-e5e8-4a20-b4a1-a810145829ba	succeeded	0	0	0	0	\N	2026-05-22 14:51:03.859661+00	2026-05-22 17:35:00.393+00
41f88289-d847-49a9-a8c8-df92b8b35fa8	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	0ffe6d60-987d-44c8-b826-8784580cc2db	succeeded	0	0	0	0	\N	2026-05-22 14:51:04.29542+00	2026-05-22 22:33:19.305+00
4553dc21-74a8-4931-8256-da655fef241a	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	89d0ec81-7139-49e2-ab7c-14d2b3552774	succeeded	0	0	0	0	\N	2026-05-22 20:51:04.483027+00	2026-05-22 22:33:25.534+00
bac15efd-14e4-439e-9567-afd6356bcf39	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	b611fee7-d846-4552-9588-e160966cb301	succeeded	0	0	0	0	\N	2026-05-22 14:51:04.236239+00	2026-05-22 17:37:42.35+00
7fdcaea2-71c6-4791-8b28-570f871c8060	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	85a76cca-2fe1-4dc4-aac2-9261544a0d45	succeeded	0	0	0	0	\N	2026-05-22 14:51:04.017641+00	2026-05-22 22:33:31.764+00
64ed9716-6ce3-4747-b534-de1c23208bb1	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	36328ef4-6e49-4c11-b94c-812901ad8400	succeeded	0	0	0	0	\N	2026-05-22 14:51:04.124439+00	2026-05-22 22:33:38.038+00
a221acf0-0b12-4d78-940d-9a3061905bbc	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	298018e2-aad3-446a-94c6-764b616d38d0	succeeded	0	0	0	0	\N	2026-05-22 15:06:04.28897+00	2026-05-22 22:33:44.329+00
bef94c85-6d32-4deb-afda-fb5c13584038	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	0267a6c6-0d91-45ff-9d28-82cba1ec6f24	succeeded	0	0	0	0	\N	2026-05-22 15:06:04.219731+00	2026-05-22 22:33:50.59+00
86070506-d7cf-4f79-9dab-4b526e8db6a3	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	c5e9ea67-80ab-4c64-9a61-16cf90a10deb	succeeded	0	0	0	0	\N	2026-05-22 20:51:06.30595+00	2026-05-22 22:33:56.838+00
d46aa59f-a0b7-4850-8741-5c8e284b9e1c	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	0b55e43f-c297-40c0-a4c0-f6ec05ebc762	succeeded	0	0	0	0	\N	2026-05-22 13:59:29.27259+00	2026-05-22 22:34:03.154+00
1a85a4a4-d61a-48f8-9f58-4373fd00b9f7	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	30416302-7175-4581-93ec-04ee64ae246f	succeeded	0	0	0	0	\N	2026-05-22 15:06:04.775915+00	2026-05-22 22:34:21.962+00
bfc1f97a-29ca-461d-8941-c0ce28151bd0	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	6b2d48c6-b764-4f9e-bbce-bbe3cdde6812	succeeded	0	0	0	0	\N	2026-05-22 15:06:03.735825+00	2026-05-22 22:34:28.203+00
b5016599-e2a6-4d6b-8573-876c769a27ab	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	c4e5bd09-2b46-4a8a-acb0-aeb277267e80	succeeded	0	0	0	0	\N	2026-05-22 15:06:03.775818+00	2026-05-22 22:34:46.862+00
f7dcd701-a2ee-4981-978d-aa64c778f140	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	57af49e6-7cd6-4165-b5dc-1688f9a6a7d0	succeeded	0	0	0	0	\N	2026-05-22 20:51:32.207223+00	2026-05-22 22:35:36.896+00
9794edb5-d5be-41f9-b600-212ac10a8a8b	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	485de803-372e-4216-a6da-fe32115804ac	succeeded	0	0	0	0	\N	2026-05-22 20:51:07.909726+00	2026-05-22 22:33:13.003+00
08211152-aaca-4d3a-9b6e-9e8ee8e85665	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	13d68522-714a-4e29-8c2f-ac77188b7a61	succeeded	0	0	0	0	\N	2026-05-22 20:51:30.051498+00	2026-05-22 22:36:01.847+00
ec9c5b12-9615-4d24-95ed-38989de2a71d	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	c42f08d9-b927-4bb4-9312-c3e7c11537f5	succeeded	0	0	0	0	\N	2026-05-22 20:51:13.099792+00	2026-05-22 22:37:16.873+00
cb4c3d65-ce7f-4a12-95ae-ed3184281b35	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	6999188c-605b-4281-9e37-59a7e38a3376	succeeded	0	0	0	0	\N	2026-05-22 20:51:09.712113+00	2026-05-22 22:38:13.183+00
8207dd61-9518-4e77-b41a-a356904dd507	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	77e3a7a5-926d-4799-a265-d0c984c206be	succeeded	0	0	0	0	\N	2026-05-22 20:51:32.725863+00	2026-05-22 22:34:15.71+00
8f8c7a52-3eff-4129-a412-7d483d26d493	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	217ff627-f65f-42a6-b0e1-dc2258e1b59b	succeeded	0	0	0	0	\N	2026-05-22 20:51:25.828105+00	2026-05-22 22:35:11.885+00
4181a8e7-13c0-46f9-a30e-be8efde4d7cf	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	70d553e4-73d8-4b21-99cd-457776fa5468	succeeded	0	0	0	0	\N	2026-05-22 20:51:14.170423+00	2026-05-22 22:36:51.904+00
9d2511ee-14ed-4c94-8e79-104a1c7af398	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	98c10cfb-f65b-46b8-ac28-dc0d7c9d1de3	succeeded	0	0	0	0	\N	2026-05-22 20:51:09.950582+00	2026-05-22 22:37:48.173+00
bd2e77f4-7d34-45e1-bef7-9183831bc851	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	a84ce2b0-bbb3-415e-a417-c06b7b3305ea	succeeded	0	0	0	0	\N	2026-05-22 20:51:27.439091+00	2026-05-22 22:34:40.66+00
a95963ea-e171-48a0-9560-5e22c9277b58	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	3b1a195f-d9b2-4f75-80c9-3d2b2532a85a	succeeded	0	0	0	0	\N	2026-05-22 20:51:11.893471+00	2026-05-22 22:37:10.605+00
54d7d112-b780-432f-ad73-526c956f3834	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	e85b097a-efef-44d9-a0f4-0645dfbcb0ad	succeeded	0	0	0	0	\N	2026-05-22 20:51:12.574823+00	2026-05-22 22:37:23.133+00
96cf91f1-f440-4757-81da-b26caf1d9b2d	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	4fe25e4a-7897-408c-bb90-33ab44d4866f	succeeded	0	0	0	0	\N	2026-05-22 20:51:37.483509+00	2026-05-22 22:37:41.906+00
aea0c0af-8e81-448f-93d2-8de16964ec18	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	e7b85961-a277-4937-836e-2971671be5c5	succeeded	0	0	0	0	\N	2026-05-22 20:51:36.006841+00	2026-05-22 22:37:54.369+00
90e98495-824e-4ba5-a9cd-df2bd087ee32	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	514300c8-c909-4e59-ac8a-24ecf3e9d211	succeeded	0	0	0	0	\N	2026-05-22 20:51:15.135555+00	2026-05-22 22:36:58.136+00
6aebb64e-38a8-473a-8df3-bcc25824fb7d	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	f2f5ca66-c279-4e1f-9bb1-8f9b3569bb9d	succeeded	0	0	0	0	\N	2026-05-22 20:51:28.534375+00	2026-05-22 22:34:34.467+00
26fd450c-04e0-408d-b883-e1efd15dc4d4	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	ee9be8c2-44ca-4af1-98e0-05377fce4777	succeeded	0	0	0	0	\N	2026-05-22 20:51:24.214043+00	2026-05-22 22:35:05.607+00
07dc95a8-a84a-4a74-9318-740cfdd38866	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	3f43bff9-0321-4d08-9454-ad41b0d66cc1	succeeded	0	0	0	0	\N	2026-05-22 20:51:33.678164+00	2026-05-22 22:35:30.667+00
46f7de29-8442-48c5-9060-3012b17428e7	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	c3bbdaec-9721-4f73-aa5d-fa7fa15c8641	succeeded	0	0	0	0	\N	2026-05-22 20:51:19.419802+00	2026-05-22 22:35:55.646+00
f1b0a00f-699c-4be9-b05f-e074cd8d3242	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	863d4b4d-2dab-4b5f-a3fa-9fcef0942f25	succeeded	0	0	0	0	\N	2026-05-22 20:51:36.874755+00	2026-05-22 22:36:33.23+00
dac3e5f3-c182-4b8a-b77f-59d1a200a2d6	a163ef00-71bb-4412-8943-c109f58a60a7	hermes_local	\N	{}	c3be9ae9-11db-423a-98eb-a92104478b55	succeeded	0	0	0	0	\N	2026-05-22 20:51:16.895768+00	2026-05-22 22:38:31.948+00
7cf8f19c-28e7-4b88-b24a-4c2626054c1b	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	4fa94a8d-94c8-4c22-b2db-a25d10334fcf	succeeded	0	0	0	0	\N	2026-05-22 20:51:20.115857+00	2026-05-22 22:35:24.463+00
231e9903-7d58-4eb0-91dd-b0507fe25e3f	0b96ba9b-87c5-4e69-89ca-188782d40d5f	hermes_local	\N	{}	a92af047-70c2-4941-b061-a1908fd2a837	succeeded	0	0	0	0	\N	2026-05-22 15:06:03.945887+00	2026-05-22 22:32:28.999+00
b348b5be-d356-4428-8138-c595b15bd58a	a24e39b2-2ede-4aec-9471-248458a381fc	hermes_local	\N	{}	643e1b95-66d4-4da4-af9e-76eac84389f5	succeeded	0	0	0	0	\N	2026-05-22 20:51:25.070218+00	2026-05-22 22:34:59.388+00
\.


--
-- Data for Name: agent_task_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_task_sessions (id, company_id, agent_id, adapter_type, task_key, session_params_json, session_display_id, last_run_id, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_wakeup_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_wakeup_requests (id, company_id, agent_id, source, trigger_detail, reason, payload, status, coalesced_count, requested_by_actor_type, requested_by_actor_id, idempotency_key, run_id, requested_at, claimed_at, finished_at, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agents (id, company_id, name, role, title, status, reports_to, capabilities, adapter_type, adapter_config, budget_monthly_cents, spent_monthly_cents, last_heartbeat_at, metadata, created_at, updated_at, runtime_config, permissions, icon, pause_reason, paused_at, default_environment_id) FROM stdin;
a3663b65-90db-4964-88ae-e1185b8c4bd6	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Aquarela Torres	designer	Marketing Creative Specialist	idle	bf5603f8-b958-4285-88d1-3cea52b185c9	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:MKT-CREATIVE:{{issueId}}"}	15000	0	2026-05-22 22:31:57.78+00	{"boss": "CRO", "routine": "0 */15 * * * *", "cortexRole": "MKT-CREATIVE", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:31:57.78+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
4553dc21-74a8-4931-8256-da655fef241a	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Dona Flor	pm	Chief Product Officer	idle	544b475d-754e-4196-85fe-cac25e2392ed	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:CPO:{{issueId}}"}	30000	0	2026-05-22 22:33:25.539+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CPO", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:33:25.539+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
d46aa59f-a0b7-4850-8741-5c8e284b9e1c	a24e39b2-2ede-4aec-9471-248458a381fc	Coronel Marcos	ceo	Chief Executive Officer	idle	\N	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cc/claude-opus-4-7", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "3guns:CEO:{{issueId}}"}	0	0	2026-05-22 22:34:03.158+00	{"boss": "none", "routine": "0 */15 * * * *", "cortexRole": "CEO", "companyPrefix": "GUN"}	2026-05-22 13:54:41.223742+00	2026-05-22 22:34:03.158+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
06156af6-c717-462e-bc56-ed7d2a688393	a24e39b2-2ede-4aec-9471-248458a381fc	Major Duarte	cto	Chief Technology Officer	idle	d46aa59f-a0b7-4850-8741-5c8e284b9e1c	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "3guns:CTO:{{issueId}}"}	0	0	2026-05-25 01:31:05.782+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CTO", "companyPrefix": "GUN"}	2026-05-22 13:54:41.241225+00	2026-05-25 01:31:05.782+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
42e0f410-e62a-4b4b-8aaf-23704301b4af	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Araci Nunes	engineer	Staff React Native Engineer	idle	53ef54cf-6db8-4286-9462-30fff6187413	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "celebrar:STAFF-RN:{{issueId}}"}	30000	0	2026-05-22 22:32:03.954+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-RN", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:32:03.954+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
8d8a5ee1-ebe5-465e-8a18-b17b815ecb60	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Vitória Guaracy	engineer	Staff Backend Engineer	idle	53ef54cf-6db8-4286-9462-30fff6187413	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "celebrar:STAFF-BACKEND:{{issueId}}"}	30000	0	2026-05-22 22:32:54.236+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-BACKEND", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:32:54.236+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
8207dd61-9518-4e77-b41a-a356904dd507	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Nascimento	designer	Marketing Creative Specialist	idle	7cf8f19c-28e7-4b88-b24a-4c2626054c1b	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:MKT-CREATIVE:{{issueId}}"}	15000	0	2026-05-22 22:34:15.715+00	{"boss": "CRO", "routine": "0 */15 * * * *", "cortexRole": "MKT-CREATIVE", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:34:15.715+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
bfc1f97a-29ca-461d-8941-c0ce28151bd0	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Martins	engineer	RN iOS Engineer	idle	8f8c7a52-3eff-4129-a412-7d483d26d493	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:ENG-RN-IOS:{{issueId}}"}	20000	0	2026-05-22 22:34:28.208+00	{"boss": "STAFF-RN", "routine": "0 */15 * * * *", "cortexRole": "ENG-RN-IOS", "companyPrefix": "GUN"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:34:28.208+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
6aebb64e-38a8-473a-8df3-bcc25824fb7d	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Monteiro	engineer	API Engineer II	idle	b348b5be-d356-4428-8138-c595b15bd58a	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:ENG-API-2:{{issueId}}"}	20000	0	2026-05-22 22:34:34.473+00	{"boss": "STAFF-BACKEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-API-2", "companyPrefix": "GUN"}	2026-05-22 18:22:20.146586+00	2026-05-22 22:34:34.473+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
9794edb5-d5be-41f9-b600-212ac10a8a8b	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Onça Pintada	general	External Bug Bounty Bot	idle	53ef54cf-6db8-4286-9462-30fff6187413	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "minimax/MiniMax-M2.7-highspeed", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "minimax/MiniMax-M2.7-highspeed", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:BUG-BOUNTY:{{issueId}}"}	10000	0	2026-05-22 22:33:13.008+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "BUG-BOUNTY", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:33:13.008+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
a221acf0-0b12-4d78-940d-9a3061905bbc	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Anhangá Freitas	qa	QA Unit Test Engineer	idle	86070506-d7cf-4f79-9dab-4b526e8db6a3	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:QA-UNIT:{{issueId}}"}	10000	0	2026-05-22 22:33:44.335+00	{"boss": "QA-LEAD", "routine": "0 */15 * * * *", "cortexRole": "QA-UNIT", "companyPrefix": "CLB"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:33:44.335+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
bd2e77f4-7d34-45e1-bef7-9183831bc851	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Ribeiro	engineer	Web Frontend Engineer II	idle	26fd450c-04e0-408d-b883-e1efd15dc4d4	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:ENG-WEB-FRONTEND-2:{{issueId}}"}	20000	0	2026-05-22 22:34:40.665+00	{"boss": "STAFF-FRONTEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-WEB-FRONTEND-2", "companyPrefix": "GUN"}	2026-05-22 18:22:20.146586+00	2026-05-22 22:34:40.665+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
86070506-d7cf-4f79-9dab-4b526e8db6a3	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Jaciara Melo	qa	QA Lead	idle	53ef54cf-6db8-4286-9462-30fff6187413	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:QA-LEAD:{{issueId}}"}	20000	0	2026-05-22 22:33:56.843+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "QA-LEAD", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:33:56.843+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
1a85a4a4-d61a-48f8-9f58-4373fd00b9f7	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Cardoso	engineer	RN Android Engineer	idle	8f8c7a52-3eff-4129-a412-7d483d26d493	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:ENG-RN-ANDROID:{{issueId}}"}	20000	0	2026-05-22 22:34:21.965+00	{"boss": "STAFF-RN", "routine": "0 */15 * * * *", "cortexRole": "ENG-RN-ANDROID", "companyPrefix": "GUN"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:34:21.965+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
b5016599-e2a6-4d6b-8573-876c769a27ab	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Rocha	engineer	API Engineer	idle	b348b5be-d356-4428-8138-c595b15bd58a	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:ENG-API:{{issueId}}"}	20000	0	2026-05-22 22:34:46.867+00	{"boss": "STAFF-BACKEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-API", "companyPrefix": "GUN"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:34:46.867+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
e9ebf6bb-cd87-459e-9b08-20743bb9b3eb	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Tavares	engineer	Web Frontend Engineer	idle	26fd450c-04e0-408d-b883-e1efd15dc4d4	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:ENG-WEB-FRONTEND:{{issueId}}"}	20000	0	2026-05-22 22:34:53.136+00	{"boss": "STAFF-FRONTEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-WEB-FRONTEND", "companyPrefix": "GUN"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:34:53.136+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
b348b5be-d356-4428-8138-c595b15bd58a	a24e39b2-2ede-4aec-9471-248458a381fc	Subtenente Batista	engineer	Staff Backend Engineer	idle	06156af6-c717-462e-bc56-ed7d2a688393	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "3guns:STAFF-BACKEND:{{issueId}}"}	30000	0	2026-05-22 22:34:59.397+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-BACKEND", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:34:59.397+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
8f8c7a52-3eff-4129-a412-7d483d26d493	a24e39b2-2ede-4aec-9471-248458a381fc	Subtenente Moura	engineer	Staff React Native Engineer	idle	06156af6-c717-462e-bc56-ed7d2a688393	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "3guns:STAFF-RN:{{issueId}}"}	30000	0	2026-05-22 22:35:11.892+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-RN", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:35:11.892+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
00922a3c-6ab1-4db1-9a49-7f669af81343	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Cuca Barbosa	engineer	API Engineer II	idle	8d8a5ee1-ebe5-465e-8a18-b17b815ecb60	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:ENG-API-2:{{issueId}}"}	20000	0	2026-05-22 22:32:22.801+00	{"boss": "STAFF-BACKEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-API-2", "companyPrefix": "CLB"}	2026-05-22 18:22:20.146586+00	2026-05-22 22:32:22.801+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
8779a527-cc95-442f-a81e-dc567c0cdca0	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Maracatu Rocha	general	Marketing Content Specialist	idle	bf5603f8-b958-4285-88d1-3cea52b185c9	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:MKT-CONTENT:{{issueId}}"}	15000	0	2026-05-22 22:33:00.441+00	{"boss": "CRO", "routine": "0 */15 * * * *", "cortexRole": "MKT-CONTENT", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:33:00.441+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
2ed62f71-2618-4cb9-98ff-21bd4602e5e0	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Saci Ferreira	engineer	Web Frontend Engineer II	idle	0ef004dc-d7f4-459d-85f3-4c73b4008961	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:ENG-WEB-FRONTEND-2:{{issueId}}"}	20000	0	2026-05-22 22:32:47.912+00	{"boss": "STAFF-FRONTEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-WEB-FRONTEND-2", "companyPrefix": "CLB"}	2026-05-22 18:22:20.146586+00	2026-05-22 22:32:47.912+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
7cf8f19c-28e7-4b88-b24a-4c2626054c1b	a24e39b2-2ede-4aec-9471-248458a381fc	Comandante Nogueira	general	Chief Revenue Officer	idle	d46aa59f-a0b7-4850-8741-5c8e284b9e1c	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:CRO:{{issueId}}"}	30000	0	2026-05-22 22:35:24.47+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CRO", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:35:24.47+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
07dc95a8-a84a-4a74-9318-740cfdd38866	a24e39b2-2ede-4aec-9471-248458a381fc	Observador Águia	general	External Bug Bounty Bot	idle	06156af6-c717-462e-bc56-ed7d2a688393	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "minimax/MiniMax-M2.7-highspeed", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "minimax/MiniMax-M2.7-highspeed", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:BUG-BOUNTY:{{issueId}}"}	10000	0	2026-05-22 22:35:30.673+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "BUG-BOUNTY", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:35:30.673+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
f7dcd701-a2ee-4981-978d-aa64c778f140	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Almeida	general	Marketing Content Specialist	idle	7cf8f19c-28e7-4b88-b24a-4c2626054c1b	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:MKT-CONTENT:{{issueId}}"}	15000	0	2026-05-22 22:35:36.9+00	{"boss": "CRO", "routine": "0 */15 * * * *", "cortexRole": "MKT-CONTENT", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:35:36.9+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
04773188-742c-4eb0-af4a-9af30eff6436	a24e39b2-2ede-4aec-9471-248458a381fc	Capitão Reis	pm	Product Manager	idle	46f7de29-8442-48c5-9060-3012b17428e7	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:PM:{{issueId}}"}	0	0	2026-05-22 22:35:43.134+00	{"boss": "CPO", "routine": "0 */15 * * * *", "cortexRole": "PM", "companyPrefix": "GUN"}	2026-05-22 13:54:41.27283+00	2026-05-22 22:35:43.134+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
55428e1c-6601-413e-90b1-d1e528dfa77d	a24e39b2-2ede-4aec-9471-248458a381fc	Tenente Vieira	pm	Product Owner	idle	46f7de29-8442-48c5-9060-3012b17428e7	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:PO:{{issueId}}"}	0	0	2026-05-22 22:35:49.397+00	{"boss": "CPO", "routine": "0 */15 * * * *", "cortexRole": "PO", "companyPrefix": "GUN"}	2026-05-22 13:54:41.253952+00	2026-05-22 22:35:49.397+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
9cec2434-4f85-4444-b328-6f4ccf3e47bb	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Gomes	qa	QA Unit Test Engineer	idle	08211152-aaca-4d3a-9b6e-9e8ee8e85665	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:QA-UNIT:{{issueId}}"}	10000	0	2026-05-22 22:36:08.15+00	{"boss": "QA-LEAD", "routine": "0 */15 * * * *", "cortexRole": "QA-UNIT", "companyPrefix": "GUN"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:36:08.15+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
06d67702-d4af-48c8-81a4-10a7fb5f3374	a24e39b2-2ede-4aec-9471-248458a381fc	Soldado Pereira	qa	QA E2E Engineer	idle	08211152-aaca-4d3a-9b6e-9e8ee8e85665	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:QA-E2E:{{issueId}}"}	10000	0	2026-05-22 22:36:14.378+00	{"boss": "QA-LEAD", "routine": "0 */15 * * * *", "cortexRole": "QA-E2E", "companyPrefix": "GUN"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:36:14.378+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
f1b0a00f-699c-4be9-b05f-e074cd8d3242	a163ef00-71bb-4412-8943-c109f58a60a7	Canvas Ribeiro	designer	Marketing Creative Specialist	idle	9d2511ee-14ed-4c94-8e79-104a1c7af398	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:MKT-CREATIVE:{{issueId}}"}	15000	0	2026-05-22 22:36:33.236+00	{"boss": "CRO", "routine": "0 */15 * * * *", "cortexRole": "MKT-CREATIVE", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:36:33.236+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
4181a8e7-13c0-46f9-a30e-be8efde4d7cf	a163ef00-71bb-4412-8943-c109f58a60a7	Node Farias	engineer	Web Frontend Engineer II	idle	a95963ea-e171-48a0-9560-5e22c9277b58	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:ENG-WEB-FRONTEND-2:{{issueId}}"}	20000	0	2026-05-22 22:36:51.909+00	{"boss": "STAFF-FRONTEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-WEB-FRONTEND-2", "companyPrefix": "MEM"}	2026-05-22 18:22:20.146586+00	2026-05-22 22:36:51.909+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
90e98495-824e-4ba5-a9cd-df2bd087ee32	a163ef00-71bb-4412-8943-c109f58a60a7	Query Azevedo	engineer	API Engineer II	idle	54d7d112-b780-432f-ad73-526c956f3834	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:ENG-API-2:{{issueId}}"}	20000	0	2026-05-22 22:36:58.143+00	{"boss": "STAFF-BACKEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-API-2", "companyPrefix": "MEM"}	2026-05-22 18:22:20.146586+00	2026-05-22 22:36:58.143+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
be4a3e5b-c754-467b-99ba-06dfac2a77f6	a163ef00-71bb-4412-8943-c109f58a60a7	Query Machado	engineer	API Engineer	idle	54d7d112-b780-432f-ad73-526c956f3834	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:ENG-API:{{issueId}}"}	20000	0	2026-05-22 22:37:04.394+00	{"boss": "STAFF-BACKEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-API", "companyPrefix": "MEM"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:37:04.394+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
ec9c5b12-9615-4d24-95ed-38989de2a71d	a163ef00-71bb-4412-8943-c109f58a60a7	Router Ferraz	engineer	Staff React Native Engineer	idle	efbb9050-2f00-4d68-b753-707a75b2dc90	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "mementry:STAFF-RN:{{issueId}}"}	30000	0	2026-05-22 22:37:16.877+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-RN", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:37:16.877+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
95dd975b-0ad3-4de4-a5b3-1b1aaa83b3c7	a163ef00-71bb-4412-8943-c109f58a60a7	Swift Campos	engineer	RN iOS Engineer	idle	ec9c5b12-9615-4d24-95ed-38989de2a71d	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:ENG-RN-IOS:{{issueId}}"}	20000	0	2026-05-22 22:37:29.366+00	{"boss": "STAFF-RN", "routine": "0 */15 * * * *", "cortexRole": "ENG-RN-IOS", "companyPrefix": "MEM"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:37:29.366+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
ccc347d1-0bb9-415f-aba8-83c6821e9707	a24e39b2-2ede-4aec-9471-248458a381fc	Sargento Alves	engineer	Staff Engineer	terminated	06156af6-c717-462e-bc56-ed7d2a688393	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": 50, "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "3guns:STAFF-ENG:{{issueId}}"}	0	0	2026-05-22 17:35:00.398+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-ENG-RETIRED", "companyPrefix": "GUN"}	2026-05-22 13:54:41.282+00	2026-05-22 18:00:41.632053+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
53ef54cf-6db8-4286-9462-30fff6187413	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Seu Caetano	cto	Chief Technology Officer	idle	544b475d-754e-4196-85fe-cac25e2392ed	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "celebrar:CTO:{{issueId}}"}	0	0	2026-05-22 22:31:51.535+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CTO", "companyPrefix": "CLB"}	2026-05-22 13:54:41.318811+00	2026-05-22 22:31:51.535+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
bf5603f8-b958-4285-88d1-3cea52b185c9	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Mestre Folia	general	Chief Revenue Officer	idle	544b475d-754e-4196-85fe-cac25e2392ed	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:CRO:{{issueId}}"}	30000	0	2026-05-22 22:33:06.735+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CRO", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:33:06.735+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
08211152-aaca-4d3a-9b6e-9e8ee8e85665	a24e39b2-2ede-4aec-9471-248458a381fc	Sargento Costa	qa	QA Lead	idle	06156af6-c717-462e-bc56-ed7d2a688393	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:QA-LEAD:{{issueId}}"}	20000	0	2026-05-22 22:36:01.851+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "QA-LEAD", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:36:01.851+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
765bdae8-5f6e-45a1-8720-4d564dad87df	a163ef00-71bb-4412-8943-c109f58a60a7	Mnemo Vance	ceo	Chief Executive Officer	idle	\N	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cc/claude-opus-4-7", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "mementry:CEO:{{issueId}}"}	0	0	2026-05-22 22:36:20.655+00	{"boss": "none", "routine": "0 */15 * * * *", "cortexRole": "CEO", "companyPrefix": "MEM"}	2026-05-22 05:28:16.102844+00	2026-05-22 22:36:20.655+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
96cf91f1-f440-4757-81da-b26caf1d9b2d	a163ef00-71bb-4412-8943-c109f58a60a7	Null Sentinel	general	External Bug Bounty Bot	idle	efbb9050-2f00-4d68-b753-707a75b2dc90	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "minimax/MiniMax-M2.7-highspeed", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "minimax/MiniMax-M2.7-highspeed", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:BUG-BOUNTY:{{issueId}}"}	10000	0	2026-05-22 22:37:41.913+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "BUG-BOUNTY", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:37:41.913+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
1b025a48-e543-456d-9619-b4b4d9281574	a163ef00-71bb-4412-8943-c109f58a60a7	Gradle Pinto	engineer	RN Android Engineer	idle	ec9c5b12-9615-4d24-95ed-38989de2a71d	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:ENG-RN-ANDROID:{{issueId}}"}	20000	0	2026-05-22 22:36:39.457+00	{"boss": "STAFF-RN", "routine": "0 */15 * * * *", "cortexRole": "ENG-RN-ANDROID", "companyPrefix": "MEM"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:36:39.457+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
bef94c85-6d32-4deb-afda-fb5c13584038	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Curupira Lima	qa	QA E2E Engineer	idle	86070506-d7cf-4f79-9dab-4b526e8db6a3	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:QA-E2E:{{issueId}}"}	10000	0	2026-05-22 22:33:50.596+00	{"boss": "QA-LEAD", "routine": "0 */15 * * * *", "cortexRole": "QA-E2E", "companyPrefix": "CLB"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:33:50.596+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
a95963ea-e171-48a0-9560-5e22c9277b58	a163ef00-71bb-4412-8943-c109f58a60a7	Render Teixeira	engineer	Staff Frontend Engineer	idle	efbb9050-2f00-4d68-b753-707a75b2dc90	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "mementry:STAFF-FRONTEND:{{issueId}}"}	30000	0	2026-05-22 22:37:10.609+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-FRONTEND", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:37:10.609+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
544b475d-754e-4196-85fe-cac25e2392ed	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Dona Aurora	ceo	Chief Executive Officer	idle	\N	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cc/claude-opus-4-7", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "celebrar:CEO:{{issueId}}"}	0	0	2026-05-22 22:31:45.336+00	{"boss": "none", "routine": "0 */15 * * * *", "cortexRole": "CEO", "companyPrefix": "CLB"}	2026-05-22 05:28:16.102844+00	2026-05-22 22:31:45.336+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
0ef004dc-d7f4-459d-85f3-4c73b4008961	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Boto Martins	engineer	Staff Frontend Engineer	idle	53ef54cf-6db8-4286-9462-30fff6187413	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "celebrar:STAFF-FRONTEND:{{issueId}}"}	30000	0	2026-05-22 22:32:16.518+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-FRONTEND", "companyPrefix": "CLB"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:32:16.518+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
64ed9716-6ce3-4747-b534-de1c23208bb1	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Raoni Silva	pm	Product Owner	idle	4553dc21-74a8-4931-8256-da655fef241a	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:PO:{{issueId}}"}	0	0	2026-05-22 22:33:38.042+00	{"boss": "CPO", "routine": "0 */15 * * * *", "cortexRole": "PO", "companyPrefix": "CLB"}	2026-05-22 13:54:41.332372+00	2026-05-22 22:33:38.042+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
9d2511ee-14ed-4c94-8e79-104a1c7af398	a163ef00-71bb-4412-8943-c109f58a60a7	Signal Prado	general	Chief Revenue Officer	idle	765bdae8-5f6e-45a1-8720-4d564dad87df	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:CRO:{{issueId}}"}	30000	0	2026-05-22 22:37:48.181+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CRO", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:37:48.181+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
231e9903-7d58-4eb0-91dd-b0507fe25e3f	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Cuca Oliveira	engineer	API Engineer	idle	8d8a5ee1-ebe5-465e-8a18-b17b815ecb60	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:ENG-API:{{issueId}}"}	20000	0	2026-05-22 22:32:29.001+00	{"boss": "STAFF-BACKEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-API", "companyPrefix": "CLB"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:32:29.001+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
59c0c0f8-8ff6-4774-8149-fd0b6e26c9ab	a163ef00-71bb-4412-8943-c109f58a60a7	Epoch Duarte	pm	Product Owner	idle	cb4c3d65-ce7f-4a12-95ae-ed3184281b35	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:PO:{{issueId}}"}	0	0	2026-05-22 22:38:00.643+00	{"boss": "CPO", "routine": "0 */15 * * * *", "cortexRole": "PO", "companyPrefix": "MEM"}	2026-05-22 13:54:41.395346+00	2026-05-22 22:38:00.643+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
5167d7b6-eea7-4c2b-94d1-2370c87df803	a163ef00-71bb-4412-8943-c109f58a60a7	Pixel Nunes	pm	Product Manager	idle	cb4c3d65-ce7f-4a12-95ae-ed3184281b35	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:PM:{{issueId}}"}	0	0	2026-05-22 22:38:06.932+00	{"boss": "CPO", "routine": "0 */15 * * * *", "cortexRole": "PM", "companyPrefix": "MEM"}	2026-05-22 13:54:41.38845+00	2026-05-22 22:38:06.932+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
cb4c3d65-ce7f-4a12-95ae-ed3184281b35	a163ef00-71bb-4412-8943-c109f58a60a7	Vector Maia	pm	Chief Product Officer	idle	765bdae8-5f6e-45a1-8720-4d564dad87df	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:CPO:{{issueId}}"}	30000	0	2026-05-22 22:38:13.187+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CPO", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:38:13.187+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
46f7de29-8442-48c5-9060-3012b17428e7	a24e39b2-2ede-4aec-9471-248458a381fc	Tenente-Coronel Barros	pm	Chief Product Officer	idle	d46aa59f-a0b7-4850-8741-5c8e284b9e1c	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:CPO:{{issueId}}"}	30000	0	2026-05-22 22:35:55.65+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CPO", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:35:55.65+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
36a10f57-9138-43e6-ad8c-9cebfe613ac4	a163ef00-71bb-4412-8943-c109f58a60a7	Assert Ramos	qa	QA Unit Test Engineer	idle	dac3e5f3-c182-4b8a-b77f-59d1a200a2d6	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:QA-UNIT:{{issueId}}"}	10000	0	2026-05-22 22:38:19.457+00	{"boss": "QA-LEAD", "routine": "0 */15 * * * *", "cortexRole": "QA-UNIT", "companyPrefix": "MEM"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:38:19.457+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
44db3c4b-0ea8-4fcb-863c-32bf228949f9	a163ef00-71bb-4412-8943-c109f58a60a7	Node Araújo	engineer	Web Frontend Engineer	idle	a95963ea-e171-48a0-9560-5e22c9277b58	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:ENG-WEB-FRONTEND:{{issueId}}"}	20000	0	2026-05-22 22:36:45.662+00	{"boss": "STAFF-FRONTEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-WEB-FRONTEND", "companyPrefix": "MEM"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:36:45.662+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
54d7d112-b780-432f-ad73-526c956f3834	a163ef00-71bb-4412-8943-c109f58a60a7	Schema Barros	engineer	Staff Backend Engineer	idle	efbb9050-2f00-4d68-b753-707a75b2dc90	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "mementry:STAFF-BACKEND:{{issueId}}"}	30000	0	2026-05-22 22:37:23.138+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-BACKEND", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:37:23.138+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
efbb9050-2f00-4d68-b753-707a75b2dc90	a163ef00-71bb-4412-8943-c109f58a60a7	Cache Torres	cto	Chief Technology Officer	idle	765bdae8-5f6e-45a1-8720-4d564dad87df	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "mementry:CTO:{{issueId}}"}	0	0	2026-05-22 22:36:26.854+00	{"boss": "CEO", "routine": "0 */15 * * * *", "cortexRole": "CTO", "companyPrefix": "MEM"}	2026-05-22 13:54:41.381811+00	2026-05-22 22:36:26.854+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
26fd450c-04e0-408d-b883-e1efd15dc4d4	a24e39b2-2ede-4aec-9471-248458a381fc	Subtenente Lima	engineer	Staff Frontend Engineer	idle	06156af6-c717-462e-bc56-ed7d2a688393	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "3guns:STAFF-FRONTEND:{{issueId}}"}	30000	0	2026-05-22 22:35:05.611+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-FRONTEND", "companyPrefix": "GUN"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:35:05.611+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
3fe44f46-ad69-4c57-bacb-47736ab288f5	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Saci Costa	engineer	Web Frontend Engineer	idle	0ef004dc-d7f4-459d-85f3-4c73b4008961	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:ENG-WEB-FRONTEND:{{issueId}}"}	20000	0	2026-05-22 22:32:41.638+00	{"boss": "STAFF-FRONTEND", "routine": "0 */15 * * * *", "cortexRole": "ENG-WEB-FRONTEND", "companyPrefix": "CLB"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:32:41.638+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
b3befd4b-9c97-4d9c-ba70-27387493e4a4	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Boitatá Souza	engineer	RN Android Engineer	idle	42e0f410-e62a-4b4b-8aaf-23704301b4af	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:ENG-RN-ANDROID:{{issueId}}"}	20000	0	2026-05-22 22:32:10.272+00	{"boss": "STAFF-RN", "routine": "0 */15 * * * *", "cortexRole": "ENG-RN-ANDROID", "companyPrefix": "CLB"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:32:10.272+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
c2811a02-1ab3-4caf-873c-c60bfcaf209c	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Jurema Dias	engineer	RN iOS Engineer	idle	42e0f410-e62a-4b4b-8aaf-23704301b4af	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "kimi/kimi-k2.6", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "kimi/kimi-k2.6", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:ENG-RN-IOS:{{issueId}}"}	20000	0	2026-05-22 22:32:35.309+00	{"boss": "STAFF-RN", "routine": "0 */15 * * * *", "cortexRole": "ENG-RN-IOS", "companyPrefix": "CLB"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:32:35.309+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
aea0c0af-8e81-448f-93d2-8de16964ec18	a163ef00-71bb-4412-8943-c109f58a60a7	Story Valença	general	Marketing Content Specialist	idle	9d2511ee-14ed-4c94-8e79-104a1c7af398	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:MKT-CONTENT:{{issueId}}"}	15000	0	2026-05-22 22:37:54.373+00	{"boss": "CRO", "routine": "0 */15 * * * *", "cortexRole": "MKT-CONTENT", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:37:54.373+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
dac3e5f3-c182-4b8a-b77f-59d1a200a2d6	a163ef00-71bb-4412-8943-c109f58a60a7	Probe Carvalho	qa	QA Lead	idle	efbb9050-2f00-4d68-b753-707a75b2dc90	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:QA-LEAD:{{issueId}}"}	20000	0	2026-05-22 22:38:31.953+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "QA-LEAD", "companyPrefix": "MEM"}	2026-05-22 18:00:41.632053+00	2026-05-22 22:38:31.953+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
26c45480-1419-4e69-ad84-6bb2f04ce314	a163ef00-71bb-4412-8943-c109f58a60a7	Lint Moreira	general	Code Reviewer	idle	efbb9050-2f00-4d68-b753-707a75b2dc90	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "minimax/MiniMax-M2.7-highspeed", "FALLBACK_MODEL": "glm/glm-5.1", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "minimax/MiniMax-M2.7-highspeed", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:REVIEWER:{{issueId}}"}	0	0	2026-05-22 22:37:35.635+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "REVIEWER", "companyPrefix": "MEM"}	2026-05-22 13:54:41.431338+00	2026-05-22 22:37:35.635+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
9e8a9cf6-3bec-475d-b2a5-b2bd665bf895	a163ef00-71bb-4412-8943-c109f58a60a7	Beacon Lopes	qa	QA E2E Engineer	idle	dac3e5f3-c182-4b8a-b77f-59d1a200a2d6	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "glm/glm-5.1", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "kimi/kimi-k2.6", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "glm/glm-5.1", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "mementry:QA-E2E:{{issueId}}"}	10000	0	2026-05-22 22:38:25.697+00	{"boss": "QA-LEAD", "routine": "0 */15 * * * *", "cortexRole": "QA-E2E", "companyPrefix": "MEM"}	2026-05-22 14:51:01.773647+00	2026-05-22 22:38:25.697+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
41f88289-d847-49a9-a8c8-df92b8b35fa8	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Yaci Ribeiro	general	Code Reviewer	idle	53ef54cf-6db8-4286-9462-30fff6187413	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "minimax/MiniMax-M2.7-highspeed", "FALLBACK_MODEL": "glm/glm-5.1", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "minimax/MiniMax-M2.7-highspeed", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:REVIEWER:{{issueId}}"}	0	0	2026-05-22 22:33:19.309+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "REVIEWER", "companyPrefix": "CLB"}	2026-05-22 13:54:41.36868+00	2026-05-22 22:33:19.309+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
a0e40b7d-50d8-4825-863a-bb07da88219e	a163ef00-71bb-4412-8943-c109f58a60a7	Kernel Braga	engineer	Staff Engineer	terminated	efbb9050-2f00-4d68-b753-707a75b2dc90	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/mementry", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "mementry", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "mementry", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "mementry", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_MEMENTRY_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": 50, "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "mementry:STAFF-ENG:{{issueId}}"}	0	0	2026-05-22 17:44:07.928+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-ENG-RETIRED", "companyPrefix": "MEM"}	2026-05-22 13:54:41.40268+00	2026-05-22 18:00:41.632053+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
7fdcaea2-71c6-4791-8b28-570f871c8060	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Iara Santos	pm	Product Manager	idle	4553dc21-74a8-4931-8256-da655fef241a	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cx/gpt-5.5", "FALLBACK_MODEL": "minimax/MiniMax-M2.7", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cx/gpt-5.5", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "celebrar:PM:{{issueId}}"}	0	0	2026-05-22 22:33:31.768+00	{"boss": "CPO", "routine": "0 */15 * * * *", "cortexRole": "PM", "companyPrefix": "CLB"}	2026-05-22 13:54:41.325679+00	2026-05-22 22:33:31.768+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
bac15efd-14e4-439e-9567-afd6356bcf39	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Tupã Mendes	engineer	Staff Engineer	terminated	53ef54cf-6db8-4286-9462-30fff6187413	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/celebrar", "HERMES_MODEL": "cc/claude-opus-4-7", "FALLBACK_MODEL": "kimi/kimi-k2.6", "HERMES_PROFILE": "celebrar", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "cx/gpt-5.5", "HERMES_REASONING": "high", "HONCHO_WORKSPACE": "celebrar", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "cc/claude-opus-4-7", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "celebrar", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_CELEBRAR_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": 50, "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "high", "sessionTemplate": "celebrar:STAFF-ENG:{{issueId}}"}	0	0	2026-05-22 17:37:42.356+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "STAFF-ENG-RETIRED", "companyPrefix": "CLB"}	2026-05-22 13:54:41.338944+00	2026-05-22 18:00:41.632053+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
576ecd91-110d-4b26-be9b-711f5ec15a82	a24e39b2-2ede-4aec-9471-248458a381fc	Cabo Ferreira	general	Code Reviewer	idle	06156af6-c717-462e-bc56-ed7d2a688393	\N	hermes_local	{"env": {"HERMES_HOME": "/opt/cortexos/hermes/profiles/3guns", "HERMES_MODEL": "minimax/MiniMax-M2.7-highspeed", "FALLBACK_MODEL": "glm/glm-5.1", "HERMES_PROFILE": "3guns", "OPENAI_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "HONCHO_BASE_URL": "http://127.0.0.1:18690", "OPENAI_BASE_URL": "http://127.0.0.1:11434/v1", "ANTAGONIST_MODEL": "glm/glm-5.1", "HERMES_REASONING": "medium", "HONCHO_WORKSPACE": "3guns", "OPENROUTER_API_KEY": "bi2MaO6IN3twmDj0IjIpnFcrW1LA9bpOtpOtmixwacw", "OPENROUTER_BASE_URL": "http://127.0.0.1:11434/v1"}, "model": "minimax/MiniMax-M2.7-highspeed", "quiet": true, "baseUrl": "http://127.0.0.1:18691/v1", "profile": "3guns", "verbose": false, "graceSec": 15, "provider": "openrouter", "toolsets": "terminal,file,web,browser,code_execution", "apiKeyEnv": "HERMES_3GUNS_API_KEY", "timeoutSec": 900, "hermesCommand": "/opt/cortexos/bin/hermes-paperclip", "maxIterations": "50", "persistSession": false, "paperclipApiUrl": "http://127.0.0.1:3033", "reasoningEffort": "medium", "sessionTemplate": "3guns:REVIEWER:{{issueId}}"}	0	0	2026-05-22 22:35:18.147+00	{"boss": "CTO", "routine": "0 */15 * * * *", "cortexRole": "REVIEWER", "companyPrefix": "GUN"}	2026-05-22 13:54:41.298609+00	2026-05-22 22:35:18.147+00	{"heartbeat": {"enabled": false, "intervalSec": 900, "maxConcurrentRuns": 20}}	{}	\N	\N	\N	\N
\.


--
-- Data for Name: approval_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_comments (id, company_id, approval_id, author_agent_id, author_user_id, body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approvals (id, company_id, type, requested_by_agent_id, requested_by_user_id, status, payload, decision_note, decided_by_user_id, decided_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assets (id, company_id, provider, object_key, content_type, byte_size, sha256, original_filename, created_by_agent_id, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: board_api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_api_keys (id, user_id, name, key_hash, last_used_at, revoked_at, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: budget_incidents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_incidents (id, company_id, policy_id, scope_type, scope_id, metric, window_kind, window_start, window_end, threshold_type, amount_limit, amount_observed, status, approval_id, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: budget_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_policies (id, company_id, scope_type, scope_id, metric, window_kind, amount, warn_percent, hard_stop_enabled, notify_enabled, is_active, created_by_user_id, updated_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cli_auth_challenges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cli_auth_challenges (id, secret_hash, command, client_name, requested_access, requested_company_id, pending_key_hash, pending_key_name, approved_by_user_id, board_api_key_id, approved_at, cancelled_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, description, status, budget_monthly_cents, spent_monthly_cents, created_at, updated_at, issue_prefix, issue_counter, require_board_approval_for_new_agents, brand_color, pause_reason, paused_at, feedback_data_sharing_enabled, feedback_data_sharing_consent_at, feedback_data_sharing_consent_by_user_id, feedback_data_sharing_terms_version, attachment_max_bytes) FROM stdin;
a163ef00-71bb-4412-8943-c109f58a60a7	Mementry	\N	active	0	0	2026-05-22 05:28:16.099254+00	2026-05-22 05:28:16.099254+00	MEM	52	f	\N	\N	\N	f	\N	\N	\N	10485760
a24e39b2-2ede-4aec-9471-248458a381fc	3Guns	\N	active	0	0	2026-05-22 05:35:09.186551+00	2026-05-22 05:35:09.186551+00	GUN	70	f	\N	\N	\N	f	\N	\N	\N	10485760
0b96ba9b-87c5-4e69-89ca-188782d40d5f	Celebrar.me	\N	active	0	0	2026-05-22 05:28:16.099254+00	2026-05-22 05:28:16.099254+00	CLB	119	f	\N	\N	\N	f	\N	\N	\N	10485760
\.


--
-- Data for Name: company_logos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_logos (id, company_id, asset_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: company_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_memberships (id, company_id, principal_type, principal_id, status, membership_role, created_at, updated_at) FROM stdin;
df4f2a4e-8a59-44a6-94e0-ece452484327	0b96ba9b-87c5-4e69-89ca-188782d40d5f	user	local-board	active	owner	2026-05-22 05:28:54.340182+00	2026-05-22 05:28:54.340182+00
d6a57f8d-d8b3-4eed-9c87-c88dcdb82901	a163ef00-71bb-4412-8943-c109f58a60a7	user	local-board	active	owner	2026-05-22 05:28:54.348518+00	2026-05-22 05:28:54.348518+00
4e09183f-37cc-4fca-8280-6dbd37ac380a	0b96ba9b-87c5-4e69-89ca-188782d40d5f	user	5ogQZrALdOL170oXtx4PfWowYHz1nwsU	active	owner	2026-05-22 05:33:09.161044+00	2026-05-22 05:33:09.161044+00
7776aff8-360c-4bf4-a84b-045acaaf6716	a163ef00-71bb-4412-8943-c109f58a60a7	user	5ogQZrALdOL170oXtx4PfWowYHz1nwsU	active	owner	2026-05-22 05:33:09.161044+00	2026-05-22 05:33:09.161044+00
1d806c8c-96fa-4beb-92f5-58c1ff3deb86	a24e39b2-2ede-4aec-9471-248458a381fc	user	5ogQZrALdOL170oXtx4PfWowYHz1nwsU	active	owner	2026-05-22 05:35:09.195182+00	2026-05-22 05:35:09.195182+00
b1da2cd6-da26-4daf-984d-3168f9c2339d	a24e39b2-2ede-4aec-9471-248458a381fc	user	local-board	active	owner	2026-05-22 05:35:09.20083+00	2026-05-22 05:35:09.20083+00
\.


--
-- Data for Name: company_secret_bindings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_secret_bindings (id, company_id, secret_id, target_type, target_id, config_path, version_selector, required, label, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: company_secret_provider_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_secret_provider_configs (id, company_id, provider, display_name, status, is_default, config, health_status, health_checked_at, health_message, health_details, disabled_at, created_by_agent_id, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: company_secret_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_secret_versions (id, secret_id, version, material, value_sha256, created_by_agent_id, created_by_user_id, created_at, revoked_at, provider_version_ref, status, fingerprint_sha256, rotation_job_id) FROM stdin;
\.


--
-- Data for Name: company_secrets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_secrets (id, company_id, name, provider, external_ref, latest_version, description, created_by_agent_id, created_by_user_id, created_at, updated_at, key, status, managed_mode, provider_config_id, provider_metadata, last_resolved_at, last_rotated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: company_skills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_skills (id, company_id, key, slug, name, description, markdown, source_type, source_locator, source_ref, trust_level, compatibility, file_inventory, metadata, created_at, updated_at) FROM stdin;
359800e7-1bee-4c0b-854a-bae3f32b2aaf	0b96ba9b-87c5-4e69-89ca-188782d40d5f	paperclipai/paperclip/paperclip-dev	paperclip-dev	paperclip-dev	>	---\nname: paperclip-dev\nrequired: false\ndescription: >\n  Develop and operate a local Paperclip instance — start and stop servers,\n  pull updates from master, run builds and tests, manage worktrees, back up\n  databases, and diagnose problems. Use whenever you need to work on the\n  Paperclip codebase itself or keep a running instance healthy.\n---\n\n# Paperclip Dev\n\nThis skill covers the day-to-day workflows for developing and operating a local Paperclip instance. It assumes you are working inside the Paperclip repo checkout with `origin` pointing to `git@github.com:paperclipai/paperclip.git`.\n\n> **OPEN SOURCE HYGIENE:** This repository is public-facing. Treat anything you push to `origin` as publishable. Never commit or push secrets, API keys, tokens, private logs, PII, customer data, or machine-local configuration that should stay private. Keep git history tidy as well: avoid pushing throwaway branches, noisy checkpoint commits, or speculative work that does not need to be shared upstream.\n\n> **MANDATORY:** Before running any CLI command, building, testing, or managing worktrees, you MUST read `doc/DEVELOPING.md` in the Paperclip repo. It is the canonical reference for all `paperclipai` CLI commands, their options, build/test workflows, database operations, worktree management, and diagnostics. Do NOT guess at flags or options — read the doc first.\n\n## Quick Command Reference\n\nThese are the most common commands. For full option tables and details, see `doc/DEVELOPING.md`.\n\n| Task | Command |\n|------|---------|\n| Start server (first time or normal) | `npx paperclipai run` |\n| Dev mode with hot reload | `pnpm dev` |\n| Stop dev server | `pnpm dev:stop` |\n| Build | `pnpm build` |\n| Type-check | `pnpm typecheck` |\n| Run tests | `pnpm test` |\n| Run migrations | `pnpm db:migrate` |\n| Regenerate Drizzle client | `pnpm db:generate` |\n| Back up database | `npx paperclipai db:backup` |\n| Health check | `npx paperclipai doctor --repair` |\n| Print env vars | `npx paperclipai env` |\n| Trigger agent heartbeat | `npx paperclipai heartbeat run --agent-id <id>` |\n| Install agent skills locally | `npx paperclipai agent local-cli <agent> --company-id <id>` |\n\n## Pulling from Master\n\n```bash\ngit fetch origin && git pull origin master\npnpm install && pnpm build\n```\n\nIf schema changes landed, also run `pnpm db:generate && pnpm db:migrate`.\n\n## Worktrees\n\nPaperclip worktrees combine git worktrees with isolated Paperclip instances — each gets its own database, server port, and environment seeded from the primary instance.\n\n> **MANDATORY:** Before creating or managing worktrees, you MUST read the "Worktree-local Instances" and "Worktree CLI Reference" sections in `doc/DEVELOPING.md`. That is the canonical reference for all worktree commands, their options, seed modes, and environment variables.\n\n### When to Use Worktrees\n\n- Starting a feature branch that needs its own Paperclip environment\n- Running parallel agent work without cross-contaminating the primary instance\n- Testing Paperclip changes in isolation before merging\n\n### Command Overview\n\nThe CLI has two tiers (see `doc/DEVELOPING.md` for full option tables):\n\n| Command | Purpose |\n|---------|---------|\n| `worktree:make <name>` | Create worktree + isolated instance in one step |\n| `worktree:list` | List worktrees and their Paperclip status |\n| `worktree:merge-history` | Preview/import issue history between worktrees |\n| `worktree:cleanup <name>` | Remove worktree, branch, and instance data |\n| `worktree init` | Bootstrap instance inside existing worktree |\n| `worktree env` | Print shell exports for worktree instance |\n| `worktree reseed` | Refresh worktree DB from another instance |\n| `worktree repair` | Fix broken/missing worktree instance metadata |\n\n### Typical Workflow\n\n```bash\n# 1. Create a worktree for a feature\nnpx paperclipai worktree:make my-feature --start-point origin/main\n\n# 2. Move into the worktree (path printed by worktree:make) and source the environment\ncd <worktree-path>\neval "$(npx paperclipai worktree env)"\n\n# 3. Start the isolated Paperclip server\nnpx paperclipai run\n\n# 4. Do your work\n\n# 5. When done, merge history back if needed\nnpx paperclipai worktree:merge-history --from paperclip-my-feature --to current --apply\n\n# 6. Clean up\nnpx paperclipai worktree:cleanup my-feature\n```\n\n## Forks — Prefer Pushing to a User Fork\n\nIf the user has a personal fork of `paperclipai/paperclip` configured as a git remote, push your feature branches to **that fork** instead of creating branches on the main repo. This keeps the upstream branch list clean and matches the standard open-source contribution flow.\n\n### Detect a fork remote\n\nBefore pushing or creating a PR, list remotes and check for one that points at a non-`paperclipai` GitHub fork:\n\n```bash\ngit remote -v\n```\n\nTreat any remote whose URL points to `github.com:<user>/paperclip` (or `github.com/<user>/paperclip.git`) as the user's fork. Common names are `fork`, `<username>`, or `myfork`. The remote named `origin` or `upstream` that points at `paperclipai/paperclip` is the canonical upstream — do not push feature branches there if a fork exists.\n\n### Pushing to the fork\n\n```bash\n# Push the current branch to the user's fork and set upstream\ngit push -u <fork-remote> HEAD\n```\n\nThen create the PR from the fork branch:\n\n```bash\ngh pr create --repo paperclipai/paperclip --head <fork-owner>:<branch-name> ...\n```\n\n`gh pr create` usually figures out the head ref automatically when run from a branch tracking the fork; the explicit `--head <owner>:<branch>` form is the reliable fallback when it does not.\n\n### When no fork exists\n\nIf `git remote -v` shows only `paperclipai/paperclip` remotes (no user fork), fall back to pushing branches to `origin` as before. Do NOT create a fork on the user's behalf — ask first.\n\n### Keeping the fork up to date\n\nThe canonical remote that points at `paperclipai/paperclip` may be named `origin` **or** `upstream` depending on how the user set up the repo. Detect it the same way as in the "Detect a fork remote" step, then fetch and push from/with that remote so the sync works under either convention:\n\n```bash\nUPSTREAM_REMOTE=$(git remote -v | awk '/paperclipai\\/paperclip.*\\(fetch\\)/{print $1; exit}')\ngit fetch "$UPSTREAM_REMOTE"\ngit push <fork-remote> "${UPSTREAM_REMOTE}/master:master"\n```\n\n## Pull Requests\n\n> **MANDATORY PRE-FLIGHT:** Before creating ANY pull request, you MUST read the canonical source files listed below. Do NOT run `gh pr create` until you have read these files and verified your PR body matches every required section.\n\n### Step 1 — Read the canonical files\n\nYou MUST read all three of these files before creating a PR:\n\n1. **`.github/PULL_REQUEST_TEMPLATE.md`** — the required PR body structure\n2. **`CONTRIBUTING.md`** — contribution conventions, PR requirements, and thinking-path examples\n3. **`.github/workflows/pr.yml`** — CI checks that gate merge\n\n### Step 2 — Validate your PR body against this checklist\n\nAfter reading the template, verify your `--body` includes every one of these sections (names must match exactly):\n\n- [ ] `## Thinking Path` — blockquote style, 5-8 reasoning steps\n- [ ] `## What Changed` — bullet list of concrete changes\n- [ ] `## Verification` — how a reviewer confirms this works\n- [ ] `## Risks` — what could go wrong\n- [ ] `## Model Used` — provider, model ID, version, capabilities\n- [ ] `## Checklist` — copied from the template, items checked off\n\nIf any section is missing or empty, do NOT submit the PR. Go back and fill it in.\n\n### Step 3 — Create the PR\n\nOnly after completing Steps 1 and 2, run `gh pr create`. Use the template contents as the structure for `--body` — do not write a freeform summary.\n\n## Hard Rules — Do NOT Bypass\n\nThese rules exist because agents have caused real damage by improvising around CLI failures. Follow them exactly.\n\n1. **CLI is the only interface to worktrees and databases.** All worktree and database operations MUST go through `npx paperclipai` / `pnpm paperclipai` commands. You MUST NOT:\n   - Run `pg_dump`, `pg_restore`, `psql`, `createdb`, `dropdb`, or any raw postgres commands\n   - Manually set `DATABASE_URL` to point a worktree server at another instance's database\n   - Run `rm -rf` on any `.paperclip/`, `.paperclip-worktrees/`, or `db/` directory\n   - Directly manipulate embedded postgres data directories\n   - Kill postgres processes by PID\n\n2. **If a CLI command fails, stop and report.** Do NOT attempt workarounds. If `worktree:make`, `worktree reseed`, `worktree init`, `worktree:cleanup`, or any other `paperclipai` command fails:\n   - Report the exact error message in your task comment\n   - Set the task to `blocked`\n   - Suggest running `npx paperclipai doctor --repair` or recreating the worktree from scratch\n   - Do NOT try to manually replicate what the CLI does\n\n3. **Never share databases between instances.** Each worktree instance gets its own isolated database. Never override `DATABASE_URL` to point one instance at another's database. This destroys isolation and can corrupt production data.\n\n4. **Starting a dev server in a worktree requires setup first.** The correct sequence is:\n   ```bash\n   # If the worktree already exists but has no running instance:\n   cd <worktree-path>\n   eval "$(npx paperclipai worktree env)"\n   pnpm install && pnpm build\n   npx paperclipai run          # or pnpm dev\n\n   # If the worktree needs a fresh database:\n   npx paperclipai worktree reseed --seed-mode full\n\n   # If the worktree is broken beyond repair:\n   npx paperclipai worktree:cleanup <name>\n   npx paperclipai worktree:make <name> --seed-mode full\n   ```\n   If any step fails, follow rule 2 — stop and report.\n\n5. **Seeding is a CLI operation.** When asked to seed a worktree database from the main instance, use `worktree reseed` or recreate with `worktree:make --seed-mode full`. Read `doc/DEVELOPING.md` for the full option tables. Never attempt manual database copying.\n\n## Persistent Dev Servers (for Manual Testing)\n\nWhen an agent needs to start a dev server that outlives the current heartbeat — for example, so a human or QA agent can manually test against it — the server process **must** be launched in a detached session. A process started directly from a heartbeat shell is killed when the heartbeat exits.\n\n### Use `tmux` for persistent servers\n\n```bash\n# 1. cd into the worktree (or main repo) and source the environment\ncd <worktree-path>\neval "$(npx paperclipai worktree env)"   # skip if using the primary instance\n\n# 2. Start the dev server in a named, detached tmux session\ntmux new-session -d -s <session-name> 'pnpm dev'\n\n# Example with a descriptive name:\ntmux new-session -d -s auth-fix-3102 'pnpm dev'\n```\n\n### Managing the session\n\n| Task | Command |\n|------|---------|\n| Check if the session is alive | `tmux has-session -t <session-name> 2>/dev/null && echo running` |\n| View server output | `tmux capture-pane -t <session-name> -p` |\n| Kill the session | `tmux kill-session -t <session-name>` |\n| List all tmux sessions | `tmux list-sessions` |\n\n### Verifying the server is reachable\n\nAfter launching, confirm the port is listening before reporting success:\n\n```bash\n# Wait briefly for startup, then verify\nsleep 3\ncurl -sf http://127.0.0.1:<port>/api/health && echo "Server is up"\nlsof -nP -iTCP:<port> -sTCP:LISTEN\n```\n\n### Key rules\n\n1. **Always use `tmux` (or equivalent)** when a dev server needs to stay running after the heartbeat ends. A server started directly from the agent shell will die when the heartbeat exits, even if it appeared healthy moments before.\n2. **Name the session descriptively** — include the worktree name and port (e.g., `auth-fix-3102`).\n3. **Verify the server is listening** before reporting the URL to anyone.\n4. **Do not use `nohup` or `&` alone** — these are unreliable for agent shells that may have their entire process group killed.\n5. **Clean up when done** — kill the tmux session when the testing is complete.\n\n## Common Mistakes\n\n| Mistake | Fix |\n|---------|-----|\n| Server won't start | Run `npx paperclipai doctor --repair` to diagnose and auto-fix |\n| Forgetting to source worktree env | Run `eval "$(npx paperclipai worktree env)"` after cd-ing into the worktree |\n| Stale dependencies after pull | Run `pnpm install && pnpm build` after pulling |\n| Schema out of date after pull | Run `pnpm db:generate && pnpm db:migrate` |\n| Reseeding while target DB is running | Stop the target server first, or use `--allow-live-target` |\n| Cleaning up with unmerged commits | Merge or push first, or use `--force` if intentionally discarding |\n| Running agents against wrong instance | Verify `PAPERCLIP_API_URL` points to the correct port |\n| CLI command fails | Do NOT work around it — report the error and block (see Hard Rules above) |\n| Agent tries manual postgres operations | NEVER do this — all DB ops go through the CLI (see Hard Rules above) |\n| Dev server dies between heartbeats | Launch in a detached `tmux` session — see "Persistent Dev Servers" above |\n| Pushed feature branch to `paperclipai/paperclip` when a fork exists | Push to the user's fork remote instead — see "Forks" above |\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-dev	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-dev", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:50.516875+00	2026-05-22 22:33:56.728+00
6f058bd9-2f8c-4a36-b5cf-06086fdca572	a163ef00-71bb-4412-8943-c109f58a60a7	paperclipai/paperclip/paperclip-dev	paperclip-dev	paperclip-dev	>	---\nname: paperclip-dev\nrequired: false\ndescription: >\n  Develop and operate a local Paperclip instance — start and stop servers,\n  pull updates from master, run builds and tests, manage worktrees, back up\n  databases, and diagnose problems. Use whenever you need to work on the\n  Paperclip codebase itself or keep a running instance healthy.\n---\n\n# Paperclip Dev\n\nThis skill covers the day-to-day workflows for developing and operating a local Paperclip instance. It assumes you are working inside the Paperclip repo checkout with `origin` pointing to `git@github.com:paperclipai/paperclip.git`.\n\n> **OPEN SOURCE HYGIENE:** This repository is public-facing. Treat anything you push to `origin` as publishable. Never commit or push secrets, API keys, tokens, private logs, PII, customer data, or machine-local configuration that should stay private. Keep git history tidy as well: avoid pushing throwaway branches, noisy checkpoint commits, or speculative work that does not need to be shared upstream.\n\n> **MANDATORY:** Before running any CLI command, building, testing, or managing worktrees, you MUST read `doc/DEVELOPING.md` in the Paperclip repo. It is the canonical reference for all `paperclipai` CLI commands, their options, build/test workflows, database operations, worktree management, and diagnostics. Do NOT guess at flags or options — read the doc first.\n\n## Quick Command Reference\n\nThese are the most common commands. For full option tables and details, see `doc/DEVELOPING.md`.\n\n| Task | Command |\n|------|---------|\n| Start server (first time or normal) | `npx paperclipai run` |\n| Dev mode with hot reload | `pnpm dev` |\n| Stop dev server | `pnpm dev:stop` |\n| Build | `pnpm build` |\n| Type-check | `pnpm typecheck` |\n| Run tests | `pnpm test` |\n| Run migrations | `pnpm db:migrate` |\n| Regenerate Drizzle client | `pnpm db:generate` |\n| Back up database | `npx paperclipai db:backup` |\n| Health check | `npx paperclipai doctor --repair` |\n| Print env vars | `npx paperclipai env` |\n| Trigger agent heartbeat | `npx paperclipai heartbeat run --agent-id <id>` |\n| Install agent skills locally | `npx paperclipai agent local-cli <agent> --company-id <id>` |\n\n## Pulling from Master\n\n```bash\ngit fetch origin && git pull origin master\npnpm install && pnpm build\n```\n\nIf schema changes landed, also run `pnpm db:generate && pnpm db:migrate`.\n\n## Worktrees\n\nPaperclip worktrees combine git worktrees with isolated Paperclip instances — each gets its own database, server port, and environment seeded from the primary instance.\n\n> **MANDATORY:** Before creating or managing worktrees, you MUST read the "Worktree-local Instances" and "Worktree CLI Reference" sections in `doc/DEVELOPING.md`. That is the canonical reference for all worktree commands, their options, seed modes, and environment variables.\n\n### When to Use Worktrees\n\n- Starting a feature branch that needs its own Paperclip environment\n- Running parallel agent work without cross-contaminating the primary instance\n- Testing Paperclip changes in isolation before merging\n\n### Command Overview\n\nThe CLI has two tiers (see `doc/DEVELOPING.md` for full option tables):\n\n| Command | Purpose |\n|---------|---------|\n| `worktree:make <name>` | Create worktree + isolated instance in one step |\n| `worktree:list` | List worktrees and their Paperclip status |\n| `worktree:merge-history` | Preview/import issue history between worktrees |\n| `worktree:cleanup <name>` | Remove worktree, branch, and instance data |\n| `worktree init` | Bootstrap instance inside existing worktree |\n| `worktree env` | Print shell exports for worktree instance |\n| `worktree reseed` | Refresh worktree DB from another instance |\n| `worktree repair` | Fix broken/missing worktree instance metadata |\n\n### Typical Workflow\n\n```bash\n# 1. Create a worktree for a feature\nnpx paperclipai worktree:make my-feature --start-point origin/main\n\n# 2. Move into the worktree (path printed by worktree:make) and source the environment\ncd <worktree-path>\neval "$(npx paperclipai worktree env)"\n\n# 3. Start the isolated Paperclip server\nnpx paperclipai run\n\n# 4. Do your work\n\n# 5. When done, merge history back if needed\nnpx paperclipai worktree:merge-history --from paperclip-my-feature --to current --apply\n\n# 6. Clean up\nnpx paperclipai worktree:cleanup my-feature\n```\n\n## Forks — Prefer Pushing to a User Fork\n\nIf the user has a personal fork of `paperclipai/paperclip` configured as a git remote, push your feature branches to **that fork** instead of creating branches on the main repo. This keeps the upstream branch list clean and matches the standard open-source contribution flow.\n\n### Detect a fork remote\n\nBefore pushing or creating a PR, list remotes and check for one that points at a non-`paperclipai` GitHub fork:\n\n```bash\ngit remote -v\n```\n\nTreat any remote whose URL points to `github.com:<user>/paperclip` (or `github.com/<user>/paperclip.git`) as the user's fork. Common names are `fork`, `<username>`, or `myfork`. The remote named `origin` or `upstream` that points at `paperclipai/paperclip` is the canonical upstream — do not push feature branches there if a fork exists.\n\n### Pushing to the fork\n\n```bash\n# Push the current branch to the user's fork and set upstream\ngit push -u <fork-remote> HEAD\n```\n\nThen create the PR from the fork branch:\n\n```bash\ngh pr create --repo paperclipai/paperclip --head <fork-owner>:<branch-name> ...\n```\n\n`gh pr create` usually figures out the head ref automatically when run from a branch tracking the fork; the explicit `--head <owner>:<branch>` form is the reliable fallback when it does not.\n\n### When no fork exists\n\nIf `git remote -v` shows only `paperclipai/paperclip` remotes (no user fork), fall back to pushing branches to `origin` as before. Do NOT create a fork on the user's behalf — ask first.\n\n### Keeping the fork up to date\n\nThe canonical remote that points at `paperclipai/paperclip` may be named `origin` **or** `upstream` depending on how the user set up the repo. Detect it the same way as in the "Detect a fork remote" step, then fetch and push from/with that remote so the sync works under either convention:\n\n```bash\nUPSTREAM_REMOTE=$(git remote -v | awk '/paperclipai\\/paperclip.*\\(fetch\\)/{print $1; exit}')\ngit fetch "$UPSTREAM_REMOTE"\ngit push <fork-remote> "${UPSTREAM_REMOTE}/master:master"\n```\n\n## Pull Requests\n\n> **MANDATORY PRE-FLIGHT:** Before creating ANY pull request, you MUST read the canonical source files listed below. Do NOT run `gh pr create` until you have read these files and verified your PR body matches every required section.\n\n### Step 1 — Read the canonical files\n\nYou MUST read all three of these files before creating a PR:\n\n1. **`.github/PULL_REQUEST_TEMPLATE.md`** — the required PR body structure\n2. **`CONTRIBUTING.md`** — contribution conventions, PR requirements, and thinking-path examples\n3. **`.github/workflows/pr.yml`** — CI checks that gate merge\n\n### Step 2 — Validate your PR body against this checklist\n\nAfter reading the template, verify your `--body` includes every one of these sections (names must match exactly):\n\n- [ ] `## Thinking Path` — blockquote style, 5-8 reasoning steps\n- [ ] `## What Changed` — bullet list of concrete changes\n- [ ] `## Verification` — how a reviewer confirms this works\n- [ ] `## Risks` — what could go wrong\n- [ ] `## Model Used` — provider, model ID, version, capabilities\n- [ ] `## Checklist` — copied from the template, items checked off\n\nIf any section is missing or empty, do NOT submit the PR. Go back and fill it in.\n\n### Step 3 — Create the PR\n\nOnly after completing Steps 1 and 2, run `gh pr create`. Use the template contents as the structure for `--body` — do not write a freeform summary.\n\n## Hard Rules — Do NOT Bypass\n\nThese rules exist because agents have caused real damage by improvising around CLI failures. Follow them exactly.\n\n1. **CLI is the only interface to worktrees and databases.** All worktree and database operations MUST go through `npx paperclipai` / `pnpm paperclipai` commands. You MUST NOT:\n   - Run `pg_dump`, `pg_restore`, `psql`, `createdb`, `dropdb`, or any raw postgres commands\n   - Manually set `DATABASE_URL` to point a worktree server at another instance's database\n   - Run `rm -rf` on any `.paperclip/`, `.paperclip-worktrees/`, or `db/` directory\n   - Directly manipulate embedded postgres data directories\n   - Kill postgres processes by PID\n\n2. **If a CLI command fails, stop and report.** Do NOT attempt workarounds. If `worktree:make`, `worktree reseed`, `worktree init`, `worktree:cleanup`, or any other `paperclipai` command fails:\n   - Report the exact error message in your task comment\n   - Set the task to `blocked`\n   - Suggest running `npx paperclipai doctor --repair` or recreating the worktree from scratch\n   - Do NOT try to manually replicate what the CLI does\n\n3. **Never share databases between instances.** Each worktree instance gets its own isolated database. Never override `DATABASE_URL` to point one instance at another's database. This destroys isolation and can corrupt production data.\n\n4. **Starting a dev server in a worktree requires setup first.** The correct sequence is:\n   ```bash\n   # If the worktree already exists but has no running instance:\n   cd <worktree-path>\n   eval "$(npx paperclipai worktree env)"\n   pnpm install && pnpm build\n   npx paperclipai run          # or pnpm dev\n\n   # If the worktree needs a fresh database:\n   npx paperclipai worktree reseed --seed-mode full\n\n   # If the worktree is broken beyond repair:\n   npx paperclipai worktree:cleanup <name>\n   npx paperclipai worktree:make <name> --seed-mode full\n   ```\n   If any step fails, follow rule 2 — stop and report.\n\n5. **Seeding is a CLI operation.** When asked to seed a worktree database from the main instance, use `worktree reseed` or recreate with `worktree:make --seed-mode full`. Read `doc/DEVELOPING.md` for the full option tables. Never attempt manual database copying.\n\n## Persistent Dev Servers (for Manual Testing)\n\nWhen an agent needs to start a dev server that outlives the current heartbeat — for example, so a human or QA agent can manually test against it — the server process **must** be launched in a detached session. A process started directly from a heartbeat shell is killed when the heartbeat exits.\n\n### Use `tmux` for persistent servers\n\n```bash\n# 1. cd into the worktree (or main repo) and source the environment\ncd <worktree-path>\neval "$(npx paperclipai worktree env)"   # skip if using the primary instance\n\n# 2. Start the dev server in a named, detached tmux session\ntmux new-session -d -s <session-name> 'pnpm dev'\n\n# Example with a descriptive name:\ntmux new-session -d -s auth-fix-3102 'pnpm dev'\n```\n\n### Managing the session\n\n| Task | Command |\n|------|---------|\n| Check if the session is alive | `tmux has-session -t <session-name> 2>/dev/null && echo running` |\n| View server output | `tmux capture-pane -t <session-name> -p` |\n| Kill the session | `tmux kill-session -t <session-name>` |\n| List all tmux sessions | `tmux list-sessions` |\n\n### Verifying the server is reachable\n\nAfter launching, confirm the port is listening before reporting success:\n\n```bash\n# Wait briefly for startup, then verify\nsleep 3\ncurl -sf http://127.0.0.1:<port>/api/health && echo "Server is up"\nlsof -nP -iTCP:<port> -sTCP:LISTEN\n```\n\n### Key rules\n\n1. **Always use `tmux` (or equivalent)** when a dev server needs to stay running after the heartbeat ends. A server started directly from the agent shell will die when the heartbeat exits, even if it appeared healthy moments before.\n2. **Name the session descriptively** — include the worktree name and port (e.g., `auth-fix-3102`).\n3. **Verify the server is listening** before reporting the URL to anyone.\n4. **Do not use `nohup` or `&` alone** — these are unreliable for agent shells that may have their entire process group killed.\n5. **Clean up when done** — kill the tmux session when the testing is complete.\n\n## Common Mistakes\n\n| Mistake | Fix |\n|---------|-----|\n| Server won't start | Run `npx paperclipai doctor --repair` to diagnose and auto-fix |\n| Forgetting to source worktree env | Run `eval "$(npx paperclipai worktree env)"` after cd-ing into the worktree |\n| Stale dependencies after pull | Run `pnpm install && pnpm build` after pulling |\n| Schema out of date after pull | Run `pnpm db:generate && pnpm db:migrate` |\n| Reseeding while target DB is running | Stop the target server first, or use `--allow-live-target` |\n| Cleaning up with unmerged commits | Merge or push first, or use `--force` if intentionally discarding |\n| Running agents against wrong instance | Verify `PAPERCLIP_API_URL` points to the correct port |\n| CLI command fails | Do NOT work around it — report the error and block (see Hard Rules above) |\n| Agent tries manual postgres operations | NEVER do this — all DB ops go through the CLI (see Hard Rules above) |\n| Dev server dies between heartbeats | Launch in a detached `tmux` session — see "Persistent Dev Servers" above |\n| Pushed feature branch to `paperclipai/paperclip` when a fork exists | Push to the user's fork remote instead — see "Forks" above |\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-dev	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-dev", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:51.241932+00	2026-05-22 22:38:31.842+00
7a70d8f8-657e-4373-b500-af90e3388e8f	0b96ba9b-87c5-4e69-89ca-188782d40d5f	paperclipai/paperclip/diagnose-why-work-stopped	diagnose-why-work-stopped	diagnose-why-work-stopped	>	---\nname: diagnose-why-work-stopped\ndescription: >\n  How to handle "why did this work stop / why is this looping?" assignments.\n  Forensics first on the named tree, surface the exact stop-point, frame the\n  fix as a general product rule that respects three invariants (productive\n  work continues, only real blockers stop work, no infinite loops), and\n  deliver a plan — no code changes — gated by board/CTO approval before\n  child issues are created. Use whenever the issue title or body asks for\n  forensics on a stalled, looping, or "went too deep" tree.\n---\n\n# Diagnose Why Work Stopped\n\nA repeatable procedure for the recurring class of issues where the user (or a manager) points at a stalled / looping / over-recovered issue tree and asks "why did this stop / why is this looping / how do we make sure this doesn't happen again?"\n\nThis skill is **diagnostic + product-design**, not engineering. The output is a written root cause and an approved plan. No code changes leave this skill.\n\nCanonical execution model: read `doc/execution-semantics.md` before diagnosing or proposing a new liveness/recovery rule. Use that document as the source of truth for status, action-path, post-run disposition, bounded continuation, productivity review, pause-hold, watchdog, and explicit recovery semantics. If the investigation finds a true product-rule gap, the plan should say whether `doc/execution-semantics.md` needs a matching update.\n\n## When to use\n\nTrigger on an assignment whose title or body matches any of:\n\n- "why did this work stop", "why did this stall", "why did this just stop"\n- "infinite loop", "looping", "spinning", "going too deep", "recovery went too deep"\n- "liveness — what happened here", "this tree stopped working", "stuck"\n- "approach it from a product perspective", "general product principle / rule"\n- An attached link to a specific stalled / looping / over-recovered issue tree\n\nAlso use when the user asks for forensics, root cause, or a write-up *before* any product change.\n\n## When NOT to use\n\n- The assignment asks you to ship a code change directly. Use normal engineering flow.\n- The assignment is a normal bug report against a specific feature. Use normal investigation.\n- You are the original implementer being asked to fix your own bug. Use normal debugging.\n\n## Three invariants you must preserve\n\nEvery diagnosis and every proposed rule must hold these three invariants together. The user has restated them on at least four issues; treat them as load-bearing:\n\n1. **Productive work continues.** Agents that have a clear next action must keep working without needing the user to wake them. ([PAP-2674](/PAP/issues/PAP-2674), [PAP-2708](/PAP/issues/PAP-2708))\n2. **Only real blockers stop work.** Stops happen when something genuinely cannot proceed (missing approval, missing dependency, human owner). Pseudo-stops (in_review with no action path, cancelled leaves, malformed metadata) must be detected and routed, not left silent. ([PAP-2335](/PAP/issues/PAP-2335), [PAP-2674](/PAP/issues/PAP-2674))\n3. **No infinite loops.** Stranded-work recovery and continuation loops must be bounded and distinguishable from genuinely productive continuation. ([PAP-2602](/PAP/issues/PAP-2602), [PAP-2486](/PAP/issues/PAP-2486))\n\nIf a proposed rule violates any of the three, drop it or rework it. State explicitly in the plan how each invariant is held.\n\n## Procedure\n\n### 0. Read the current execution contract\n\nBefore walking the tree, read `doc/execution-semantics.md` and keep its terms intact:\n\n- live path / waiting path / recovery path\n- post-run disposition: terminal, explicitly live, explicitly waiting, invalid\n- bounded `run_liveness_continuation`\n- productivity review vs liveness recovery\n- active subtree pause holds\n- silent active-run watchdog\n\nDo not invent a new rule until you can state how it differs from the current execution semantics document.\n\n### 1. Forensics on the named tree — before anything else\n\nDo this in the same heartbeat. Do not propose a rule until you have a concrete stop point.\n\n- Open the linked issue (and its blocker chain, parents, recovery siblings, recent runs).\n- Walk the tree node-by-node and find the exact issue + state combination that stops the world. Common shapes seen in the company so far:\n  - `in_review` with no typed execution participant, no active run, no pending interaction, no recovery issue ([PAP-2335](/PAP/issues/PAP-2335), [PAP-2674](/PAP/issues/PAP-2674)).\n  - `in_progress` after a successful run with no future action path queued ([PAP-2674](/PAP/issues/PAP-2674)).\n  - Blocker chain whose leaf is `cancelled` / malformed / cross-company-inaccessible ([PAP-2602](/PAP/issues/PAP-2602)).\n  - `issue.continuation_recovery` waking the same issue >N times after successful runs ([PAP-2602](/PAP/issues/PAP-2602)).\n  - Stranded-work recovery treating its own recovery issues as more recoverable source work ([PAP-2486](/PAP/issues/PAP-2486)).\n- Quote the evidence: run ids, comment timestamps, status transitions. "Inferred" is acceptable only when an API boundary blocks direct evidence — say so explicitly and mark the claim provisional ([PAP-2631](/PAP/issues/PAP-2631)).\n\nRespect the API boundary. If the linked issue is in another company and your agent token returns 403, do not bypass scoping. Either request a board-approved diagnostic path or proceed from inferred PAP-side evidence and label it.\n\n### 2. Survey recent related work\n\nBefore proposing a new product rule, read what already shipped this week in the same area. The user has explicitly called this out: ([PAP-2602](/PAP/issues/PAP-2602)) "review our recent work on liveness that we shipped in the last couple of days." A new rule that contradicts code merged 48 hours ago is rework, not improvement.\n\nQuick survey:\n- Recent merged PRs in the affected area.\n- Recent done issues whose title mentions liveness, recovery, productivity, continuation, or the affected subsystem.\n- Any active plan documents on parent issues. The fix may belong as a revision to an existing plan, not as a new top-level proposal.\n\nState in the forensics: "I reviewed X, Y, Z. The new gap is …"\n\n### 3. Classify each non-progressing issue in the tree\n\nFor every issue in the affected tree that is not `done` / `cancelled` / actively running, decide:\n\n- **Truly needs human or board intervention** — name the owner and the action.\n- **Agent-actionable but not currently routed** — name the rule that would have routed it, and the agent that should have been waked.\n- **Already covered** — point at the active run, queued wake, recovery issue, or pending interaction.\n\nThis is the table the user has asked for repeatedly ([PAP-2335](/PAP/issues/PAP-2335)). Without it the plan is abstract.\n\n### 4. Frame as a general product rule\n\nThe user does not want a one-off patch on the named tree. They want the rule. Two checks:\n\n- The rule is **stated as a contract**, not as an if/else patch. Example contract: "every agent-owned non-terminal issue must finish each heartbeat with a terminal state, an explicit waiting path, or an explicit live path" ([PAP-2674](/PAP/issues/PAP-2674)).\n- The rule is reconciled against `doc/execution-semantics.md`. Prefer citing and applying the existing contract; propose a document change only when the current doc is incomplete or contradicted by accepted/implemented behavior.\n- The rule **explicitly preserves the three invariants** above. Show the work.\n\nIf the rule would have blocked a recent productive run from succeeding, drop or narrow it.\n\n### 5. Plan, do not code\n\nWrite the plan into the issue's `plan` document. Cover:\n\n- Forensics summary (root cause + evidence).\n- The general product rule, stated as a contract.\n- Whether the existing `doc/execution-semantics.md` contract already covers the case, or what exact documentation update is needed.\n- Phased subtasks: typically `Phase 0` resolves the named live tree (carefully, not destructively), `Phase 1` codifies the contract in docs, then implementation phases for detection, recovery, UI surfacing, security review, QA, and CTO review.\n- Explicit assignees per phase; favor team specialty (CodexCoder for server, ClaudeCoder for FE, UXDesigner for visible state, SecurityEngineer for ownership/permissions, QA for validation).\n- Blocking dependencies wired with `blockedByIssueIds`, parallel branches identified.\n\nDo not create the child issues yet. Do not push code.\n\n### 6. Request approval, then decompose\n\n- Open a `request_confirmation` interaction targeting the latest plan revision. Idempotency key `confirmation:{issueId}:plan:{revisionId}`.\n- Wait for board/CTO acceptance. If the user posts a new comment that supersedes the plan, the prior confirmation is invalidated — open a fresh confirmation tied to the new revision ([PAP-2602](/PAP/issues/PAP-2602) cycled three revisions; that is fine).\n- Only after acceptance: create the phased child issues with the right assignees and dependencies, then block this parent on the final QA / CTO review issue so the parent only wakes when the chain finishes.\n\n### 7. Phase 0 hygiene on the named tree\n\nPhase 0 cleans up the live tree without papering over evidence:\n\n- Move stalled `in_review` leaves with no participant to `todo` with a precise next action and named owner ([PAP-2335](/PAP/issues/PAP-2335)).\n- Detach cancelled/dead blockers from chains they were holding hostage; do not silently mark issues `done` to clear backlog.\n- Leave a comment on the original named issue summarizing what changed and why; never hide the recovery chain history.\n\n### 8. Final close-out\n\nWhen the phase chain is complete, post a board-level summary comment on the parent issue: what changed, what the new contract is, what the rollout step is (e.g. "restart the control-plane to pick up the new response shape"), and the live state of the originally-named tree. Then close the parent.\n\n## Pitfalls\n\n- **Coding before approval.** The user has said "make a plan first" on every recent diagnostic issue. Producing code in the forensic phase wastes the round-trip.\n- **Restating one invariant at the cost of another.** Bound continuation too tightly and productive work stalls; loosen recovery and infinite loops return. Always check all three.\n- **Skipping the recent-work survey.** Proposing a contract that contradicts what shipped 24 hours ago is the easiest way to get the plan rejected.\n- **Letting "in_review" mean done.** A leaf assigned to another agent with no participant or active run is not progress; treat it as a stop.\n- **Bypassing company scoping.** Cross-company forensics needs a board-approved diagnostic path, not a database read.\n- **Recursive recovery.** Stranded-work recovery that recovers its own recovery issues is the canonical infinite loop ([PAP-2486](/PAP/issues/PAP-2486)). Detect it and refuse to deepen.\n- **Hiding the chain.** Don't silently delete or hide the symptomatic recovery issues — the operator needs the audit trail.\n\n## Verification checklist (before posting the plan)\n\n- [ ] The exact stop point in the named tree is identified with run ids / comment ids.\n- [ ] Recent shipped work in the same area was surveyed and is referenced.\n- [ ] Every non-progressing issue is classified human-needed / agent-actionable / already-covered.\n- [ ] The proposed rule is stated as a contract, not a patch.\n- [ ] All three invariants are explicitly preserved.\n- [ ] No code change has landed in this heartbeat.\n- [ ] A `request_confirmation` against the latest plan revision is open.\n- [ ] Phase 0 of the plan addresses the live named tree without destroying evidence.\n- [ ] Implementation phases name specialty-appropriate assignees and `blockedByIssueIds` dependencies.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/diagnose-why-work-stopped	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/diagnose-why-work-stopped", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:50.482687+00	2026-05-22 22:33:56.694+00
b0c783e1-cdeb-4faf-b835-1bb7cfa819ff	0b96ba9b-87c5-4e69-89ca-188782d40d5f	paperclipai/paperclip/paperclip	paperclip	paperclip	>	---\nname: paperclip\ndescription: >\n  Interact with the Paperclip control plane API to manage tasks, coordinate with\n  other agents, and follow company governance. Use when you need to check\n  assignments, update task status, delegate work, post comments, set up or manage\n  routines (recurring scheduled tasks), or call any Paperclip API endpoint. Do NOT\n  use for the actual domain work itself (writing code, research, etc.) — only for\n  Paperclip coordination.\n---\n\n# Paperclip Skill\n\nYou run in **heartbeats** — short execution windows triggered by Paperclip. Each heartbeat, you wake up, check your work, do something useful, and exit. You do not run continuously.\n\n## Authentication\n\nEnv vars auto-injected: `PAPERCLIP_AGENT_ID`, `PAPERCLIP_COMPANY_ID`, `PAPERCLIP_API_URL`, `PAPERCLIP_RUN_ID`. Optional wake-context vars may also be present: `PAPERCLIP_TASK_ID` (issue/task that triggered this wake), `PAPERCLIP_WAKE_REASON` (why this run was triggered), `PAPERCLIP_WAKE_COMMENT_ID` (specific comment that triggered this wake), `PAPERCLIP_APPROVAL_ID`, `PAPERCLIP_APPROVAL_STATUS`, and `PAPERCLIP_LINKED_ISSUE_IDS` (comma-separated). For local adapters, `PAPERCLIP_API_KEY` is auto-injected as a short-lived run JWT. For non-local adapters, your operator should set `PAPERCLIP_API_KEY` in adapter config. All requests use `Authorization: Bearer $PAPERCLIP_API_KEY`. All endpoints under `/api`, all JSON. Never hard-code the API URL.\n\nSome adapters also inject `PAPERCLIP_WAKE_PAYLOAD_JSON` on comment-driven wakes. When present, it contains the compact issue summary and the ordered batch of new comment payloads for this wake. Use it first. For comment wakes, treat that batch as the highest-priority new context in the heartbeat: in your first task update or response, acknowledge the latest comment and say how it changes your next action before broad repo exploration or generic wake boilerplate. Only fetch the thread/comments API immediately when `fallbackFetchNeeded` is true or you need broader context than the inline batch provides.\n\nManual local CLI mode (outside heartbeat runs): use `paperclipai agent local-cli <agent-id-or-shortname> --company-id <company-id>` to install Paperclip skills for Claude/Codex and print/export the required `PAPERCLIP_*` environment variables for that agent identity.\n\n**Run audit trail:** You MUST include `-H 'X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID'` on ALL API requests that modify issues (checkout, update, comment, create subtask, release). This links your actions to the current heartbeat run for traceability.\n\n## The Heartbeat Procedure\n\nFollow these steps every time you wake up:\n\n**Scoped-wake fast path.** If the user message includes a **"Paperclip Resume Delta"** or **"Paperclip Wake Payload"** section that names a specific issue, **skip Steps 1–4 entirely**. Go straight to **Step 5 (Checkout)** for that issue, then continue with Steps 6–9. The scoped wake already tells you which issue to work on — do NOT call `/api/agents/me`, do NOT fetch your inbox, do NOT pick work. Just checkout, read the wake context, do the work, and update.\n\n**Step 1 — Identity.** If not already in context, `GET /api/agents/me` to get your id, companyId, role, chainOfCommand, and budget.\n\n**Step 2 — Approval follow-up (when triggered).** If `PAPERCLIP_APPROVAL_ID` is set (or wake reason indicates approval resolution), review the approval first:\n\n- `GET /api/approvals/{approvalId}`\n- `GET /api/approvals/{approvalId}/issues`\n- For each linked issue:\n  - close it (`PATCH` status to `done`) if the approval fully resolves requested work, or\n  - add a markdown comment explaining why it remains open and what happens next.\n    Always include links to the approval and issue in that comment.\n\n**Step 3 — Get assignments.** Prefer `GET /api/agents/me/inbox-lite` for the normal heartbeat inbox. It returns the compact assignment list you need for prioritization. Fall back to `GET /api/companies/{companyId}/issues?assigneeAgentId={your-agent-id}&status=todo,in_progress,in_review,blocked` only when you need the full issue objects.\n\n**Step 4 — Pick work.** Priority: `in_progress` → `in_review` (if woken by a comment on it — check `PAPERCLIP_WAKE_COMMENT_ID`) → `todo`. Skip `blocked` unless you can unblock.\n\nOverrides and special cases:\n\n- `PAPERCLIP_TASK_ID` set and assigned to you → prioritize that task first.\n- `PAPERCLIP_WAKE_REASON=issue_commented` with `PAPERCLIP_WAKE_COMMENT_ID` → read the comment, then checkout and address the feedback (applies to `in_review` too).\n- `PAPERCLIP_WAKE_REASON=issue_comment_mentioned` → read the comment thread first even if you're not the assignee. Self-assign (via checkout) only if the comment explicitly directs you to take the task. Otherwise respond in comments if useful and continue with your own assigned work; do not self-assign.\n- Wake payload says `dependency-blocked interaction: yes` → the issue is still blocked for deliverable work. Do not try to unblock it. Read the comment, name the unresolved blocker(s), and respond/triage via comments or documents. Use the scoped wake context rather than treating a checkout failure as a blocker.\n- **Blocked-task dedup:** before touching a `blocked` task, check the thread. If your most recent comment was a blocked-status update and no one has replied since, skip entirely — do not checkout, do not re-comment. Only re-engage on new context (comment, status change, event wake).\n- Nothing assigned and no valid mention handoff → exit the heartbeat.\n\n**Step 5 — Checkout.** You MUST checkout before doing any work. Include the run ID header:\n\n```\nPOST /api/issues/{issueId}/checkout\nHeaders: Authorization: Bearer $PAPERCLIP_API_KEY, X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID\n{ "agentId": "{your-agent-id}", "expectedStatuses": ["todo", "backlog", "blocked", "in_review"] }\n```\n\nIf already checked out by you, returns normally. If owned by another agent: `409 Conflict` — stop, pick a different task. **Never retry a 409.**\n\n**Step 6 — Understand context.** Prefer `GET /api/issues/{issueId}/heartbeat-context` first. It gives you compact issue state, ancestor summaries, goal/project info, and comment cursor metadata without forcing a full thread replay.\n\nIf `PAPERCLIP_WAKE_PAYLOAD_JSON` is present, inspect that payload before calling the API. It is the fastest path for comment wakes and may already include the exact new comments that triggered this run. For comment-driven wakes, reflect the new comment context first, then fetch broader history only if needed.\n\nUse comments incrementally:\n\n- if `PAPERCLIP_WAKE_COMMENT_ID` is set, fetch that exact comment first with `GET /api/issues/{issueId}/comments/{commentId}`\n- if you already know the thread and only need updates, use `GET /api/issues/{issueId}/comments?after={last-seen-comment-id}&order=asc`\n- use the full `GET /api/issues/{issueId}/comments` route only when cold-starting or when incremental isn't enough\n\nRead enough ancestor/comment context to understand _why_ the task exists and what changed. Do not reflexively reload the whole thread on every heartbeat.\n\n**Execution-policy review/approval wakes.** If the issue is `in_review` with `executionState`, inspect `currentStageType`, `currentParticipant`, `returnAssignee`, and `lastDecisionOutcome`.\n\nIf `currentParticipant` matches you, submit your decision via the normal update route — there is no separate execution-decision endpoint:\n\n- Approve: `PATCH /api/issues/{issueId}` with `{ "status": "done", "comment": "Approved: …" }`. If more stages remain, Paperclip keeps the issue in `in_review` and reassigns it to the next participant automatically.\n- Request changes: `PATCH` with `{ "status": "in_progress", "comment": "Changes requested: …" }`. Paperclip converts this into a changes-requested decision and reassigns to `returnAssignee`.\n\nIf `currentParticipant` does not match you, do not try to advance the stage — Paperclip will reject other actors with `422`.\n\n**Step 7 — Do the work.** Use your tools and capabilities. Execution contract:\n\n- If the issue is actionable, start concrete work in the same heartbeat. Do not stop at a plan unless the issue specifically asks for planning.\n- Leave durable progress in comments, issue documents, or work products, then update the issue state/path to a clear final disposition before you exit.\n- Treat comments, documents, screenshots, work products, and `Remaining` bullets as evidence. They are not valid liveness paths by themselves.\n- Use child issues for parallel or long delegated work; do not busy-poll agents, sessions, child issues, or processes waiting for completion.\n- If your heartbeat creates a pending board/user interaction or approval before more work can proceed, leave the source issue in an explicit waiting posture before you exit. Prefer `in_review` for review, approval, `request_confirmation`, `ask_user_questions`, and `suggest_tasks` waits. Use `blocked` with `blockedByIssueIds` when another issue is the blocker.\n- If blocked, move the issue to `blocked` with the unblock owner and exact action needed.\n- Respect budget, pause/cancel, approval gates, execution policy stages, and company boundaries.\n\n**Step 8 — Update status and communicate.** Always include the run ID header.\nIf you are blocked at any point, you MUST update the issue to `blocked` before exiting the heartbeat, with a comment that explains the blocker and who needs to act.\n\nBefore ending any heartbeat, apply this final-disposition checklist:\n\n- `done`: the requested work is complete, verification is recorded, and no follow-up remains on this issue.\n- `in_review`: a real reviewer path exists, such as a typed execution participant, board/user owner, linked approval, pending interaction, or an explicit monitor that will wake the assignee later. Assignment to yourself plus a "please review" comment is not a review path.\n- `blocked`: work cannot continue until first-class `blockedByIssueIds` resolve or a named owner takes a concrete unblock action.\n- Delegated follow-up: create the follow-up issue directly, link it with `parentId`/`goalId`, and use blockers when the current issue must wait for that work.\n- Explicit continuation: keep the issue `in_progress` only when there is an active run, queued continuation, or monitor/recovery path that will wake the responsible assignee. Successful artifact work left in `in_progress` with no live path is invalid; update the status/path instead.\n\nWhen writing issue descriptions or comments, follow the ticket-linking rule in **Comment Style** below.\n\n```json\nPATCH /api/issues/{issueId}\nHeaders: X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID\n{ "status": "done", "comment": "What was done and why." }\n```\n\nFor multiline markdown comments, do **not** hand-inline the markdown into a one-line JSON string — that is how comments get "smooshed" together. Use the helper below (or an equivalent `jq --arg` pattern reading from a heredoc/file) so literal newlines survive JSON encoding:\n\n```bash\nscripts/paperclip-issue-update.sh --issue-id "$PAPERCLIP_TASK_ID" --status done <<'MD'\nDone\n\n- Fixed the newline-preserving issue update path\n- Verified the raw stored comment body keeps paragraph breaks\nMD\n```\n\nStatus values: `backlog`, `todo`, `in_progress`, `in_review`, `done`, `blocked`, `cancelled`. Priority values: `critical`, `high`, `medium`, `low`. Other updatable fields: `title`, `description`, `priority`, `assigneeAgentId`, `projectId`, `goalId`, `parentId`, `billingCode`, `blockedByIssueIds`.\n\n### Status Quick Guide\n\n- `backlog` — parked/unscheduled, not something you're about to start this heartbeat.\n- `todo` — ready and actionable, but not checked out yet. Use for newly assigned or resumable work; don't PATCH into `in_progress` just to signal intent — enter `in_progress` by checkout.\n- `in_progress` — actively owned, execution-backed work.\n- `in_review` — paused pending reviewer/approver/board/user feedback. Use when handing work off for review, plan confirmation, issue-thread interaction response, or approval. This is a healthy waiting path, not a synonym for done. If a human asks to take the task back, reassign to them and set `in_review`.\n- `blocked` — cannot proceed until something specific changes. Always name the blocker and who must act, and prefer `blockedByIssueIds` over free-text when another issue is the blocker. `parentId` alone does not imply a blocker.\n- `done` — work complete, no follow-up on this issue.\n- `cancelled` — intentionally abandoned, not to be resumed.\n\n**Step 9 — Delegate if needed.** Create subtasks with `POST /api/companies/{companyId}/issues`. Always set `parentId` and `goalId`. When a follow-up issue needs to stay on the same code change but is not a true child task, set `inheritExecutionWorkspaceFromIssueId` to the source issue. Set `billingCode` for cross-team work.\n\n## Issue Dependencies (Blockers)\n\nExpress "A is blocked by B" as first-class blockers so dependent work auto-resumes.\n\n**Set blockers** via `blockedByIssueIds` (array of issue IDs) on create or update:\n\n```json\nPOST /api/companies/{companyId}/issues\n{ "title": "Deploy to prod", "blockedByIssueIds": ["id-1","id-2"], "status": "blocked" }\n\nPATCH /api/issues/{issueId}\n{ "blockedByIssueIds": ["id-1","id-2"] }\n```\n\nThe array **replaces** the current set on each update — send `[]` to clear. Issues cannot block themselves; circular chains are rejected.\n\n**Read blockers** from `GET /api/issues/{issueId}`: `blockedBy` (issues blocking this one) and `blocks` (issues this one blocks), each with id/identifier/title/status/priority/assignee.\n\n**Automatic wakes:**\n\n- `PAPERCLIP_WAKE_REASON=issue_blockers_resolved` — all `blockedBy` issues reached `done`; dependent's assignee is woken.\n- `PAPERCLIP_WAKE_REASON=issue_children_completed` — all direct children reached a terminal state (`done`/`cancelled`); parent's assignee is woken.\n\n`cancelled` blockers do **not** count as resolved — remove or replace them explicitly before expecting `issue_blockers_resolved`.\n\n## Requesting Board Approval\n\nUse `request_board_approval` when you need the board to approve/deny a proposed action:\n\n```json\nPOST /api/companies/{companyId}/approvals\n{\n  "type": "request_board_approval",\n  "requestedByAgentId": "{your-agent-id}",\n  "issueIds": ["{issue-id}"],\n  "payload": {\n    "title": "Approve monthly hosting spend",\n    "summary": "Estimated cost is $42/month for provider X.",\n    "recommendedAction": "Approve provider X and continue setup.",\n    "risks": ["Costs may increase with usage."]\n  }\n}\n```\n\n`issueIds` links the approval into the issue thread. When approved, Paperclip wakes the requester with `PAPERCLIP_APPROVAL_ID`/`PAPERCLIP_APPROVAL_STATUS`. Keep the payload concise and decision-ready.\n\n## Niche Workflow Pointers\n\nLoad `references/workflows.md` when the task matches one of these:\n\n- Set up a new project + workspace (CEO/Manager).\n- Generate an OpenClaw invite prompt (CEO).\n- Set or clear an agent's `instructions-path`.\n- CEO-safe company imports/exports (preview/apply).\n- App-level self-test playbook.\n\n## Company Skills Workflow\n\nAuthorized managers can install company skills independently of hiring, then assign or remove those skills on agents.\n\n- Install and inspect company skills with the company skills API.\n- Assign skills to existing agents with `POST /api/agents/{agentId}/skills/sync`.\n- When hiring or creating an agent, include optional `desiredSkills` so the same assignment model is applied on day one.\n\nIf you are asked to install a skill for the company or an agent you MUST read:\n`skills/paperclip/references/company-skills.md`\n\n## Routines\n\nRoutines are recurring tasks. Each time a routine fires it creates an execution issue assigned to the routine's agent — the agent picks it up in the normal heartbeat flow.\n\n- Create and manage routines with the routines API — agents can only manage routines assigned to themselves.\n- Add triggers per routine: `schedule` (cron), `webhook`, or `api` (manual).\n- Control concurrency and catch-up behaviour with `concurrencyPolicy` and `catchUpPolicy`.\n\nIf you are asked to create or manage routines you MUST read:\n`skills/paperclip/references/routines.md`\n\n## Issue Workspace Runtime Controls\n\nWhen an issue needs browser/manual QA or a preview server, inspect its current execution workspace and use Paperclip's workspace runtime controls instead of starting unmanaged background servers yourself.\n\nFor commands, response fields, and MCP tools, read:\n`skills/paperclip/references/issue-workspaces.md`\n\n## Critical Rules\n\n- **Never retry a 409.** The task belongs to someone else.\n- **Never look for unassigned work.** No assignments = exit.\n- **Self-assign only for explicit @-mention handoff.** Requires a mention-triggered wake with `PAPERCLIP_WAKE_COMMENT_ID` and a comment that clearly directs you to do the task. Use checkout (never direct assignee patch).\n- **Honor "send it back to me" requests from board users.** If a board/user asks for review handoff (e.g. "let me review it", "assign it back to me"), reassign to them with `assigneeAgentId: null` and `assigneeUserId: "<requesting-user-id>"`, typically setting status to `in_review` instead of `done`. Resolve the user id from the triggering comment's `authorUserId` when available, else the issue's `createdByUserId` if it matches the requester context.\n- **Start actionable work before planning-only closure.** Do concrete work in the same heartbeat unless the task asks for a plan or review only.\n- **Leave a next action.** Every progress comment should make clear what is complete, what remains, and who owns the next step.\n- **Prefer child issues over polling.** Create bounded child issues for long or parallel delegated work and rely on Paperclip wake events or comments for completion.\n- **Preserve workspace continuity for follow-ups.** Child issues inherit execution workspace from `parentId` server-side. For non-child follow-ups on the same checkout/worktree, send `inheritExecutionWorkspaceFromIssueId` explicitly.\n- **Never cancel cross-team tasks.** Reassign to your manager with a comment.\n- **Use first-class blockers** (`blockedByIssueIds`) rather than free-text "blocked by X" comments.\n- **On a blocked task with no new context, don't re-comment** — see the blocked-task dedup rule in Step 4.\n- **@-mentions** trigger heartbeats — use sparingly, they cost budget. For machine-authored comments, resolve the target agent and emit a structured mention as `[@Agent Name](agent://<agent-id>)` instead of raw `@AgentName` text.\n- **Budget**: auto-paused at 100%. Above 80%, focus on critical tasks only.\n- **Escalate** via `chainOfCommand` when stuck. Reassign to manager or create a task for them.\n- **Hiring**: use the `paperclip-create-agent` skill for new agent creation workflows (links to reusable `AGENTS.md` templates like `Coder` and `QA`).\n- **Commit Co-author**: if you make a git commit you MUST add EXACTLY `Co-Authored-By: Paperclip <noreply@paperclip.ing>` to the end of each commit message. Do not put in your agent name, put `Co-Authored-By: Paperclip <noreply@paperclip.ing>`.\n\nThis is rule #1:\n\nIMPORTANT: **NEVER ASK A HUMAN TO DO WHAT AN AGENT COULD DO**. If you need to escalate, escalate. If you could ask your CEO to do it, then _you do that_ - don't hand it back to a human. Again: Never ask a human to do what an agent _could_ do. Rule number 1.\n\n## Comment Style (Required)\n\nWhen posting issue comments or writing issue descriptions, use concise markdown with:\n\n- a short status line\n- bullets for what changed / what is blocked\n- links to related entities when available\n\n**Ticket references are links (required):** If you mention another issue identifier such as `PAP-224`, `ZED-24`, or any `{PREFIX}-{NUMBER}` ticket id inside a comment body or issue description, wrap it in a Markdown link:\n\n- `[PAP-224](/PAP/issues/PAP-224)`\n- `[ZED-24](/ZED/issues/ZED-24)`\n\nNever leave bare ticket ids in issue descriptions or comments when a clickable internal link can be provided.\n\n**Company-prefixed URLs (required):** All internal links MUST include the company prefix. Derive the prefix from any issue identifier you have (e.g., `PAP-315` → prefix is `PAP`). Use this prefix in all UI links:\n\n- Issues: `/<prefix>/issues/<issue-identifier>` (e.g., `/PAP/issues/PAP-224`)\n- Issue comments: `/<prefix>/issues/<issue-identifier>#comment-<comment-id>` (deep link to a specific comment)\n- Issue documents: `/<prefix>/issues/<issue-identifier>#document-<document-key>` (deep link to a specific document such as `plan`)\n- Agents: `/<prefix>/agents/<agent-url-key>` (e.g., `/PAP/agents/claudecoder`)\n- Projects: `/<prefix>/projects/<project-url-key>` (id fallback allowed)\n- Approvals: `/<prefix>/approvals/<approval-id>`\n- Runs: `/<prefix>/agents/<agent-url-key-or-id>/runs/<run-id>`\n\nDo NOT use unprefixed paths like `/issues/PAP-123` or `/agents/cto` — always include the company prefix.\n\n**Preserve markdown line breaks (required):** build multiline JSON bodies from heredoc/file input (via the helper in Step 8 or `jq -n --arg comment "$comment"`). Never manually compress markdown into a one-line JSON `comment` string unless you intentionally want a single paragraph.\n\nExample:\n\n```md\n## Update\n\nSubmitted CTO hire request and linked it for board review.\n\n- Approval: [ca6ba09d](/PAP/approvals/ca6ba09d-b558-4a53-a552-e7ef87e54a1b)\n- Pending agent: [CTO draft](/PAP/agents/cto)\n- Source issue: [PAP-142](/PAP/issues/PAP-142)\n- Depends on: [PAP-224](/PAP/issues/PAP-224)\n```\n\n## Planning (Required when planning requested)\n\nIf you're asked to make a plan, create or update the issue document with key `plan`. Do not append plans into the issue description anymore. If you're asked for plan revisions, update that same `plan` document. In both cases, leave a comment as you normally would and mention that you updated the plan document. Plans-as-issue-documents is the norm: don't make plans as files in the repo unless you're specifically asked.\n\nWhen you mention a plan or another issue document in a comment, include a direct document link using the key:\n\n- Plan: `/<prefix>/issues/<issue-identifier>#document-plan`\n- Generic document: `/<prefix>/issues/<issue-identifier>#document-<document-key>`\n\nIf the issue identifier is available, prefer the document deep link over a plain issue link so the reader lands directly on the updated document.\n\nIf you're asked to make a plan, _do not mark the issue as done_. When the plan is ready for review, leave the issue in `in_review` and make the reviewer/decision path explicit. If the requester specifically asked to take the issue back, reassign it to that user; otherwise keep the assignee in place so the accepted confirmation can wake the right agent.\n\nIf the plan needs explicit approval before implementation, update the `plan` document, create a `request_confirmation` issue-thread interaction bound to the latest plan revision, then update the source issue to `in_review` with a comment that links the plan and names the pending confirmation. This is a deliberate waiting path, not an abandoned productive run. Wait for acceptance before creating implementation subtasks. See `references/api-reference.md` for the interaction payload.\n\nWhen asked to convert a plan into executable Paperclip tasks — depth, assignment, dependencies, parallelization — use the companion skill `paperclip-converting-plans-to-tasks`.\n\nWhen asked to convert a plan into executable Paperclip tasks — depth, assignment, dependencies, parallelization — use the companion skill `paperclip-converting-plans-to-tasks`.\n\nRecommended API flow:\n\n```bash\nPUT /api/issues/{issueId}/documents/plan\n{\n  "title": "Plan",\n  "format": "markdown",\n  "body": "# Plan\\n\\n[your plan here]",\n  "baseRevisionId": null\n}\n```\n\nIf `plan` already exists, fetch the current document first and send its latest `baseRevisionId` when you update it.\n\n## Key Endpoints (Hot Routes)\n\n| Action                                | Endpoint                                                                                                                        |\n| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |\n| My identity                           | `GET /api/agents/me`                                                                                                            |\n| My compact inbox                      | `GET /api/agents/me/inbox-lite`                                                                                                 |\n| My assignments                        | `GET /api/companies/:companyId/issues?assigneeAgentId=:id&status=todo,in_progress,in_review,blocked`                            |\n| Checkout task                         | `POST /api/issues/:issueId/checkout`                                                                                            |\n| Get task + ancestors                  | `GET /api/issues/:issueId`                                                                                                      |\n| Compact heartbeat context             | `GET /api/issues/:issueId/heartbeat-context`                                                                                    |\n| Update task                           | `PATCH /api/issues/:issueId` (optional `comment` field)                                                                         |\n| Get comments / delta / single         | `GET /api/issues/:issueId/comments[?after=:commentId&order=asc]` • `/comments/:commentId`                                       |\n| Add comment                           | `POST /api/issues/:issueId/comments`                                                                                            |\n| Issue-thread interactions             | `GET\\|POST /api/issues/:issueId/interactions` • `POST /api/issues/:issueId/interactions/:interactionId/{accept,reject,respond}` |\n| Create subtask                        | `POST /api/companies/:companyId/issues`                                                                                         |\n| Release task                          | `POST /api/issues/:issueId/release`                                                                                             |\n| Search issues                         | `GET /api/companies/:companyId/issues?q=search+term`                                                                            |\n| Issue documents (list/get/put)        | `GET\\|PUT /api/issues/:issueId/documents[/:key]`                                                                                |\n| Create approval                       | `POST /api/companies/:companyId/approvals`                                                                                      |\n| Upload attachment (multipart, `file`) | `POST /api/companies/:companyId/issues/:issueId/attachments`                                                                    |\n| List / get / delete attachment        | `GET /api/issues/:issueId/attachments` • `GET\\|DELETE /api/attachments/:attachmentId[/content]`                                 |\n| Execution workspace + runtime         | `GET /api/execution-workspaces/:id` • `POST …/runtime-services/:action`                                                         |\n| Set agent instructions path           | `PATCH /api/agents/:agentId/instructions-path`                                                                                  |\n| List agents                           | `GET /api/companies/:companyId/agents`                                                                                          |\n| Dashboard                             | `GET /api/companies/:companyId/dashboard`                                                                                       |\n\nFull endpoint table (company imports/exports, OpenClaw invites, company skills, routines, etc.) lives in `references/api-reference.md`.\n\n## Searching Issues\n\nUse the `q` query parameter on the issues list endpoint to search across titles, identifiers, descriptions, and comments:\n\n```\nGET /api/companies/{companyId}/issues?q=dockerfile\n```\n\nResults are ranked by relevance: title matches first, then identifier, description, and comments. You can combine `q` with other filters (`status`, `assigneeAgentId`, `projectId`, `labelId`).\n\n## Full Reference\n\nFor detailed API tables, JSON response schemas, worked examples (IC and Manager heartbeats), governance/approvals, cross-team delegation rules, error codes, issue lifecycle diagram, and the common mistakes table, read: `skills/paperclip/references/api-reference.md`\n\nAgain, rule #1 is: never ask a human to do what an agent could do. Try harder. Try again. Ask another agent to help. Keep working until the goal is fully accomplished.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/api-reference.md"}, {"kind": "reference", "path": "references/company-skills.md"}, {"kind": "reference", "path": "references/issue-workspaces.md"}, {"kind": "reference", "path": "references/routines.md"}, {"kind": "reference", "path": "references/workflows.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:50.488655+00	2026-05-22 22:33:56.698+00
21d173b9-e0a0-4326-9f81-784ea739e5cd	a24e39b2-2ede-4aec-9471-248458a381fc	paperclipai/paperclip/diagnose-why-work-stopped	diagnose-why-work-stopped	diagnose-why-work-stopped	>	---\nname: diagnose-why-work-stopped\ndescription: >\n  How to handle "why did this work stop / why is this looping?" assignments.\n  Forensics first on the named tree, surface the exact stop-point, frame the\n  fix as a general product rule that respects three invariants (productive\n  work continues, only real blockers stop work, no infinite loops), and\n  deliver a plan — no code changes — gated by board/CTO approval before\n  child issues are created. Use whenever the issue title or body asks for\n  forensics on a stalled, looping, or "went too deep" tree.\n---\n\n# Diagnose Why Work Stopped\n\nA repeatable procedure for the recurring class of issues where the user (or a manager) points at a stalled / looping / over-recovered issue tree and asks "why did this stop / why is this looping / how do we make sure this doesn't happen again?"\n\nThis skill is **diagnostic + product-design**, not engineering. The output is a written root cause and an approved plan. No code changes leave this skill.\n\nCanonical execution model: read `doc/execution-semantics.md` before diagnosing or proposing a new liveness/recovery rule. Use that document as the source of truth for status, action-path, post-run disposition, bounded continuation, productivity review, pause-hold, watchdog, and explicit recovery semantics. If the investigation finds a true product-rule gap, the plan should say whether `doc/execution-semantics.md` needs a matching update.\n\n## When to use\n\nTrigger on an assignment whose title or body matches any of:\n\n- "why did this work stop", "why did this stall", "why did this just stop"\n- "infinite loop", "looping", "spinning", "going too deep", "recovery went too deep"\n- "liveness — what happened here", "this tree stopped working", "stuck"\n- "approach it from a product perspective", "general product principle / rule"\n- An attached link to a specific stalled / looping / over-recovered issue tree\n\nAlso use when the user asks for forensics, root cause, or a write-up *before* any product change.\n\n## When NOT to use\n\n- The assignment asks you to ship a code change directly. Use normal engineering flow.\n- The assignment is a normal bug report against a specific feature. Use normal investigation.\n- You are the original implementer being asked to fix your own bug. Use normal debugging.\n\n## Three invariants you must preserve\n\nEvery diagnosis and every proposed rule must hold these three invariants together. The user has restated them on at least four issues; treat them as load-bearing:\n\n1. **Productive work continues.** Agents that have a clear next action must keep working without needing the user to wake them. ([PAP-2674](/PAP/issues/PAP-2674), [PAP-2708](/PAP/issues/PAP-2708))\n2. **Only real blockers stop work.** Stops happen when something genuinely cannot proceed (missing approval, missing dependency, human owner). Pseudo-stops (in_review with no action path, cancelled leaves, malformed metadata) must be detected and routed, not left silent. ([PAP-2335](/PAP/issues/PAP-2335), [PAP-2674](/PAP/issues/PAP-2674))\n3. **No infinite loops.** Stranded-work recovery and continuation loops must be bounded and distinguishable from genuinely productive continuation. ([PAP-2602](/PAP/issues/PAP-2602), [PAP-2486](/PAP/issues/PAP-2486))\n\nIf a proposed rule violates any of the three, drop it or rework it. State explicitly in the plan how each invariant is held.\n\n## Procedure\n\n### 0. Read the current execution contract\n\nBefore walking the tree, read `doc/execution-semantics.md` and keep its terms intact:\n\n- live path / waiting path / recovery path\n- post-run disposition: terminal, explicitly live, explicitly waiting, invalid\n- bounded `run_liveness_continuation`\n- productivity review vs liveness recovery\n- active subtree pause holds\n- silent active-run watchdog\n\nDo not invent a new rule until you can state how it differs from the current execution semantics document.\n\n### 1. Forensics on the named tree — before anything else\n\nDo this in the same heartbeat. Do not propose a rule until you have a concrete stop point.\n\n- Open the linked issue (and its blocker chain, parents, recovery siblings, recent runs).\n- Walk the tree node-by-node and find the exact issue + state combination that stops the world. Common shapes seen in the company so far:\n  - `in_review` with no typed execution participant, no active run, no pending interaction, no recovery issue ([PAP-2335](/PAP/issues/PAP-2335), [PAP-2674](/PAP/issues/PAP-2674)).\n  - `in_progress` after a successful run with no future action path queued ([PAP-2674](/PAP/issues/PAP-2674)).\n  - Blocker chain whose leaf is `cancelled` / malformed / cross-company-inaccessible ([PAP-2602](/PAP/issues/PAP-2602)).\n  - `issue.continuation_recovery` waking the same issue >N times after successful runs ([PAP-2602](/PAP/issues/PAP-2602)).\n  - Stranded-work recovery treating its own recovery issues as more recoverable source work ([PAP-2486](/PAP/issues/PAP-2486)).\n- Quote the evidence: run ids, comment timestamps, status transitions. "Inferred" is acceptable only when an API boundary blocks direct evidence — say so explicitly and mark the claim provisional ([PAP-2631](/PAP/issues/PAP-2631)).\n\nRespect the API boundary. If the linked issue is in another company and your agent token returns 403, do not bypass scoping. Either request a board-approved diagnostic path or proceed from inferred PAP-side evidence and label it.\n\n### 2. Survey recent related work\n\nBefore proposing a new product rule, read what already shipped this week in the same area. The user has explicitly called this out: ([PAP-2602](/PAP/issues/PAP-2602)) "review our recent work on liveness that we shipped in the last couple of days." A new rule that contradicts code merged 48 hours ago is rework, not improvement.\n\nQuick survey:\n- Recent merged PRs in the affected area.\n- Recent done issues whose title mentions liveness, recovery, productivity, continuation, or the affected subsystem.\n- Any active plan documents on parent issues. The fix may belong as a revision to an existing plan, not as a new top-level proposal.\n\nState in the forensics: "I reviewed X, Y, Z. The new gap is …"\n\n### 3. Classify each non-progressing issue in the tree\n\nFor every issue in the affected tree that is not `done` / `cancelled` / actively running, decide:\n\n- **Truly needs human or board intervention** — name the owner and the action.\n- **Agent-actionable but not currently routed** — name the rule that would have routed it, and the agent that should have been waked.\n- **Already covered** — point at the active run, queued wake, recovery issue, or pending interaction.\n\nThis is the table the user has asked for repeatedly ([PAP-2335](/PAP/issues/PAP-2335)). Without it the plan is abstract.\n\n### 4. Frame as a general product rule\n\nThe user does not want a one-off patch on the named tree. They want the rule. Two checks:\n\n- The rule is **stated as a contract**, not as an if/else patch. Example contract: "every agent-owned non-terminal issue must finish each heartbeat with a terminal state, an explicit waiting path, or an explicit live path" ([PAP-2674](/PAP/issues/PAP-2674)).\n- The rule is reconciled against `doc/execution-semantics.md`. Prefer citing and applying the existing contract; propose a document change only when the current doc is incomplete or contradicted by accepted/implemented behavior.\n- The rule **explicitly preserves the three invariants** above. Show the work.\n\nIf the rule would have blocked a recent productive run from succeeding, drop or narrow it.\n\n### 5. Plan, do not code\n\nWrite the plan into the issue's `plan` document. Cover:\n\n- Forensics summary (root cause + evidence).\n- The general product rule, stated as a contract.\n- Whether the existing `doc/execution-semantics.md` contract already covers the case, or what exact documentation update is needed.\n- Phased subtasks: typically `Phase 0` resolves the named live tree (carefully, not destructively), `Phase 1` codifies the contract in docs, then implementation phases for detection, recovery, UI surfacing, security review, QA, and CTO review.\n- Explicit assignees per phase; favor team specialty (CodexCoder for server, ClaudeCoder for FE, UXDesigner for visible state, SecurityEngineer for ownership/permissions, QA for validation).\n- Blocking dependencies wired with `blockedByIssueIds`, parallel branches identified.\n\nDo not create the child issues yet. Do not push code.\n\n### 6. Request approval, then decompose\n\n- Open a `request_confirmation` interaction targeting the latest plan revision. Idempotency key `confirmation:{issueId}:plan:{revisionId}`.\n- Wait for board/CTO acceptance. If the user posts a new comment that supersedes the plan, the prior confirmation is invalidated — open a fresh confirmation tied to the new revision ([PAP-2602](/PAP/issues/PAP-2602) cycled three revisions; that is fine).\n- Only after acceptance: create the phased child issues with the right assignees and dependencies, then block this parent on the final QA / CTO review issue so the parent only wakes when the chain finishes.\n\n### 7. Phase 0 hygiene on the named tree\n\nPhase 0 cleans up the live tree without papering over evidence:\n\n- Move stalled `in_review` leaves with no participant to `todo` with a precise next action and named owner ([PAP-2335](/PAP/issues/PAP-2335)).\n- Detach cancelled/dead blockers from chains they were holding hostage; do not silently mark issues `done` to clear backlog.\n- Leave a comment on the original named issue summarizing what changed and why; never hide the recovery chain history.\n\n### 8. Final close-out\n\nWhen the phase chain is complete, post a board-level summary comment on the parent issue: what changed, what the new contract is, what the rollout step is (e.g. "restart the control-plane to pick up the new response shape"), and the live state of the originally-named tree. Then close the parent.\n\n## Pitfalls\n\n- **Coding before approval.** The user has said "make a plan first" on every recent diagnostic issue. Producing code in the forensic phase wastes the round-trip.\n- **Restating one invariant at the cost of another.** Bound continuation too tightly and productive work stalls; loosen recovery and infinite loops return. Always check all three.\n- **Skipping the recent-work survey.** Proposing a contract that contradicts what shipped 24 hours ago is the easiest way to get the plan rejected.\n- **Letting "in_review" mean done.** A leaf assigned to another agent with no participant or active run is not progress; treat it as a stop.\n- **Bypassing company scoping.** Cross-company forensics needs a board-approved diagnostic path, not a database read.\n- **Recursive recovery.** Stranded-work recovery that recovers its own recovery issues is the canonical infinite loop ([PAP-2486](/PAP/issues/PAP-2486)). Detect it and refuse to deepen.\n- **Hiding the chain.** Don't silently delete or hide the symptomatic recovery issues — the operator needs the audit trail.\n\n## Verification checklist (before posting the plan)\n\n- [ ] The exact stop point in the named tree is identified with run ids / comment ids.\n- [ ] Recent shipped work in the same area was surveyed and is referenced.\n- [ ] Every non-progressing issue is classified human-needed / agent-actionable / already-covered.\n- [ ] The proposed rule is stated as a contract, not a patch.\n- [ ] All three invariants are explicitly preserved.\n- [ ] No code change has landed in this heartbeat.\n- [ ] A `request_confirmation` against the latest plan revision is open.\n- [ ] Phase 0 of the plan addresses the live named tree without destroying evidence.\n- [ ] Implementation phases name specialty-appropriate assignees and `blockedByIssueIds` dependencies.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/diagnose-why-work-stopped	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/diagnose-why-work-stopped", "sourceKind": "paperclip_bundled"}	2026-05-22 13:59:29.291816+00	2026-05-25 01:43:29.958+00
e6e23898-8b69-4d5c-a2ab-5e5050276999	a24e39b2-2ede-4aec-9471-248458a381fc	paperclipai/paperclip/terminal-bench-loop	terminal-bench-loop	terminal-bench-loop	>	---\nname: terminal-bench-loop\ndescription: >\n  Run a single Terminal-Bench problem through Paperclip in a bounded,\n  human-in-the-loop improvement cycle until the smoke passes, the board\n  rejects the next fix, the iteration budget is exhausted, or a real\n  blocker is named. Each iteration runs a bounded smoke against an\n  isolated Paperclip App worktree, captures artifacts, diagnoses the\n  exact stop point with `/diagnose-why-work-stopped`, requests board\n  confirmation before any product fix, then reruns against the same\n  worktree. Use whenever an issue asks to "run Terminal-Bench in a\n  loop", "drive Terminal-Bench until it passes", "loop fix-git through\n  Paperclip", or otherwise points at a Terminal-Bench task and asks for\n  bounded iteration with diagnosis.\n---\n\n# Terminal-Bench Loop\n\nA repeatable operating skill for driving one Terminal-Bench problem to a passing smoke through Paperclip, with explicit issue topology, bounded runs, board-gated product fixes, and worktree continuity.\n\nThis skill is **operational + diagnostic**, not engineering. It coordinates issues, artifacts, and approvals around a Terminal-Bench loop. It does not authorize code changes — every accepted product fix lands as a separate implementation child issue after a board confirmation.\n\nCanonical execution model: read `doc/execution-semantics.md` before starting a loop or moving any loop issue. Every loop issue must rest in a state the doc allows: terminal (`done`/`cancelled`), explicitly live (active run / queued wake), explicitly waiting (`in_review` with participant/interaction/approval), or explicit recovery/blocker (`blocked` with `blockedByIssueIds` and a named owner).\n\n## When to use\n\nTrigger on an assignment whose title or body matches any of:\n\n- "run Terminal-Bench in a loop", "loop \\<task-name\\> through Paperclip"\n- "drive Terminal-Bench fix-git", "iterate on Terminal-Bench until it passes"\n- "Terminal-Bench smoke loop", "bench loop", "smoke loop on \\<task-name\\>"\n- An attached link to a Terminal-Bench loop parent issue, plus a request to do another iteration\n\nAlso use when the user hands you an existing top-level loop issue and asks for the next iteration, diagnosis, or rerun.\n\n## When NOT to use\n\n- The assignment is to build or change `paperclip-bench` itself (Harbor adapter, wrapper, telemetry). Use normal engineering flow on that repo.\n- The assignment is to submit a benchmark result for ranking. This skill produces smoke/non-comparable runs by design — escalate full-suite or comparable runs to BenchmarkQualityManager.\n- The assignment is a normal Paperclip product bug not surfaced by a Terminal-Bench loop. Use normal investigation.\n- You have not been granted permission to install or assign company skills, and the asker actually wants library mutation. Hand that step to an authorized skill-library owner.\n\n## Three invariants you must preserve\n\nEvery loop iteration and every proposed product fix must hold these three invariants together. They come from `/diagnose-why-work-stopped` and the user has restated them across the liveness work:\n\n1. **Productive work continues.** Each loop issue must always have a clear next action owner — agent, board, user, or named blocker. No silent `in_review` with nothing waiting on it.\n2. **Only real blockers stop work.** Stops happen when something genuinely cannot proceed (board confirmation, QA, missing credentials, exhausted budget). Pseudo-stops must be detected and routed.\n3. **No infinite loops.** Iteration count, wall-clock budget, and a board gate before product fixes are applied keep the loop bounded.\n\nIf a proposed iteration violates any of the three, drop it or rework it. State explicitly in the loop issue how each invariant is held this iteration.\n\n## Inputs\n\nCollect these on the top-level loop issue before iteration 1. Any input that cannot be supplied is a blocker — name the unblock owner and stop.\n\n- **Source issue.** The Paperclip issue that asked for the loop. The loop parent links back to it.\n- **Terminal-Bench task name.** Single-task identifier (e.g. `terminal-bench/fix-git`). Multi-task suites are out of scope for this skill.\n- **Iteration budget.** Maximum number of iterations before the loop must stop without further fixes (typical: 3–5). Also record a per-iteration wall-clock cap.\n- **Paperclip App worktree issue.** The implementation-side issue under the Paperclip App project whose execution workspace owns the isolated worktree. First iteration creates it; later iterations reuse it via `inheritExecutionWorkspaceFromIssueId` or equivalent.\n- **Benchmark command.** The exact `paperclip-bench` invocation, including the `PAPERCLIPAI_CMD` (or equivalent) binding pinned to the Paperclip App worktree under test. Record verbatim on the loop issue.\n- **Dispatch runner config.** The exact Harbor/Paperclip runner dispatch config required for the smoke to actually start a Paperclip heartbeat. For the current Harbor wrapper, record the `PAPERCLIP_HARBOR_RUNNER_CONFIG` JSON (or equivalent config file) verbatim enough to preserve: `assignee`, `heartbeat_strategy`, `agent_adapter` / `agent_adapters`, `reuse_host_home` when local credentials are intentionally needed, and the stop budget. A bare Harbor command that creates `BEN-1` as unassigned `todo` with zero heartbeat-enabled agents is a harness/setup failure, not a valid product diagnosis.\n- **Latest artifact root.** Filesystem or storage path under which `paperclip-bench` writes run artifacts (manifest, `results.jsonl`, Harbor raw job folders, redacted telemetry). Each iteration appends; nothing is overwritten.\n- **Approval policy.** Who must accept a proposed product fix before implementation (default: board via `request_confirmation`; CTO if delegated; never the loop driver alone).\n\nRecord each input on the top-level loop issue (description or a dedicated `inputs` document). If any input changes mid-loop, note the change and the iteration it took effect.\n\n## Issue topology\n\nThe loop must be representable as a tree, not as prose in comments:\n\n- **Top-level loop issue.** Long-lived. Holds inputs, iteration counter, current state, links to every iteration child, and the product-rule history. Rests in `in_progress` while an iteration is running, `in_review` only when a typed waiter sits directly on the loop parent (execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or named human owner), `blocked` with `blockedByIssueIds` while a child issue is the gating work (iteration child holding the fix-proposal `request_confirmation`, or implementation, QA, or CTO review children), `done` on pass, or `cancelled` on board-rejection / budget exhaustion.\n- **Iteration child issues.** One per iteration. Each carries: a bounded run issue (smoke), a diagnosis issue (applies `/diagnose-why-work-stopped`), a fix-proposal document with a `request_confirmation` interaction, and — only after acceptance — implementation, QA, CTO review, and rerun children. Iteration children are blocked by their predecessors so the executor wakes them in order.\n- **Paperclip App implementation issue.** The first iteration creates a fresh Paperclip App child whose project policy spawns an isolated worktree. Every later iteration's implementation/rerun child references that same execution workspace via `inheritExecutionWorkspaceFromIssueId` so the same worktree is amended and tested.\n\nWire dependencies with `blockedByIssueIds`, never with prose like "blocked by X". When a dependent child is `done`, the executor auto-wakes the next.\n\n## Procedure\n\n### 0. Read the current execution contract\n\nBefore opening or advancing a loop, read `doc/execution-semantics.md`. Use that document's terms intact when classifying loop-issue state: live path / waiting path / recovery path; post-run disposition; bounded continuation; productivity review; pause-hold; watchdog. Do not invent a new state.\n\n### 1. Open or reuse the top-level loop issue\n\n- If an existing loop issue is supplied, read it: inputs, iteration counter, last iteration's stop reason, current Paperclip App worktree pointer, latest benchmark command.\n- If no loop issue exists, create one under the Paperclip App project (or the project the source issue points at). Title: `Terminal-Bench loop: <task-name>`. Description captures the inputs above, the iteration budget, and a link to the source issue.\n- Verify the worktree pointer still resolves. If the recorded execution workspace was discarded (worktree pruned, project changed), the loop is blocked — name the unblock owner (CodexCoder or the Paperclip App owner) and stop.\n\n### 2. Open the iteration child\n\n- Increment the iteration counter on the loop issue.\n- Create an iteration child titled `Iteration N: <task-name>`. Its description repeats the inputs and references the loop parent. Block it on the prior iteration's terminal child (if any) so the executor cannot start two iterations in parallel.\n- If the iteration counter would exceed the budget, do not create the child. Move the loop issue to `cancelled` (budget exhausted) or `in_review` if the user must decide whether to extend the budget.\n\n### 3. Run the bounded smoke\n\n- The benchmark command must use the Paperclip App worktree under test. Set `PAPERCLIPAI_CMD` (or the equivalent command binding) to the CLI entrypoint inside that worktree. Never let the smoke run against the operator's current Paperclip checkout.\n- The same command block must include the runner dispatch config that makes the benchmark issue actionable. For the current Harbor wrapper, export `PAPERCLIP_HARBOR_RUNNER_CONFIG` with the intended assignee, heartbeat strategy, agent adapter, credential/home mode, and stop budget. Do not treat a bare `uvx harbor run ...` as the canonical smoke if it omits the dispatch config; record that as a harness/setup miss and rerun with the recorded config.\n- Bound the run by wall-clock and by Paperclip's run-budget controls. If the smoke would exceed the per-iteration cap, kill it and record the truncation reason.\n- Capture, in the iteration child or a dedicated `run` document:\n  - Paperclip run id and heartbeat run ids\n  - benchmark run id, manifest, `results.jsonl` row, Harbor raw job folder\n  - dispatch config used (`PAPERCLIP_HARBOR_RUNNER_CONFIG` or equivalent), including assignee and adapter type\n  - the exact stop reason reported by the harness (pass, harness fail, verifier fail, timeout, agent gave up, infrastructure error)\n  - heartbeat-enabled and heartbeat-observed agent counts when Paperclip telemetry exports them\n  - failure taxonomy bucket (task/model, Paperclip product, harness/setup, verifier/infrastructure, security, unclear)\n  - artifact paths under the latest artifact root\n- Label the iteration as **smoke / non-comparable**. Comparable runs are out of scope for this skill.\n\n### 4. Diagnose the exact stop point\n\nApply the `/diagnose-why-work-stopped` pattern to the iteration's run, scoped to this loop only — do not pull in unrelated forensic boilerplate. Specifically:\n\n- Walk the Paperclip issue tree the smoke produced under the Paperclip App worktree, node by node, and find the exact `(issue, status)` combination that stopped progress. Quote evidence: run ids, comment timestamps, status transitions.\n- Classify every non-progressing issue in that subtree as **truly needs human/board intervention**, **agent-actionable but not currently routed**, or **already covered**.\n- State whether the failure is task/model, Paperclip product, harness/setup, verifier/infrastructure, security, or unclear. Be explicit when evidence is inferred (e.g. cross-company API boundary blocks direct reads).\n- If the failure is a Paperclip product gap, frame the fix as a **general product rule** stated as a contract, and check it against the three invariants above. If the rule would have blocked a recent productive run, narrow it.\n\nRecord the diagnosis on the iteration child as a `diagnosis` document. Do not propose code yet.\n\n### 5. Decide the next move\n\nBased on the diagnosis, the iteration ends in exactly one of these terminal-for-iteration states:\n\n- **Pass.** Smoke verifier reports pass. Move the iteration child and the loop parent toward QA/CTO review (Step 8).\n- **Product fix proposed.** A Paperclip product gap was identified. Write the fix proposal as a `plan` document on the iteration child, then go to Step 6.\n- **Non-product failure with retry.** Failure is harness/setup/infrastructure or model flakiness, the iteration budget is not exhausted, and the loop driver believes a rerun without code changes has signal (e.g. transient infra). Record the rationale on the iteration child and go to Step 7 with no implementation step.\n- **Real blocker.** Named external blocker (credentials, quota, third-party outage, security review). Move the loop issue to `blocked`, set `blockedByIssueIds` to the blocker issue (creating one if needed), and name the unblock owner. Stop.\n- **Budget or board stop.** Iteration budget reached, or the board has rejected the next fix proposal. Move the loop issue to `cancelled` with a comment that summarizes the run history and the reason for stopping.\n\n### 6. Request board confirmation before any product fix\n\nWhen the iteration ends in **product fix proposed**:\n\n- Update the iteration child's `plan` document with the proposed contract, the three-invariant check, the affected Paperclip surfaces, and the phased subtasks (implementation, QA, CTO review, rerun) — but do not create those subtasks.\n- Open the `request_confirmation` interaction on the **iteration child** (the same issue that owns the `plan` document), targeting the latest plan revision. Idempotency key: `confirmation:{iterationIssueId}:plan:{revisionId}`. Set `continuationPolicy` to `wake_assignee`.\n- Move the **iteration child** to `in_review`. The typed waiter — the `request_confirmation` interaction — sits directly on it, so its `in_review` is healthy. Comment links the plan document and names the pending confirmation.\n- Move the **loop parent** to `blocked` with `blockedByIssueIds: [iterationChildId]` and a comment naming the board (or whichever approver the approval policy designates) as the unblock owner. Do not move the loop parent to `in_review` here: the typed waiter lives on the iteration child, not on the parent, so the parent's wait path is the child blocker. This matches the topology rule that the loop parent only sits in `in_review` when a typed waiter is attached directly to the parent.\n- Wait for acceptance. If the board posts a superseding comment that changes the plan, revise the document, then open a fresh confirmation tied to the new revision on the iteration child — the prior one is invalidated. The loop parent's `blockedByIssueIds` already points at the iteration child, so it does not need to change.\n- On rejection, end the loop per the **Budget or board stop** rule; do not silently retry the same proposal.\n- On acceptance, create the implementation, QA, CTO review, and rerun child issues with `blockedByIssueIds` wired in order, and update the loop parent's `blockedByIssueIds` to point at the new gating child (typically the implementation child) so the parent stays `blocked` against real downstream work. The implementation child must inherit the Paperclip App execution workspace (`inheritExecutionWorkspaceFromIssueId` to the worktree-owning issue) so the fix lands in the same isolated worktree the smoke ran against.\n\n### 7. Rerun against the same worktree\n\nAfter implementation and QA complete (or immediately, in the **non-product failure with retry** case), the rerun child runs the same `paperclip-bench` invocation with `PAPERCLIPAI_CMD` still pinned to the Paperclip App worktree under test.\n\n- The rerun must use the same worktree the fix landed in. If the workspace was reset between iterations, the loop is invalid — open a blocker on the loop issue and stop.\n- On completion, the rerun child becomes the next iteration's run record. If the smoke now passes, jump to Step 8. Otherwise return to Step 4 with a new iteration child (subject to the iteration budget).\n\n### 8. Pass: QA, CTO review, close\n\nWhen the smoke passes:\n\n- Create QA and CTO review children if they are not already in the dependency chain (CTO review blocked by QA, so the chain wakes in order). Move the loop parent to `blocked` with `blockedByIssueIds` set to the QA / CTO review chain, and post a comment that names QA and CTO as the unblock owners and links the children. The loop parent stays `blocked` — not `in_review` — because the typed waiter lives on the children, not on the parent.\n- If you instead want the loop parent itself to sit in `in_review` during this phase (for example because a board user has explicitly volunteered to drive the review), put a typed waiter directly on the parent — execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or named human owner — and do not rely on the child chain alone. Do not combine `in_review` on the parent with QA/CTO children acting as the blocker; that is the ambiguous review shape this skill exists to prevent.\n- QA validates artifacts (manifest, `results.jsonl`, Harbor raw job, redacted telemetry) and the rerun reproducibility against the same worktree.\n- CTO reviews the technical scope of any product fixes that landed during the loop.\n- On QA + CTO acceptance, close the loop issue with a board-level summary comment: task name, iteration count, stop reason (pass), worktree pointer, link to the final artifact root, and the list of accepted product fixes (each with its implementation issue id).\n\n### 9. Stop rules\n\nThe loop **must** stop, with state explicitly recorded on the loop issue, when any of these is true:\n\n- **Pass.** Smoke verifier reports pass and QA + CTO accept (Step 8). Loop issue → `done`.\n- **Board rejection.** Board rejects a fix proposal and does not request a revision. Loop issue → `cancelled`. Comment names the rejected proposal and the reason.\n- **Iteration budget reached.** Iteration counter reaches the budget without a pass. Loop issue → `cancelled` (or `in_review` if the user must decide whether to extend the budget). Never silently start iteration N+1.\n- **Real blocker named.** External blocker (credentials, quota, infra, security, missing skill) cannot be resolved by the loop driver. Loop issue → `blocked` with `blockedByIssueIds` to the blocker issue and the unblock owner named.\n\nA loop must never end on a prose comment alone. Every stop is a status transition with a named next-action owner.\n\n## Worktree rule\n\nThe loop must not test whatever Paperclip checkout happens to be current for the heartbeat. It must test the same isolated Paperclip App worktree where proposed fixes are applied.\n\n- The first iteration creates the Paperclip App implementation child; that project's git-worktree policy spawns a fresh worktree.\n- The loop issue records the worktree-owning issue id and the workspace path (or workspace id).\n- Every later implementation, QA, and rerun child sets `inheritExecutionWorkspaceFromIssueId` to that worktree-owning issue, so all subsequent loop work shares one workspace.\n- The benchmark command always sets `PAPERCLIPAI_CMD` (or the equivalent command binding) to the CLI entrypoint inside that worktree, and it carries the recorded dispatch runner config (`PAPERCLIP_HARBOR_RUNNER_CONFIG` or equivalent) needed to assign the benchmark issue and start the heartbeat. The benchmark command stored on the loop issue is the source of truth — if a heartbeat needs to run the smoke from a different shell, it copies the recorded command block verbatim, not only the Harbor invocation line.\n- If the workspace is pruned or the worktree path no longer resolves, the loop is invalid until rebuilt. Mark the loop `blocked` and name the unblock owner (typically CodexCoder or the Paperclip App owner).\n\n## Liveness rule\n\nEvery loop issue, at the end of every heartbeat, must rest in one of:\n\n- **Terminal:** `done` or `cancelled`. No further action.\n- **Explicitly live:** `in_progress` with an active run, an upcoming queued wake, or a child issue actively executing under it.\n- **Explicitly waiting:** `in_review` with a typed waiter — execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or a named human owner.\n- **Explicit recovery / blocker:** `blocked` with `blockedByIssueIds` set to a real blocking issue, plus a comment naming the unblock owner and the action needed.\n\nIf a loop issue does not fit one of these on exit, the heartbeat is not done. Fix the state before exiting.\n\n## Pitfalls\n\n- **Running the smoke against the operator's Paperclip checkout.** The whole point of the worktree rule is that the bench tests the worktree the fix lands in. Always set `PAPERCLIPAI_CMD` and verify the path before launching the run.\n- **Dropping the dispatch config.** A Harbor run that omits `PAPERCLIP_HARBOR_RUNNER_CONFIG` (or equivalent) may boot Paperclip and create `BEN-1`, but leave it unassigned with zero heartbeat-enabled agents. That is not a Terminal-Bench product signal. Preserve and rerun the full command block, including assignee and adapter config.\n- **Coding before approval.** No implementation child exists until a board confirmation accepts the iteration's `plan` document. Do not push code in the diagnostic phase.\n- **Skipping the recent-work survey.** When proposing a Paperclip product rule, check what already shipped in the affected liveness/execution area in the last few days. A rule that contradicts last-week's accepted contract is rework.\n- **Letting `in_review` mean done.** A loop or iteration child sitting in `in_review` with no participant, no interaction, no approval, and no human owner is a stop, not progress. Treat it as a liveness violation and route it.\n- **Silent iteration N+1.** If the iteration budget is reached, never start another iteration without an explicit budget extension recorded on the loop issue.\n- **Comparable-run drift.** This skill produces smoke runs only. If the asker wants a comparable benchmark submission, hand off to BenchmarkQualityManager and BenchmarkForensics — do not relabel a smoke as comparable.\n- **Recursive recovery.** Stranded-work recovery that recovers its own recovery issues is the canonical infinite loop. If a diagnosis surfaces it inside the smoke's subtree, refuse to deepen and route to `/diagnose-why-work-stopped` for a product-rule fix.\n- **Skill-library mutation.** This skill never installs, edits, or assigns company skills as part of a loop iteration. Library changes go to an authorized skill-library owner via a separate issue.\n- **Hiding the chain.** Do not silently delete or hide failed iteration children, retracted proposals, or rejected confirmations. The audit trail is the loop's evidence.\n\n## Verification checklist (before exiting a heartbeat that touched the loop)\n\n- [ ] All inputs are recorded on the top-level loop issue, including the exact benchmark command, `PAPERCLIPAI_CMD` binding, and dispatch runner config.\n- [ ] Iteration counter is up to date and within budget.\n- [ ] The Paperclip App worktree pointer still resolves, and the iteration's run/implementation/rerun children share that workspace.\n- [ ] The smoke run is captured with run ids, manifest, `results.jsonl`, Harbor raw job folder, and stop reason.\n- [ ] Paperclip telemetry shows the benchmark issue was assigned and a heartbeat was enabled/observed, or the iteration is explicitly classified as harness/setup no-dispatch.\n- [ ] Diagnosis applies the `/diagnose-why-work-stopped` pattern, classifies every non-progressing issue, and checks the three invariants.\n- [ ] No implementation child exists for an unapproved fix proposal; if one was proposed, a `request_confirmation` is open against the latest plan revision.\n- [ ] Every loop and iteration issue rests in a terminal, explicitly-live, explicitly-waiting, or named-blocker state.\n- [ ] The stop reason — if the loop stopped this heartbeat — is one of pass, board rejection, budget exhausted, or named real blocker.\n- [ ] No company-skill library mutation happened in this heartbeat.\n\n## Deterministic smoke\n\nRun this smoke after installing or changing the skill, before treating it as operational for a live Terminal-Bench loop:\n\n```sh\npnpm smoke:terminal-bench-loop-skill\n```\n\nThe command uses the current Paperclip API token and company from `PAPERCLIP_API_URL`, `PAPERCLIP_API_KEY`, and `PAPERCLIP_COMPANY_ID`. When `PAPERCLIP_TASK_ID` is set, it attaches the smoke issues under that source issue and inherits its project/goal context. By default it cancels the short-lived smoke issues after verification; pass `-- --keep` to leave the verified `blocked` loop parent, `in_review` iteration child, and pending confirmation available for manual inspection.\n\nThe smoke is deterministic and intentionally non-comparable. It does not start Terminal-Bench, Harbor, an agent model, or a provider runtime. It verifies only the control-plane shape:\n\n- local `skills/terminal-bench-loop/SKILL.md` contains the loop contract terms;\n- a top-level loop issue can be created and updated into a blocker posture;\n- an iteration child issue can be created under the loop parent;\n- mocked benchmark artifact paths are recorded on a `run` document;\n- a `diagnosis` document names the exact stop point and next-action owner;\n- a `request_confirmation` interaction is created and the iteration child rests in `in_review` with a typed waiting path rather than silent review.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/terminal-bench-loop	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/terminal-bench-loop", "sourceKind": "paperclip_bundled"}	2026-05-22 13:59:29.326419+00	2026-05-25 01:43:29.992+00
fec69c4f-4624-427c-84b9-f3c9939e3af2	0b96ba9b-87c5-4e69-89ca-188782d40d5f	paperclipai/paperclip/paperclip-converting-plans-to-tasks	paperclip-converting-plans-to-tasks	paperclip-converting-plans-to-tasks	>	---\nname: paperclip-converting-plans-to-tasks\ndescription: >\n  The Paperclip way of converting a plan into executable tasks. Use whenever\n  you are asked to plan, scope, or break down work inside a Paperclip company.\n  Industry-agnostic guidance on how to translate a plan into assigned issues\n  with the right specialty, dependencies, and parallelization so Paperclip's\n  executor can pick up the work — it does not prescribe a plan format. Pair\n  with the `paperclip` skill, which covers the mechanics of writing the plan\n  document and reassigning the issue.\n---\n\n# Paperclip — Converting Plans to Tasks\n\nA companion skill for turning a plan into executable Paperclip work. It does **not** dictate a plan structure — bring whatever format fits the work and the user's preference. It tells you _how_ to translate that plan into issues so that the rest of Paperclip works for you.\n\nFor the **mechanics** of recording a plan (issue document with key `plan`, comment links, approval gating, who to reassign back to), follow the _Planning_ section of the `paperclip` skill. This skill covers planning method, not the API surface.\n\n## When you're asked to plan\n\n- **Plan deeply.** Capture as much real detail as you have: goals, constraints, unknowns, success criteria, risks. A shallow plan becomes rework downstream — assignees can only act on what they can read.\n- **Know your team.** Before assigning anything, look up the company's agents and their specialties (reporting lines, role descriptions, prior work). Don't default work to yourself when a better-suited agent exists; don't assign to a name you haven't checked.\n- **Assign for specialty.** Hand each piece of work to the agent most relevant to it. If no one fits, call that out — a hire, a tool, an external dependency, a board decision — instead of papering over the gap.\n- **Take responsibility.** Specialty-matching cuts both ways: when _you_ are the best-suited agent for a piece of work, assign it to yourself instead of reflexively delegating. Don't hand off to avoid load.\n- **Use the dependency tree.** Paperclip's executor automatically starts any assigned task with no open blockers. Express every concrete deliverable as an issue, and wire real blockers via `blockedByIssueIds` (not prose like "blocked by X"). When `done`, dependents auto-wake.\n- **Order, then parallelize.** Sequence work by real dependencies, not by personal preference. Independent branches of the graph should start in parallel. Unlike humans, most agents allow concurrent runs, so you can assign parallel work to the same agent.\n- **Enough is enough.** Plans exist to unblock execution, not replace it. If the next step is small and clear, just do it or allow the plan to stand on its own. Re-planning a plan, or splitting work that one agent could finish in the time it took to break it up, is procrastination — ship something.\n\n## Quick checklist before you publish a plan\n\n- [ ] Enough detail that assignees can act without re-asking.\n- [ ] Every concrete deliverable is an issue (or named as a known follow-up).\n- [ ] Each issue has a deliberate, specialty-matched assignee — not the planner by default.\n- [ ] Each issue's real blockers are declared via `blockedByIssueIds`.\n- [ ] Independent branches can start in parallel.\n- [ ] Gaps (missing skills, hires, decisions, external inputs) are surfaced, not hidden.\n\n## What this skill is not\n\n- Not a plan template. Use any format — prose, outline, table, RACI, Gantt, whatever fits.\n- Not software-development–specific. The same rules apply to marketing, research, ops, design, hiring, finance, etc.\n- Not a replacement for the `paperclip` skill's planning mechanics. Use both.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-converting-plans-to-tasks	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-converting-plans-to-tasks", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:50.495043+00	2026-05-22 22:33:56.703+00
766af3f7-94cb-45d0-9283-6877b9f846b9	0b96ba9b-87c5-4e69-89ca-188782d40d5f	paperclipai/paperclip/paperclip-create-plugin	paperclip-create-plugin	paperclip-create-plugin	>	---\nname: paperclip-create-plugin\ndescription: >\n  Create and develop external Paperclip plugins with the CLI-first workflow.\n  Use when scaffolding a new plugin, working on a local plugin against a running\n  Paperclip instance, or updating plugin authoring docs. Covers `paperclipai\n  plugin init`, the local install loop via `paperclipai plugin install <path>`,\n  worker/UI rebuild and reload semantics, and the required success checklist.\n---\n\n# Create and develop a Paperclip plugin\n\nUse this skill when the task is to create, scaffold, or iterate on a Paperclip plugin against a local Paperclip instance.\n\n## 1. Default: build the plugin OUTSIDE Paperclip core\n\nPlugins are their own packages. Unless the task **explicitly** asks for a bundled in-repo example, do not add plugin source under `packages/plugins/` in this repo.\n\n- Scaffold the plugin into a directory outside the Paperclip checkout (e.g. `~/dev/paperclip-plugins/<name>`).\n- Install it into the running Paperclip instance by local absolute path.\n- Edit code in the external package; let Paperclip pick up rebuilt output.\n\nOnly edit Paperclip core itself when the user asks to surface a plugin as a bundled example (`server/src/routes/plugins.ts`, in-repo example lists, docs).\n\n## 2. Ground rules\n\nReference docs when you need detail:\n\n1. `doc/plugins/PLUGIN_AUTHORING_GUIDE.md`\n2. `packages/plugins/sdk/README.md`\n3. `doc/plugins/PLUGIN_SPEC.md` — future-looking context only\n\nCurrent runtime assumptions:\n\n- plugin workers are trusted code\n- plugin UI is trusted same-origin host code\n- worker APIs are capability-gated\n- plugin UI is not sandboxed by manifest capabilities\n- no host-provided shared plugin UI component kit yet\n- `ctx.assets` is not supported in the current runtime\n\n## 3. CLI-first scaffold workflow\n\nUse `paperclipai plugin init`. Do not invoke the scaffold package node entrypoint by hand unless the CLI command is unavailable in the environment.\n\n```bash\npaperclipai plugin init @acme/my-plugin --output ~/dev/paperclip-plugins\n```\n\nUseful flags (all optional):\n\n- `--output <dir>` — parent directory; the command creates `<dir>/<unscoped-name>/`. Defaults to the current directory.\n- `--template <default|connector|workspace|environment>` — starter template.\n- `--category <connector|workspace|automation|ui|environment>` — manifest category.\n- `--display-name <name>`, `--description <text>`, `--author <name>` — manifest metadata.\n- `--sdk-path <path>` — snapshot the local SDK from a Paperclip checkout into `.paperclip-sdk/` (useful when developing against an unreleased SDK).\n\nOn success the command prints the exact next commands (`cd`, `pnpm install`, `pnpm dev`, `paperclipai plugin install <abs-path>`). Run them in order.\n\nIf `paperclipai` is not on PATH in your environment, fall back to:\n\n```bash\npnpm --filter @paperclipai/create-paperclip-plugin build\nnode packages/plugins/create-paperclip-plugin/dist/index.js @acme/my-plugin \\\n  --output /absolute/path \\\n  --sdk-path /absolute/path/to/paperclip/packages/plugins/sdk\n```\n\n## 4. Local install + rebuild loop\n\nIn the scaffolded plugin folder:\n\n```bash\npnpm install\npnpm dev            # esbuild --watch: rebuilds dist/manifest.js, dist/worker.js, dist/ui/\npaperclipai plugin install /absolute/path/to/my-plugin\n```\n\nNotes:\n\n- `paperclipai plugin install` auto-detects local paths (absolute, `./`, `../`, `~`, or an existing relative folder) and forwards `isLocalPath: true` to the server. Pass `--local` to force local mode if the heuristic is ambiguous.\n- Paths are resolved to absolute paths before being sent to the server.\n- The server watches built outputs (`dist/`) for local-path plugins and restarts the plugin worker on rebuild — you do not need to reinstall after every edit.\n- UI hot reload via the SDK dev server (`pnpm dev:ui`, port `4177`) is optional and template-dependent; only mention it if the template wires `devUiUrl` and you verified it works end to end.\n- `--version` only applies to npm package installs. Combining it with a local path is an error.\n\nAfter install, inspect with:\n\n```bash\npaperclipai plugin list\npaperclipai plugin inspect <plugin-key>\n```\n\n## 5. After scaffolding, sanity-check the package\n\nOpen and confirm:\n\n- `src/manifest.ts` — declared capabilities and slots\n- `src/worker.ts` — worker entry\n- `src/ui/index.tsx` — UI entry (if applicable)\n- `tests/plugin.spec.ts` — placeholder test\n- `package.json` — `paperclipPlugin` block points at `dist/manifest.js`, `dist/worker.js`, `dist/ui/`\n\nMake sure the plugin:\n\n- declares only supported capabilities\n- does not use `ctx.assets`\n- does not import host UI component stubs\n- keeps UI self-contained\n- uses `routePath` only on `page` slots\n\n## 6. Verification (run before declaring success)\n\nFrom the plugin folder:\n\n```bash\npnpm typecheck\npnpm test\npnpm build\n```\n\nIf the plugin is already running under `pnpm dev`, you can keep the watcher up and run `pnpm typecheck` and `pnpm test` in a separate shell.\n\nIf you changed Paperclip SDK/host/plugin runtime code in addition to the plugin, also run the relevant Paperclip workspace checks.\n\n## 7. Success checklist (report this back)\n\nWhen you finish a local plugin task, report:\n\n- **Scaffold path** — absolute path of the created plugin folder.\n- **Commands run** — the exact `paperclipai plugin init`, `pnpm install`, `pnpm dev`, `paperclipai plugin install <path>` invocations (and any verification commands).\n- **Install status** — output of `paperclipai plugin list` / `plugin inspect` (plugin key, version, status). Note if `status` is anything other than `ready` and include `lastError`.\n- **Tests / build result** — `pnpm typecheck`, `pnpm test`, `pnpm build` pass/fail with the failing output if any.\n- **Reload limitations** — call out anything that did not hot-reload (e.g. manifest changes required a reinstall, UI dev server was not wired, etc.).\n\nIf any item is missing, mark it as such — do not silently skip.\n\n## 8. When NOT to edit Paperclip core\n\nDo not add the plugin under `packages/plugins/` or update bundled-example wiring unless the user explicitly asks for a bundled example. Local-path installs are the supported development model; npm packages are the production deployment path.\n\nIf the user does ask for a bundled example, also update:\n\n- `server/src/routes/plugins.ts` example list\n- any docs that enumerate in-repo example plugins\n\n## 9. Documentation expectations\n\nWhen authoring or updating plugin docs:\n\n- distinguish current implementation from future spec ideas\n- be explicit about the trusted-code model\n- do not promise host UI components or asset APIs\n- prefer local-path development + npm-package deployment guidance over repo-local workflows\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-create-plugin	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-create-plugin", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:50.509017+00	2026-05-22 22:33:56.722+00
702a2549-eff9-462b-9777-4d82294daeb4	0b96ba9b-87c5-4e69-89ca-188782d40d5f	paperclipai/paperclip/para-memory-files	para-memory-files	para-memory-files	>	---\nname: para-memory-files\ndescription: >\n  File-based memory system using Tiago Forte's PARA method. Use this skill whenever\n  you need to store, retrieve, update, or organize knowledge across sessions. Covers\n  three memory layers: (1) Knowledge graph in PARA folders with atomic YAML facts,\n  (2) Daily notes as raw timeline, (3) Tacit knowledge about user patterns. Also\n  handles planning files, memory decay, weekly synthesis, and recall via qmd.\n  Trigger on any memory operation: saving facts, writing daily notes, creating\n  entities, running weekly synthesis, recalling past context, or managing plans.\n---\n\n# PARA Memory Files\n\nPersistent, file-based memory organized by Tiago Forte's PARA method. Three layers: a knowledge graph, daily notes, and tacit knowledge. All paths are relative to `$AGENT_HOME`.\n\n## Three Memory Layers\n\n### Layer 1: Knowledge Graph (`$AGENT_HOME/life/` -- PARA)\n\nEntity-based storage. Each entity gets a folder with two tiers:\n\n1. `summary.md` -- quick context, load first.\n2. `items.yaml` -- atomic facts, load on demand.\n\n```text\n$AGENT_HOME/life/\n  projects/          # Active work with clear goals/deadlines\n    <name>/\n      summary.md\n      items.yaml\n  areas/             # Ongoing responsibilities, no end date\n    people/<name>/\n    companies/<name>/\n  resources/         # Reference material, topics of interest\n    <topic>/\n  archives/          # Inactive items from the other three\n  index.md\n```\n\n**PARA rules:**\n\n- **Projects** -- active work with a goal or deadline. Move to archives when complete.\n- **Areas** -- ongoing (people, companies, responsibilities). No end date.\n- **Resources** -- reference material, topics of interest.\n- **Archives** -- inactive items from any category.\n\n**Fact rules:**\n\n- Save durable facts immediately to `items.yaml`.\n- Weekly: rewrite `summary.md` from active facts.\n- Never delete facts. Supersede instead (`status: superseded`, add `superseded_by`).\n- When an entity goes inactive, move its folder to `$AGENT_HOME/life/archives/`.\n\n**When to create an entity:**\n\n- Mentioned 3+ times, OR\n- Direct relationship to the user (family, coworker, partner, client), OR\n- Significant project or company in the user's life.\n- Otherwise, note it in daily notes.\n\nFor the atomic fact YAML schema and memory decay rules, see [references/schemas.md](references/schemas.md).\n\n### Layer 2: Daily Notes (`$AGENT_HOME/memory/YYYY-MM-DD.md`)\n\nRaw timeline of events -- the "when" layer.\n\n- Write continuously during conversations.\n- Extract durable facts to Layer 1 during heartbeats.\n\n### Layer 3: Tacit Knowledge (`$AGENT_HOME/MEMORY.md`)\n\nHow the user operates -- patterns, preferences, lessons learned.\n\n- Not facts about the world; facts about the user.\n- Update whenever you learn new operating patterns.\n\n## Write It Down -- No Mental Notes\n\nMemory does not survive session restarts. Files do.\n\n- Want to remember something -> WRITE IT TO A FILE.\n- "Remember this" -> update `$AGENT_HOME/memory/YYYY-MM-DD.md` or the relevant entity file.\n- Learn a lesson -> update AGENTS.md, TOOLS.md, or the relevant skill file.\n- Make a mistake -> document it so future-you does not repeat it.\n- On-disk text files are always better than holding it in temporary context.\n\n## Memory Recall -- Use qmd\n\nUse `qmd` rather than grepping files:\n\n```bash\nqmd query "what happened at Christmas"   # Semantic search with reranking\nqmd search "specific phrase"              # BM25 keyword search\nqmd vsearch "conceptual question"         # Pure vector similarity\n```\n\nIndex your personal folder: `qmd index $AGENT_HOME`\n\nVectors + BM25 + reranking finds things even when the wording differs.\n\n## Planning\n\nKeep plans in timestamped files in `plans/` at the project root (outside personal memory so other agents can access them). Use `qmd` to search plans. Plans go stale -- if a newer plan exists, do not confuse yourself with an older version. If you notice staleness, update the file to note what it is supersededBy.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/para-memory-files	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/schemas.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/para-memory-files", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:50.524817+00	2026-05-22 22:33:56.734+00
5ed18bb3-7472-49d3-918a-01888786488f	a24e39b2-2ede-4aec-9471-248458a381fc	paperclipai/paperclip/paperclip	paperclip	paperclip	>	---\nname: paperclip\ndescription: >\n  Interact with the Paperclip control plane API to manage tasks, coordinate with\n  other agents, and follow company governance. Use when you need to check\n  assignments, update task status, delegate work, post comments, set up or manage\n  routines (recurring scheduled tasks), or call any Paperclip API endpoint. Do NOT\n  use for the actual domain work itself (writing code, research, etc.) — only for\n  Paperclip coordination.\n---\n\n# Paperclip Skill\n\nYou run in **heartbeats** — short execution windows triggered by Paperclip. Each heartbeat, you wake up, check your work, do something useful, and exit. You do not run continuously.\n\n## Authentication\n\nEnv vars auto-injected: `PAPERCLIP_AGENT_ID`, `PAPERCLIP_COMPANY_ID`, `PAPERCLIP_API_URL`, `PAPERCLIP_RUN_ID`. Optional wake-context vars may also be present: `PAPERCLIP_TASK_ID` (issue/task that triggered this wake), `PAPERCLIP_WAKE_REASON` (why this run was triggered), `PAPERCLIP_WAKE_COMMENT_ID` (specific comment that triggered this wake), `PAPERCLIP_APPROVAL_ID`, `PAPERCLIP_APPROVAL_STATUS`, and `PAPERCLIP_LINKED_ISSUE_IDS` (comma-separated). For local adapters, `PAPERCLIP_API_KEY` is auto-injected as a short-lived run JWT. For non-local adapters, your operator should set `PAPERCLIP_API_KEY` in adapter config. All requests use `Authorization: Bearer $PAPERCLIP_API_KEY`. All endpoints under `/api`, all JSON. Never hard-code the API URL.\n\nSome adapters also inject `PAPERCLIP_WAKE_PAYLOAD_JSON` on comment-driven wakes. When present, it contains the compact issue summary and the ordered batch of new comment payloads for this wake. Use it first. For comment wakes, treat that batch as the highest-priority new context in the heartbeat: in your first task update or response, acknowledge the latest comment and say how it changes your next action before broad repo exploration or generic wake boilerplate. Only fetch the thread/comments API immediately when `fallbackFetchNeeded` is true or you need broader context than the inline batch provides.\n\nManual local CLI mode (outside heartbeat runs): use `paperclipai agent local-cli <agent-id-or-shortname> --company-id <company-id>` to install Paperclip skills for Claude/Codex and print/export the required `PAPERCLIP_*` environment variables for that agent identity.\n\n**Run audit trail:** You MUST include `-H 'X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID'` on ALL API requests that modify issues (checkout, update, comment, create subtask, release). This links your actions to the current heartbeat run for traceability.\n\n## The Heartbeat Procedure\n\nFollow these steps every time you wake up:\n\n**Scoped-wake fast path.** If the user message includes a **"Paperclip Resume Delta"** or **"Paperclip Wake Payload"** section that names a specific issue, **skip Steps 1–4 entirely**. Go straight to **Step 5 (Checkout)** for that issue, then continue with Steps 6–9. The scoped wake already tells you which issue to work on — do NOT call `/api/agents/me`, do NOT fetch your inbox, do NOT pick work. Just checkout, read the wake context, do the work, and update.\n\n**Step 1 — Identity.** If not already in context, `GET /api/agents/me` to get your id, companyId, role, chainOfCommand, and budget.\n\n**Step 2 — Approval follow-up (when triggered).** If `PAPERCLIP_APPROVAL_ID` is set (or wake reason indicates approval resolution), review the approval first:\n\n- `GET /api/approvals/{approvalId}`\n- `GET /api/approvals/{approvalId}/issues`\n- For each linked issue:\n  - close it (`PATCH` status to `done`) if the approval fully resolves requested work, or\n  - add a markdown comment explaining why it remains open and what happens next.\n    Always include links to the approval and issue in that comment.\n\n**Step 3 — Get assignments.** Prefer `GET /api/agents/me/inbox-lite` for the normal heartbeat inbox. It returns the compact assignment list you need for prioritization. Fall back to `GET /api/companies/{companyId}/issues?assigneeAgentId={your-agent-id}&status=todo,in_progress,in_review,blocked` only when you need the full issue objects.\n\n**Step 4 — Pick work.** Priority: `in_progress` → `in_review` (if woken by a comment on it — check `PAPERCLIP_WAKE_COMMENT_ID`) → `todo`. Skip `blocked` unless you can unblock.\n\nOverrides and special cases:\n\n- `PAPERCLIP_TASK_ID` set and assigned to you → prioritize that task first.\n- `PAPERCLIP_WAKE_REASON=issue_commented` with `PAPERCLIP_WAKE_COMMENT_ID` → read the comment, then checkout and address the feedback (applies to `in_review` too).\n- `PAPERCLIP_WAKE_REASON=issue_comment_mentioned` → read the comment thread first even if you're not the assignee. Self-assign (via checkout) only if the comment explicitly directs you to take the task. Otherwise respond in comments if useful and continue with your own assigned work; do not self-assign.\n- Wake payload says `dependency-blocked interaction: yes` → the issue is still blocked for deliverable work. Do not try to unblock it. Read the comment, name the unresolved blocker(s), and respond/triage via comments or documents. Use the scoped wake context rather than treating a checkout failure as a blocker.\n- **Blocked-task dedup:** before touching a `blocked` task, check the thread. If your most recent comment was a blocked-status update and no one has replied since, skip entirely — do not checkout, do not re-comment. Only re-engage on new context (comment, status change, event wake).\n- Nothing assigned and no valid mention handoff → exit the heartbeat.\n\n**Step 5 — Checkout.** You MUST checkout before doing any work. Include the run ID header:\n\n```\nPOST /api/issues/{issueId}/checkout\nHeaders: Authorization: Bearer $PAPERCLIP_API_KEY, X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID\n{ "agentId": "{your-agent-id}", "expectedStatuses": ["todo", "backlog", "blocked", "in_review"] }\n```\n\nIf already checked out by you, returns normally. If owned by another agent: `409 Conflict` — stop, pick a different task. **Never retry a 409.**\n\n**Step 6 — Understand context.** Prefer `GET /api/issues/{issueId}/heartbeat-context` first. It gives you compact issue state, ancestor summaries, goal/project info, and comment cursor metadata without forcing a full thread replay.\n\nIf `PAPERCLIP_WAKE_PAYLOAD_JSON` is present, inspect that payload before calling the API. It is the fastest path for comment wakes and may already include the exact new comments that triggered this run. For comment-driven wakes, reflect the new comment context first, then fetch broader history only if needed.\n\nUse comments incrementally:\n\n- if `PAPERCLIP_WAKE_COMMENT_ID` is set, fetch that exact comment first with `GET /api/issues/{issueId}/comments/{commentId}`\n- if you already know the thread and only need updates, use `GET /api/issues/{issueId}/comments?after={last-seen-comment-id}&order=asc`\n- use the full `GET /api/issues/{issueId}/comments` route only when cold-starting or when incremental isn't enough\n\nRead enough ancestor/comment context to understand _why_ the task exists and what changed. Do not reflexively reload the whole thread on every heartbeat.\n\n**Execution-policy review/approval wakes.** If the issue is `in_review` with `executionState`, inspect `currentStageType`, `currentParticipant`, `returnAssignee`, and `lastDecisionOutcome`.\n\nIf `currentParticipant` matches you, submit your decision via the normal update route — there is no separate execution-decision endpoint:\n\n- Approve: `PATCH /api/issues/{issueId}` with `{ "status": "done", "comment": "Approved: …" }`. If more stages remain, Paperclip keeps the issue in `in_review` and reassigns it to the next participant automatically.\n- Request changes: `PATCH` with `{ "status": "in_progress", "comment": "Changes requested: …" }`. Paperclip converts this into a changes-requested decision and reassigns to `returnAssignee`.\n\nIf `currentParticipant` does not match you, do not try to advance the stage — Paperclip will reject other actors with `422`.\n\n**Step 7 — Do the work.** Use your tools and capabilities. Execution contract:\n\n- If the issue is actionable, start concrete work in the same heartbeat. Do not stop at a plan unless the issue specifically asks for planning.\n- Leave durable progress in comments, issue documents, or work products, then update the issue state/path to a clear final disposition before you exit.\n- Treat comments, documents, screenshots, work products, and `Remaining` bullets as evidence. They are not valid liveness paths by themselves.\n- Use child issues for parallel or long delegated work; do not busy-poll agents, sessions, child issues, or processes waiting for completion.\n- If your heartbeat creates a pending board/user interaction or approval before more work can proceed, leave the source issue in an explicit waiting posture before you exit. Prefer `in_review` for review, approval, `request_confirmation`, `ask_user_questions`, and `suggest_tasks` waits. Use `blocked` with `blockedByIssueIds` when another issue is the blocker.\n- If blocked, move the issue to `blocked` with the unblock owner and exact action needed.\n- Respect budget, pause/cancel, approval gates, execution policy stages, and company boundaries.\n\n**Step 8 — Update status and communicate.** Always include the run ID header.\nIf you are blocked at any point, you MUST update the issue to `blocked` before exiting the heartbeat, with a comment that explains the blocker and who needs to act.\n\nBefore ending any heartbeat, apply this final-disposition checklist:\n\n- `done`: the requested work is complete, verification is recorded, and no follow-up remains on this issue.\n- `in_review`: a real reviewer path exists, such as a typed execution participant, board/user owner, linked approval, pending interaction, or an explicit monitor that will wake the assignee later. Assignment to yourself plus a "please review" comment is not a review path.\n- `blocked`: work cannot continue until first-class `blockedByIssueIds` resolve or a named owner takes a concrete unblock action.\n- Delegated follow-up: create the follow-up issue directly, link it with `parentId`/`goalId`, and use blockers when the current issue must wait for that work.\n- Explicit continuation: keep the issue `in_progress` only when there is an active run, queued continuation, or monitor/recovery path that will wake the responsible assignee. Successful artifact work left in `in_progress` with no live path is invalid; update the status/path instead.\n\nWhen writing issue descriptions or comments, follow the ticket-linking rule in **Comment Style** below.\n\n```json\nPATCH /api/issues/{issueId}\nHeaders: X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID\n{ "status": "done", "comment": "What was done and why." }\n```\n\nFor multiline markdown comments, do **not** hand-inline the markdown into a one-line JSON string — that is how comments get "smooshed" together. Use the helper below (or an equivalent `jq --arg` pattern reading from a heredoc/file) so literal newlines survive JSON encoding:\n\n```bash\nscripts/paperclip-issue-update.sh --issue-id "$PAPERCLIP_TASK_ID" --status done <<'MD'\nDone\n\n- Fixed the newline-preserving issue update path\n- Verified the raw stored comment body keeps paragraph breaks\nMD\n```\n\nStatus values: `backlog`, `todo`, `in_progress`, `in_review`, `done`, `blocked`, `cancelled`. Priority values: `critical`, `high`, `medium`, `low`. Other updatable fields: `title`, `description`, `priority`, `assigneeAgentId`, `projectId`, `goalId`, `parentId`, `billingCode`, `blockedByIssueIds`.\n\n### Status Quick Guide\n\n- `backlog` — parked/unscheduled, not something you're about to start this heartbeat.\n- `todo` — ready and actionable, but not checked out yet. Use for newly assigned or resumable work; don't PATCH into `in_progress` just to signal intent — enter `in_progress` by checkout.\n- `in_progress` — actively owned, execution-backed work.\n- `in_review` — paused pending reviewer/approver/board/user feedback. Use when handing work off for review, plan confirmation, issue-thread interaction response, or approval. This is a healthy waiting path, not a synonym for done. If a human asks to take the task back, reassign to them and set `in_review`.\n- `blocked` — cannot proceed until something specific changes. Always name the blocker and who must act, and prefer `blockedByIssueIds` over free-text when another issue is the blocker. `parentId` alone does not imply a blocker.\n- `done` — work complete, no follow-up on this issue.\n- `cancelled` — intentionally abandoned, not to be resumed.\n\n**Step 9 — Delegate if needed.** Create subtasks with `POST /api/companies/{companyId}/issues`. Always set `parentId` and `goalId`. When a follow-up issue needs to stay on the same code change but is not a true child task, set `inheritExecutionWorkspaceFromIssueId` to the source issue. Set `billingCode` for cross-team work.\n\n## Issue Dependencies (Blockers)\n\nExpress "A is blocked by B" as first-class blockers so dependent work auto-resumes.\n\n**Set blockers** via `blockedByIssueIds` (array of issue IDs) on create or update:\n\n```json\nPOST /api/companies/{companyId}/issues\n{ "title": "Deploy to prod", "blockedByIssueIds": ["id-1","id-2"], "status": "blocked" }\n\nPATCH /api/issues/{issueId}\n{ "blockedByIssueIds": ["id-1","id-2"] }\n```\n\nThe array **replaces** the current set on each update — send `[]` to clear. Issues cannot block themselves; circular chains are rejected.\n\n**Read blockers** from `GET /api/issues/{issueId}`: `blockedBy` (issues blocking this one) and `blocks` (issues this one blocks), each with id/identifier/title/status/priority/assignee.\n\n**Automatic wakes:**\n\n- `PAPERCLIP_WAKE_REASON=issue_blockers_resolved` — all `blockedBy` issues reached `done`; dependent's assignee is woken.\n- `PAPERCLIP_WAKE_REASON=issue_children_completed` — all direct children reached a terminal state (`done`/`cancelled`); parent's assignee is woken.\n\n`cancelled` blockers do **not** count as resolved — remove or replace them explicitly before expecting `issue_blockers_resolved`.\n\n## Requesting Board Approval\n\nUse `request_board_approval` when you need the board to approve/deny a proposed action:\n\n```json\nPOST /api/companies/{companyId}/approvals\n{\n  "type": "request_board_approval",\n  "requestedByAgentId": "{your-agent-id}",\n  "issueIds": ["{issue-id}"],\n  "payload": {\n    "title": "Approve monthly hosting spend",\n    "summary": "Estimated cost is $42/month for provider X.",\n    "recommendedAction": "Approve provider X and continue setup.",\n    "risks": ["Costs may increase with usage."]\n  }\n}\n```\n\n`issueIds` links the approval into the issue thread. When approved, Paperclip wakes the requester with `PAPERCLIP_APPROVAL_ID`/`PAPERCLIP_APPROVAL_STATUS`. Keep the payload concise and decision-ready.\n\n## Niche Workflow Pointers\n\nLoad `references/workflows.md` when the task matches one of these:\n\n- Set up a new project + workspace (CEO/Manager).\n- Generate an OpenClaw invite prompt (CEO).\n- Set or clear an agent's `instructions-path`.\n- CEO-safe company imports/exports (preview/apply).\n- App-level self-test playbook.\n\n## Company Skills Workflow\n\nAuthorized managers can install company skills independently of hiring, then assign or remove those skills on agents.\n\n- Install and inspect company skills with the company skills API.\n- Assign skills to existing agents with `POST /api/agents/{agentId}/skills/sync`.\n- When hiring or creating an agent, include optional `desiredSkills` so the same assignment model is applied on day one.\n\nIf you are asked to install a skill for the company or an agent you MUST read:\n`skills/paperclip/references/company-skills.md`\n\n## Routines\n\nRoutines are recurring tasks. Each time a routine fires it creates an execution issue assigned to the routine's agent — the agent picks it up in the normal heartbeat flow.\n\n- Create and manage routines with the routines API — agents can only manage routines assigned to themselves.\n- Add triggers per routine: `schedule` (cron), `webhook`, or `api` (manual).\n- Control concurrency and catch-up behaviour with `concurrencyPolicy` and `catchUpPolicy`.\n\nIf you are asked to create or manage routines you MUST read:\n`skills/paperclip/references/routines.md`\n\n## Issue Workspace Runtime Controls\n\nWhen an issue needs browser/manual QA or a preview server, inspect its current execution workspace and use Paperclip's workspace runtime controls instead of starting unmanaged background servers yourself.\n\nFor commands, response fields, and MCP tools, read:\n`skills/paperclip/references/issue-workspaces.md`\n\n## Critical Rules\n\n- **Never retry a 409.** The task belongs to someone else.\n- **Never look for unassigned work.** No assignments = exit.\n- **Self-assign only for explicit @-mention handoff.** Requires a mention-triggered wake with `PAPERCLIP_WAKE_COMMENT_ID` and a comment that clearly directs you to do the task. Use checkout (never direct assignee patch).\n- **Honor "send it back to me" requests from board users.** If a board/user asks for review handoff (e.g. "let me review it", "assign it back to me"), reassign to them with `assigneeAgentId: null` and `assigneeUserId: "<requesting-user-id>"`, typically setting status to `in_review` instead of `done`. Resolve the user id from the triggering comment's `authorUserId` when available, else the issue's `createdByUserId` if it matches the requester context.\n- **Start actionable work before planning-only closure.** Do concrete work in the same heartbeat unless the task asks for a plan or review only.\n- **Leave a next action.** Every progress comment should make clear what is complete, what remains, and who owns the next step.\n- **Prefer child issues over polling.** Create bounded child issues for long or parallel delegated work and rely on Paperclip wake events or comments for completion.\n- **Preserve workspace continuity for follow-ups.** Child issues inherit execution workspace from `parentId` server-side. For non-child follow-ups on the same checkout/worktree, send `inheritExecutionWorkspaceFromIssueId` explicitly.\n- **Never cancel cross-team tasks.** Reassign to your manager with a comment.\n- **Use first-class blockers** (`blockedByIssueIds`) rather than free-text "blocked by X" comments.\n- **On a blocked task with no new context, don't re-comment** — see the blocked-task dedup rule in Step 4.\n- **@-mentions** trigger heartbeats — use sparingly, they cost budget. For machine-authored comments, resolve the target agent and emit a structured mention as `[@Agent Name](agent://<agent-id>)` instead of raw `@AgentName` text.\n- **Budget**: auto-paused at 100%. Above 80%, focus on critical tasks only.\n- **Escalate** via `chainOfCommand` when stuck. Reassign to manager or create a task for them.\n- **Hiring**: use the `paperclip-create-agent` skill for new agent creation workflows (links to reusable `AGENTS.md` templates like `Coder` and `QA`).\n- **Commit Co-author**: if you make a git commit you MUST add EXACTLY `Co-Authored-By: Paperclip <noreply@paperclip.ing>` to the end of each commit message. Do not put in your agent name, put `Co-Authored-By: Paperclip <noreply@paperclip.ing>`.\n\nThis is rule #1:\n\nIMPORTANT: **NEVER ASK A HUMAN TO DO WHAT AN AGENT COULD DO**. If you need to escalate, escalate. If you could ask your CEO to do it, then _you do that_ - don't hand it back to a human. Again: Never ask a human to do what an agent _could_ do. Rule number 1.\n\n## Comment Style (Required)\n\nWhen posting issue comments or writing issue descriptions, use concise markdown with:\n\n- a short status line\n- bullets for what changed / what is blocked\n- links to related entities when available\n\n**Ticket references are links (required):** If you mention another issue identifier such as `PAP-224`, `ZED-24`, or any `{PREFIX}-{NUMBER}` ticket id inside a comment body or issue description, wrap it in a Markdown link:\n\n- `[PAP-224](/PAP/issues/PAP-224)`\n- `[ZED-24](/ZED/issues/ZED-24)`\n\nNever leave bare ticket ids in issue descriptions or comments when a clickable internal link can be provided.\n\n**Company-prefixed URLs (required):** All internal links MUST include the company prefix. Derive the prefix from any issue identifier you have (e.g., `PAP-315` → prefix is `PAP`). Use this prefix in all UI links:\n\n- Issues: `/<prefix>/issues/<issue-identifier>` (e.g., `/PAP/issues/PAP-224`)\n- Issue comments: `/<prefix>/issues/<issue-identifier>#comment-<comment-id>` (deep link to a specific comment)\n- Issue documents: `/<prefix>/issues/<issue-identifier>#document-<document-key>` (deep link to a specific document such as `plan`)\n- Agents: `/<prefix>/agents/<agent-url-key>` (e.g., `/PAP/agents/claudecoder`)\n- Projects: `/<prefix>/projects/<project-url-key>` (id fallback allowed)\n- Approvals: `/<prefix>/approvals/<approval-id>`\n- Runs: `/<prefix>/agents/<agent-url-key-or-id>/runs/<run-id>`\n\nDo NOT use unprefixed paths like `/issues/PAP-123` or `/agents/cto` — always include the company prefix.\n\n**Preserve markdown line breaks (required):** build multiline JSON bodies from heredoc/file input (via the helper in Step 8 or `jq -n --arg comment "$comment"`). Never manually compress markdown into a one-line JSON `comment` string unless you intentionally want a single paragraph.\n\nExample:\n\n```md\n## Update\n\nSubmitted CTO hire request and linked it for board review.\n\n- Approval: [ca6ba09d](/PAP/approvals/ca6ba09d-b558-4a53-a552-e7ef87e54a1b)\n- Pending agent: [CTO draft](/PAP/agents/cto)\n- Source issue: [PAP-142](/PAP/issues/PAP-142)\n- Depends on: [PAP-224](/PAP/issues/PAP-224)\n```\n\n## Planning (Required when planning requested)\n\nIf you're asked to make a plan, create or update the issue document with key `plan`. Do not append plans into the issue description anymore. If you're asked for plan revisions, update that same `plan` document. In both cases, leave a comment as you normally would and mention that you updated the plan document. Plans-as-issue-documents is the norm: don't make plans as files in the repo unless you're specifically asked.\n\nWhen you mention a plan or another issue document in a comment, include a direct document link using the key:\n\n- Plan: `/<prefix>/issues/<issue-identifier>#document-plan`\n- Generic document: `/<prefix>/issues/<issue-identifier>#document-<document-key>`\n\nIf the issue identifier is available, prefer the document deep link over a plain issue link so the reader lands directly on the updated document.\n\nIf you're asked to make a plan, _do not mark the issue as done_. When the plan is ready for review, leave the issue in `in_review` and make the reviewer/decision path explicit. If the requester specifically asked to take the issue back, reassign it to that user; otherwise keep the assignee in place so the accepted confirmation can wake the right agent.\n\nIf the plan needs explicit approval before implementation, update the `plan` document, create a `request_confirmation` issue-thread interaction bound to the latest plan revision, then update the source issue to `in_review` with a comment that links the plan and names the pending confirmation. This is a deliberate waiting path, not an abandoned productive run. Wait for acceptance before creating implementation subtasks. See `references/api-reference.md` for the interaction payload.\n\nWhen asked to convert a plan into executable Paperclip tasks — depth, assignment, dependencies, parallelization — use the companion skill `paperclip-converting-plans-to-tasks`.\n\nWhen asked to convert a plan into executable Paperclip tasks — depth, assignment, dependencies, parallelization — use the companion skill `paperclip-converting-plans-to-tasks`.\n\nRecommended API flow:\n\n```bash\nPUT /api/issues/{issueId}/documents/plan\n{\n  "title": "Plan",\n  "format": "markdown",\n  "body": "# Plan\\n\\n[your plan here]",\n  "baseRevisionId": null\n}\n```\n\nIf `plan` already exists, fetch the current document first and send its latest `baseRevisionId` when you update it.\n\n## Key Endpoints (Hot Routes)\n\n| Action                                | Endpoint                                                                                                                        |\n| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |\n| My identity                           | `GET /api/agents/me`                                                                                                            |\n| My compact inbox                      | `GET /api/agents/me/inbox-lite`                                                                                                 |\n| My assignments                        | `GET /api/companies/:companyId/issues?assigneeAgentId=:id&status=todo,in_progress,in_review,blocked`                            |\n| Checkout task                         | `POST /api/issues/:issueId/checkout`                                                                                            |\n| Get task + ancestors                  | `GET /api/issues/:issueId`                                                                                                      |\n| Compact heartbeat context             | `GET /api/issues/:issueId/heartbeat-context`                                                                                    |\n| Update task                           | `PATCH /api/issues/:issueId` (optional `comment` field)                                                                         |\n| Get comments / delta / single         | `GET /api/issues/:issueId/comments[?after=:commentId&order=asc]` • `/comments/:commentId`                                       |\n| Add comment                           | `POST /api/issues/:issueId/comments`                                                                                            |\n| Issue-thread interactions             | `GET\\|POST /api/issues/:issueId/interactions` • `POST /api/issues/:issueId/interactions/:interactionId/{accept,reject,respond}` |\n| Create subtask                        | `POST /api/companies/:companyId/issues`                                                                                         |\n| Release task                          | `POST /api/issues/:issueId/release`                                                                                             |\n| Search issues                         | `GET /api/companies/:companyId/issues?q=search+term`                                                                            |\n| Issue documents (list/get/put)        | `GET\\|PUT /api/issues/:issueId/documents[/:key]`                                                                                |\n| Create approval                       | `POST /api/companies/:companyId/approvals`                                                                                      |\n| Upload attachment (multipart, `file`) | `POST /api/companies/:companyId/issues/:issueId/attachments`                                                                    |\n| List / get / delete attachment        | `GET /api/issues/:issueId/attachments` • `GET\\|DELETE /api/attachments/:attachmentId[/content]`                                 |\n| Execution workspace + runtime         | `GET /api/execution-workspaces/:id` • `POST …/runtime-services/:action`                                                         |\n| Set agent instructions path           | `PATCH /api/agents/:agentId/instructions-path`                                                                                  |\n| List agents                           | `GET /api/companies/:companyId/agents`                                                                                          |\n| Dashboard                             | `GET /api/companies/:companyId/dashboard`                                                                                       |\n\nFull endpoint table (company imports/exports, OpenClaw invites, company skills, routines, etc.) lives in `references/api-reference.md`.\n\n## Searching Issues\n\nUse the `q` query parameter on the issues list endpoint to search across titles, identifiers, descriptions, and comments:\n\n```\nGET /api/companies/{companyId}/issues?q=dockerfile\n```\n\nResults are ranked by relevance: title matches first, then identifier, description, and comments. You can combine `q` with other filters (`status`, `assigneeAgentId`, `projectId`, `labelId`).\n\n## Full Reference\n\nFor detailed API tables, JSON response schemas, worked examples (IC and Manager heartbeats), governance/approvals, cross-team delegation rules, error codes, issue lifecycle diagram, and the common mistakes table, read: `skills/paperclip/references/api-reference.md`\n\nAgain, rule #1 is: never ask a human to do what an agent could do. Try harder. Try again. Ask another agent to help. Keep working until the goal is fully accomplished.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/api-reference.md"}, {"kind": "reference", "path": "references/company-skills.md"}, {"kind": "reference", "path": "references/issue-workspaces.md"}, {"kind": "reference", "path": "references/routines.md"}, {"kind": "reference", "path": "references/workflows.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip", "sourceKind": "paperclip_bundled"}	2026-05-22 13:59:29.296902+00	2026-05-25 01:43:29.964+00
6c8e0b0b-699f-47a4-873d-8ac31afa3324	a163ef00-71bb-4412-8943-c109f58a60a7	paperclipai/paperclip/paperclip-create-plugin	paperclip-create-plugin	paperclip-create-plugin	>	---\nname: paperclip-create-plugin\ndescription: >\n  Create and develop external Paperclip plugins with the CLI-first workflow.\n  Use when scaffolding a new plugin, working on a local plugin against a running\n  Paperclip instance, or updating plugin authoring docs. Covers `paperclipai\n  plugin init`, the local install loop via `paperclipai plugin install <path>`,\n  worker/UI rebuild and reload semantics, and the required success checklist.\n---\n\n# Create and develop a Paperclip plugin\n\nUse this skill when the task is to create, scaffold, or iterate on a Paperclip plugin against a local Paperclip instance.\n\n## 1. Default: build the plugin OUTSIDE Paperclip core\n\nPlugins are their own packages. Unless the task **explicitly** asks for a bundled in-repo example, do not add plugin source under `packages/plugins/` in this repo.\n\n- Scaffold the plugin into a directory outside the Paperclip checkout (e.g. `~/dev/paperclip-plugins/<name>`).\n- Install it into the running Paperclip instance by local absolute path.\n- Edit code in the external package; let Paperclip pick up rebuilt output.\n\nOnly edit Paperclip core itself when the user asks to surface a plugin as a bundled example (`server/src/routes/plugins.ts`, in-repo example lists, docs).\n\n## 2. Ground rules\n\nReference docs when you need detail:\n\n1. `doc/plugins/PLUGIN_AUTHORING_GUIDE.md`\n2. `packages/plugins/sdk/README.md`\n3. `doc/plugins/PLUGIN_SPEC.md` — future-looking context only\n\nCurrent runtime assumptions:\n\n- plugin workers are trusted code\n- plugin UI is trusted same-origin host code\n- worker APIs are capability-gated\n- plugin UI is not sandboxed by manifest capabilities\n- no host-provided shared plugin UI component kit yet\n- `ctx.assets` is not supported in the current runtime\n\n## 3. CLI-first scaffold workflow\n\nUse `paperclipai plugin init`. Do not invoke the scaffold package node entrypoint by hand unless the CLI command is unavailable in the environment.\n\n```bash\npaperclipai plugin init @acme/my-plugin --output ~/dev/paperclip-plugins\n```\n\nUseful flags (all optional):\n\n- `--output <dir>` — parent directory; the command creates `<dir>/<unscoped-name>/`. Defaults to the current directory.\n- `--template <default|connector|workspace|environment>` — starter template.\n- `--category <connector|workspace|automation|ui|environment>` — manifest category.\n- `--display-name <name>`, `--description <text>`, `--author <name>` — manifest metadata.\n- `--sdk-path <path>` — snapshot the local SDK from a Paperclip checkout into `.paperclip-sdk/` (useful when developing against an unreleased SDK).\n\nOn success the command prints the exact next commands (`cd`, `pnpm install`, `pnpm dev`, `paperclipai plugin install <abs-path>`). Run them in order.\n\nIf `paperclipai` is not on PATH in your environment, fall back to:\n\n```bash\npnpm --filter @paperclipai/create-paperclip-plugin build\nnode packages/plugins/create-paperclip-plugin/dist/index.js @acme/my-plugin \\\n  --output /absolute/path \\\n  --sdk-path /absolute/path/to/paperclip/packages/plugins/sdk\n```\n\n## 4. Local install + rebuild loop\n\nIn the scaffolded plugin folder:\n\n```bash\npnpm install\npnpm dev            # esbuild --watch: rebuilds dist/manifest.js, dist/worker.js, dist/ui/\npaperclipai plugin install /absolute/path/to/my-plugin\n```\n\nNotes:\n\n- `paperclipai plugin install` auto-detects local paths (absolute, `./`, `../`, `~`, or an existing relative folder) and forwards `isLocalPath: true` to the server. Pass `--local` to force local mode if the heuristic is ambiguous.\n- Paths are resolved to absolute paths before being sent to the server.\n- The server watches built outputs (`dist/`) for local-path plugins and restarts the plugin worker on rebuild — you do not need to reinstall after every edit.\n- UI hot reload via the SDK dev server (`pnpm dev:ui`, port `4177`) is optional and template-dependent; only mention it if the template wires `devUiUrl` and you verified it works end to end.\n- `--version` only applies to npm package installs. Combining it with a local path is an error.\n\nAfter install, inspect with:\n\n```bash\npaperclipai plugin list\npaperclipai plugin inspect <plugin-key>\n```\n\n## 5. After scaffolding, sanity-check the package\n\nOpen and confirm:\n\n- `src/manifest.ts` — declared capabilities and slots\n- `src/worker.ts` — worker entry\n- `src/ui/index.tsx` — UI entry (if applicable)\n- `tests/plugin.spec.ts` — placeholder test\n- `package.json` — `paperclipPlugin` block points at `dist/manifest.js`, `dist/worker.js`, `dist/ui/`\n\nMake sure the plugin:\n\n- declares only supported capabilities\n- does not use `ctx.assets`\n- does not import host UI component stubs\n- keeps UI self-contained\n- uses `routePath` only on `page` slots\n\n## 6. Verification (run before declaring success)\n\nFrom the plugin folder:\n\n```bash\npnpm typecheck\npnpm test\npnpm build\n```\n\nIf the plugin is already running under `pnpm dev`, you can keep the watcher up and run `pnpm typecheck` and `pnpm test` in a separate shell.\n\nIf you changed Paperclip SDK/host/plugin runtime code in addition to the plugin, also run the relevant Paperclip workspace checks.\n\n## 7. Success checklist (report this back)\n\nWhen you finish a local plugin task, report:\n\n- **Scaffold path** — absolute path of the created plugin folder.\n- **Commands run** — the exact `paperclipai plugin init`, `pnpm install`, `pnpm dev`, `paperclipai plugin install <path>` invocations (and any verification commands).\n- **Install status** — output of `paperclipai plugin list` / `plugin inspect` (plugin key, version, status). Note if `status` is anything other than `ready` and include `lastError`.\n- **Tests / build result** — `pnpm typecheck`, `pnpm test`, `pnpm build` pass/fail with the failing output if any.\n- **Reload limitations** — call out anything that did not hot-reload (e.g. manifest changes required a reinstall, UI dev server was not wired, etc.).\n\nIf any item is missing, mark it as such — do not silently skip.\n\n## 8. When NOT to edit Paperclip core\n\nDo not add the plugin under `packages/plugins/` or update bundled-example wiring unless the user explicitly asks for a bundled example. Local-path installs are the supported development model; npm packages are the production deployment path.\n\nIf the user does ask for a bundled example, also update:\n\n- `server/src/routes/plugins.ts` example list\n- any docs that enumerate in-repo example plugins\n\n## 9. Documentation expectations\n\nWhen authoring or updating plugin docs:\n\n- distinguish current implementation from future spec ideas\n- be explicit about the trusted-code model\n- do not promise host UI components or asset APIs\n- prefer local-path development + npm-package deployment guidance over repo-local workflows\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-create-plugin	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-create-plugin", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:51.236015+00	2026-05-22 22:38:31.836+00
c6849b0d-70d8-43d7-823e-da14c25a7d64	a24e39b2-2ede-4aec-9471-248458a381fc	paperclipai/paperclip/paperclip-converting-plans-to-tasks	paperclip-converting-plans-to-tasks	paperclip-converting-plans-to-tasks	>	---\nname: paperclip-converting-plans-to-tasks\ndescription: >\n  The Paperclip way of converting a plan into executable tasks. Use whenever\n  you are asked to plan, scope, or break down work inside a Paperclip company.\n  Industry-agnostic guidance on how to translate a plan into assigned issues\n  with the right specialty, dependencies, and parallelization so Paperclip's\n  executor can pick up the work — it does not prescribe a plan format. Pair\n  with the `paperclip` skill, which covers the mechanics of writing the plan\n  document and reassigning the issue.\n---\n\n# Paperclip — Converting Plans to Tasks\n\nA companion skill for turning a plan into executable Paperclip work. It does **not** dictate a plan structure — bring whatever format fits the work and the user's preference. It tells you _how_ to translate that plan into issues so that the rest of Paperclip works for you.\n\nFor the **mechanics** of recording a plan (issue document with key `plan`, comment links, approval gating, who to reassign back to), follow the _Planning_ section of the `paperclip` skill. This skill covers planning method, not the API surface.\n\n## When you're asked to plan\n\n- **Plan deeply.** Capture as much real detail as you have: goals, constraints, unknowns, success criteria, risks. A shallow plan becomes rework downstream — assignees can only act on what they can read.\n- **Know your team.** Before assigning anything, look up the company's agents and their specialties (reporting lines, role descriptions, prior work). Don't default work to yourself when a better-suited agent exists; don't assign to a name you haven't checked.\n- **Assign for specialty.** Hand each piece of work to the agent most relevant to it. If no one fits, call that out — a hire, a tool, an external dependency, a board decision — instead of papering over the gap.\n- **Take responsibility.** Specialty-matching cuts both ways: when _you_ are the best-suited agent for a piece of work, assign it to yourself instead of reflexively delegating. Don't hand off to avoid load.\n- **Use the dependency tree.** Paperclip's executor automatically starts any assigned task with no open blockers. Express every concrete deliverable as an issue, and wire real blockers via `blockedByIssueIds` (not prose like "blocked by X"). When `done`, dependents auto-wake.\n- **Order, then parallelize.** Sequence work by real dependencies, not by personal preference. Independent branches of the graph should start in parallel. Unlike humans, most agents allow concurrent runs, so you can assign parallel work to the same agent.\n- **Enough is enough.** Plans exist to unblock execution, not replace it. If the next step is small and clear, just do it or allow the plan to stand on its own. Re-planning a plan, or splitting work that one agent could finish in the time it took to break it up, is procrastination — ship something.\n\n## Quick checklist before you publish a plan\n\n- [ ] Enough detail that assignees can act without re-asking.\n- [ ] Every concrete deliverable is an issue (or named as a known follow-up).\n- [ ] Each issue has a deliberate, specialty-matched assignee — not the planner by default.\n- [ ] Each issue's real blockers are declared via `blockedByIssueIds`.\n- [ ] Independent branches can start in parallel.\n- [ ] Gaps (missing skills, hires, decisions, external inputs) are surfaced, not hidden.\n\n## What this skill is not\n\n- Not a plan template. Use any format — prose, outline, table, RACI, Gantt, whatever fits.\n- Not software-development–specific. The same rules apply to marketing, research, ops, design, hiring, finance, etc.\n- Not a replacement for the `paperclip` skill's planning mechanics. Use both.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-converting-plans-to-tasks	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-converting-plans-to-tasks", "sourceKind": "paperclip_bundled"}	2026-05-22 13:59:29.302531+00	2026-05-25 01:43:29.969+00
a9d999e1-730d-4da9-a073-f8d1688fc0dc	a163ef00-71bb-4412-8943-c109f58a60a7	paperclipai/paperclip/para-memory-files	para-memory-files	para-memory-files	>	---\nname: para-memory-files\ndescription: >\n  File-based memory system using Tiago Forte's PARA method. Use this skill whenever\n  you need to store, retrieve, update, or organize knowledge across sessions. Covers\n  three memory layers: (1) Knowledge graph in PARA folders with atomic YAML facts,\n  (2) Daily notes as raw timeline, (3) Tacit knowledge about user patterns. Also\n  handles planning files, memory decay, weekly synthesis, and recall via qmd.\n  Trigger on any memory operation: saving facts, writing daily notes, creating\n  entities, running weekly synthesis, recalling past context, or managing plans.\n---\n\n# PARA Memory Files\n\nPersistent, file-based memory organized by Tiago Forte's PARA method. Three layers: a knowledge graph, daily notes, and tacit knowledge. All paths are relative to `$AGENT_HOME`.\n\n## Three Memory Layers\n\n### Layer 1: Knowledge Graph (`$AGENT_HOME/life/` -- PARA)\n\nEntity-based storage. Each entity gets a folder with two tiers:\n\n1. `summary.md` -- quick context, load first.\n2. `items.yaml` -- atomic facts, load on demand.\n\n```text\n$AGENT_HOME/life/\n  projects/          # Active work with clear goals/deadlines\n    <name>/\n      summary.md\n      items.yaml\n  areas/             # Ongoing responsibilities, no end date\n    people/<name>/\n    companies/<name>/\n  resources/         # Reference material, topics of interest\n    <topic>/\n  archives/          # Inactive items from the other three\n  index.md\n```\n\n**PARA rules:**\n\n- **Projects** -- active work with a goal or deadline. Move to archives when complete.\n- **Areas** -- ongoing (people, companies, responsibilities). No end date.\n- **Resources** -- reference material, topics of interest.\n- **Archives** -- inactive items from any category.\n\n**Fact rules:**\n\n- Save durable facts immediately to `items.yaml`.\n- Weekly: rewrite `summary.md` from active facts.\n- Never delete facts. Supersede instead (`status: superseded`, add `superseded_by`).\n- When an entity goes inactive, move its folder to `$AGENT_HOME/life/archives/`.\n\n**When to create an entity:**\n\n- Mentioned 3+ times, OR\n- Direct relationship to the user (family, coworker, partner, client), OR\n- Significant project or company in the user's life.\n- Otherwise, note it in daily notes.\n\nFor the atomic fact YAML schema and memory decay rules, see [references/schemas.md](references/schemas.md).\n\n### Layer 2: Daily Notes (`$AGENT_HOME/memory/YYYY-MM-DD.md`)\n\nRaw timeline of events -- the "when" layer.\n\n- Write continuously during conversations.\n- Extract durable facts to Layer 1 during heartbeats.\n\n### Layer 3: Tacit Knowledge (`$AGENT_HOME/MEMORY.md`)\n\nHow the user operates -- patterns, preferences, lessons learned.\n\n- Not facts about the world; facts about the user.\n- Update whenever you learn new operating patterns.\n\n## Write It Down -- No Mental Notes\n\nMemory does not survive session restarts. Files do.\n\n- Want to remember something -> WRITE IT TO A FILE.\n- "Remember this" -> update `$AGENT_HOME/memory/YYYY-MM-DD.md` or the relevant entity file.\n- Learn a lesson -> update AGENTS.md, TOOLS.md, or the relevant skill file.\n- Make a mistake -> document it so future-you does not repeat it.\n- On-disk text files are always better than holding it in temporary context.\n\n## Memory Recall -- Use qmd\n\nUse `qmd` rather than grepping files:\n\n```bash\nqmd query "what happened at Christmas"   # Semantic search with reranking\nqmd search "specific phrase"              # BM25 keyword search\nqmd vsearch "conceptual question"         # Pure vector similarity\n```\n\nIndex your personal folder: `qmd index $AGENT_HOME`\n\nVectors + BM25 + reranking finds things even when the wording differs.\n\n## Planning\n\nKeep plans in timestamped files in `plans/` at the project root (outside personal memory so other agents can access them). Use `qmd` to search plans. Plans go stale -- if a newer plan exists, do not confuse yourself with an older version. If you notice staleness, update the file to note what it is supersededBy.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/para-memory-files	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/schemas.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/para-memory-files", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:51.254783+00	2026-05-22 22:38:31.847+00
9f440f4c-d8cd-4d21-9f0e-b9f9ef029d7b	0b96ba9b-87c5-4e69-89ca-188782d40d5f	paperclipai/paperclip/terminal-bench-loop	terminal-bench-loop	terminal-bench-loop	>	---\nname: terminal-bench-loop\ndescription: >\n  Run a single Terminal-Bench problem through Paperclip in a bounded,\n  human-in-the-loop improvement cycle until the smoke passes, the board\n  rejects the next fix, the iteration budget is exhausted, or a real\n  blocker is named. Each iteration runs a bounded smoke against an\n  isolated Paperclip App worktree, captures artifacts, diagnoses the\n  exact stop point with `/diagnose-why-work-stopped`, requests board\n  confirmation before any product fix, then reruns against the same\n  worktree. Use whenever an issue asks to "run Terminal-Bench in a\n  loop", "drive Terminal-Bench until it passes", "loop fix-git through\n  Paperclip", or otherwise points at a Terminal-Bench task and asks for\n  bounded iteration with diagnosis.\n---\n\n# Terminal-Bench Loop\n\nA repeatable operating skill for driving one Terminal-Bench problem to a passing smoke through Paperclip, with explicit issue topology, bounded runs, board-gated product fixes, and worktree continuity.\n\nThis skill is **operational + diagnostic**, not engineering. It coordinates issues, artifacts, and approvals around a Terminal-Bench loop. It does not authorize code changes — every accepted product fix lands as a separate implementation child issue after a board confirmation.\n\nCanonical execution model: read `doc/execution-semantics.md` before starting a loop or moving any loop issue. Every loop issue must rest in a state the doc allows: terminal (`done`/`cancelled`), explicitly live (active run / queued wake), explicitly waiting (`in_review` with participant/interaction/approval), or explicit recovery/blocker (`blocked` with `blockedByIssueIds` and a named owner).\n\n## When to use\n\nTrigger on an assignment whose title or body matches any of:\n\n- "run Terminal-Bench in a loop", "loop \\<task-name\\> through Paperclip"\n- "drive Terminal-Bench fix-git", "iterate on Terminal-Bench until it passes"\n- "Terminal-Bench smoke loop", "bench loop", "smoke loop on \\<task-name\\>"\n- An attached link to a Terminal-Bench loop parent issue, plus a request to do another iteration\n\nAlso use when the user hands you an existing top-level loop issue and asks for the next iteration, diagnosis, or rerun.\n\n## When NOT to use\n\n- The assignment is to build or change `paperclip-bench` itself (Harbor adapter, wrapper, telemetry). Use normal engineering flow on that repo.\n- The assignment is to submit a benchmark result for ranking. This skill produces smoke/non-comparable runs by design — escalate full-suite or comparable runs to BenchmarkQualityManager.\n- The assignment is a normal Paperclip product bug not surfaced by a Terminal-Bench loop. Use normal investigation.\n- You have not been granted permission to install or assign company skills, and the asker actually wants library mutation. Hand that step to an authorized skill-library owner.\n\n## Three invariants you must preserve\n\nEvery loop iteration and every proposed product fix must hold these three invariants together. They come from `/diagnose-why-work-stopped` and the user has restated them across the liveness work:\n\n1. **Productive work continues.** Each loop issue must always have a clear next action owner — agent, board, user, or named blocker. No silent `in_review` with nothing waiting on it.\n2. **Only real blockers stop work.** Stops happen when something genuinely cannot proceed (board confirmation, QA, missing credentials, exhausted budget). Pseudo-stops must be detected and routed.\n3. **No infinite loops.** Iteration count, wall-clock budget, and a board gate before product fixes are applied keep the loop bounded.\n\nIf a proposed iteration violates any of the three, drop it or rework it. State explicitly in the loop issue how each invariant is held this iteration.\n\n## Inputs\n\nCollect these on the top-level loop issue before iteration 1. Any input that cannot be supplied is a blocker — name the unblock owner and stop.\n\n- **Source issue.** The Paperclip issue that asked for the loop. The loop parent links back to it.\n- **Terminal-Bench task name.** Single-task identifier (e.g. `terminal-bench/fix-git`). Multi-task suites are out of scope for this skill.\n- **Iteration budget.** Maximum number of iterations before the loop must stop without further fixes (typical: 3–5). Also record a per-iteration wall-clock cap.\n- **Paperclip App worktree issue.** The implementation-side issue under the Paperclip App project whose execution workspace owns the isolated worktree. First iteration creates it; later iterations reuse it via `inheritExecutionWorkspaceFromIssueId` or equivalent.\n- **Benchmark command.** The exact `paperclip-bench` invocation, including the `PAPERCLIPAI_CMD` (or equivalent) binding pinned to the Paperclip App worktree under test. Record verbatim on the loop issue.\n- **Dispatch runner config.** The exact Harbor/Paperclip runner dispatch config required for the smoke to actually start a Paperclip heartbeat. For the current Harbor wrapper, record the `PAPERCLIP_HARBOR_RUNNER_CONFIG` JSON (or equivalent config file) verbatim enough to preserve: `assignee`, `heartbeat_strategy`, `agent_adapter` / `agent_adapters`, `reuse_host_home` when local credentials are intentionally needed, and the stop budget. A bare Harbor command that creates `BEN-1` as unassigned `todo` with zero heartbeat-enabled agents is a harness/setup failure, not a valid product diagnosis.\n- **Latest artifact root.** Filesystem or storage path under which `paperclip-bench` writes run artifacts (manifest, `results.jsonl`, Harbor raw job folders, redacted telemetry). Each iteration appends; nothing is overwritten.\n- **Approval policy.** Who must accept a proposed product fix before implementation (default: board via `request_confirmation`; CTO if delegated; never the loop driver alone).\n\nRecord each input on the top-level loop issue (description or a dedicated `inputs` document). If any input changes mid-loop, note the change and the iteration it took effect.\n\n## Issue topology\n\nThe loop must be representable as a tree, not as prose in comments:\n\n- **Top-level loop issue.** Long-lived. Holds inputs, iteration counter, current state, links to every iteration child, and the product-rule history. Rests in `in_progress` while an iteration is running, `in_review` only when a typed waiter sits directly on the loop parent (execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or named human owner), `blocked` with `blockedByIssueIds` while a child issue is the gating work (iteration child holding the fix-proposal `request_confirmation`, or implementation, QA, or CTO review children), `done` on pass, or `cancelled` on board-rejection / budget exhaustion.\n- **Iteration child issues.** One per iteration. Each carries: a bounded run issue (smoke), a diagnosis issue (applies `/diagnose-why-work-stopped`), a fix-proposal document with a `request_confirmation` interaction, and — only after acceptance — implementation, QA, CTO review, and rerun children. Iteration children are blocked by their predecessors so the executor wakes them in order.\n- **Paperclip App implementation issue.** The first iteration creates a fresh Paperclip App child whose project policy spawns an isolated worktree. Every later iteration's implementation/rerun child references that same execution workspace via `inheritExecutionWorkspaceFromIssueId` so the same worktree is amended and tested.\n\nWire dependencies with `blockedByIssueIds`, never with prose like "blocked by X". When a dependent child is `done`, the executor auto-wakes the next.\n\n## Procedure\n\n### 0. Read the current execution contract\n\nBefore opening or advancing a loop, read `doc/execution-semantics.md`. Use that document's terms intact when classifying loop-issue state: live path / waiting path / recovery path; post-run disposition; bounded continuation; productivity review; pause-hold; watchdog. Do not invent a new state.\n\n### 1. Open or reuse the top-level loop issue\n\n- If an existing loop issue is supplied, read it: inputs, iteration counter, last iteration's stop reason, current Paperclip App worktree pointer, latest benchmark command.\n- If no loop issue exists, create one under the Paperclip App project (or the project the source issue points at). Title: `Terminal-Bench loop: <task-name>`. Description captures the inputs above, the iteration budget, and a link to the source issue.\n- Verify the worktree pointer still resolves. If the recorded execution workspace was discarded (worktree pruned, project changed), the loop is blocked — name the unblock owner (CodexCoder or the Paperclip App owner) and stop.\n\n### 2. Open the iteration child\n\n- Increment the iteration counter on the loop issue.\n- Create an iteration child titled `Iteration N: <task-name>`. Its description repeats the inputs and references the loop parent. Block it on the prior iteration's terminal child (if any) so the executor cannot start two iterations in parallel.\n- If the iteration counter would exceed the budget, do not create the child. Move the loop issue to `cancelled` (budget exhausted) or `in_review` if the user must decide whether to extend the budget.\n\n### 3. Run the bounded smoke\n\n- The benchmark command must use the Paperclip App worktree under test. Set `PAPERCLIPAI_CMD` (or the equivalent command binding) to the CLI entrypoint inside that worktree. Never let the smoke run against the operator's current Paperclip checkout.\n- The same command block must include the runner dispatch config that makes the benchmark issue actionable. For the current Harbor wrapper, export `PAPERCLIP_HARBOR_RUNNER_CONFIG` with the intended assignee, heartbeat strategy, agent adapter, credential/home mode, and stop budget. Do not treat a bare `uvx harbor run ...` as the canonical smoke if it omits the dispatch config; record that as a harness/setup miss and rerun with the recorded config.\n- Bound the run by wall-clock and by Paperclip's run-budget controls. If the smoke would exceed the per-iteration cap, kill it and record the truncation reason.\n- Capture, in the iteration child or a dedicated `run` document:\n  - Paperclip run id and heartbeat run ids\n  - benchmark run id, manifest, `results.jsonl` row, Harbor raw job folder\n  - dispatch config used (`PAPERCLIP_HARBOR_RUNNER_CONFIG` or equivalent), including assignee and adapter type\n  - the exact stop reason reported by the harness (pass, harness fail, verifier fail, timeout, agent gave up, infrastructure error)\n  - heartbeat-enabled and heartbeat-observed agent counts when Paperclip telemetry exports them\n  - failure taxonomy bucket (task/model, Paperclip product, harness/setup, verifier/infrastructure, security, unclear)\n  - artifact paths under the latest artifact root\n- Label the iteration as **smoke / non-comparable**. Comparable runs are out of scope for this skill.\n\n### 4. Diagnose the exact stop point\n\nApply the `/diagnose-why-work-stopped` pattern to the iteration's run, scoped to this loop only — do not pull in unrelated forensic boilerplate. Specifically:\n\n- Walk the Paperclip issue tree the smoke produced under the Paperclip App worktree, node by node, and find the exact `(issue, status)` combination that stopped progress. Quote evidence: run ids, comment timestamps, status transitions.\n- Classify every non-progressing issue in that subtree as **truly needs human/board intervention**, **agent-actionable but not currently routed**, or **already covered**.\n- State whether the failure is task/model, Paperclip product, harness/setup, verifier/infrastructure, security, or unclear. Be explicit when evidence is inferred (e.g. cross-company API boundary blocks direct reads).\n- If the failure is a Paperclip product gap, frame the fix as a **general product rule** stated as a contract, and check it against the three invariants above. If the rule would have blocked a recent productive run, narrow it.\n\nRecord the diagnosis on the iteration child as a `diagnosis` document. Do not propose code yet.\n\n### 5. Decide the next move\n\nBased on the diagnosis, the iteration ends in exactly one of these terminal-for-iteration states:\n\n- **Pass.** Smoke verifier reports pass. Move the iteration child and the loop parent toward QA/CTO review (Step 8).\n- **Product fix proposed.** A Paperclip product gap was identified. Write the fix proposal as a `plan` document on the iteration child, then go to Step 6.\n- **Non-product failure with retry.** Failure is harness/setup/infrastructure or model flakiness, the iteration budget is not exhausted, and the loop driver believes a rerun without code changes has signal (e.g. transient infra). Record the rationale on the iteration child and go to Step 7 with no implementation step.\n- **Real blocker.** Named external blocker (credentials, quota, third-party outage, security review). Move the loop issue to `blocked`, set `blockedByIssueIds` to the blocker issue (creating one if needed), and name the unblock owner. Stop.\n- **Budget or board stop.** Iteration budget reached, or the board has rejected the next fix proposal. Move the loop issue to `cancelled` with a comment that summarizes the run history and the reason for stopping.\n\n### 6. Request board confirmation before any product fix\n\nWhen the iteration ends in **product fix proposed**:\n\n- Update the iteration child's `plan` document with the proposed contract, the three-invariant check, the affected Paperclip surfaces, and the phased subtasks (implementation, QA, CTO review, rerun) — but do not create those subtasks.\n- Open the `request_confirmation` interaction on the **iteration child** (the same issue that owns the `plan` document), targeting the latest plan revision. Idempotency key: `confirmation:{iterationIssueId}:plan:{revisionId}`. Set `continuationPolicy` to `wake_assignee`.\n- Move the **iteration child** to `in_review`. The typed waiter — the `request_confirmation` interaction — sits directly on it, so its `in_review` is healthy. Comment links the plan document and names the pending confirmation.\n- Move the **loop parent** to `blocked` with `blockedByIssueIds: [iterationChildId]` and a comment naming the board (or whichever approver the approval policy designates) as the unblock owner. Do not move the loop parent to `in_review` here: the typed waiter lives on the iteration child, not on the parent, so the parent's wait path is the child blocker. This matches the topology rule that the loop parent only sits in `in_review` when a typed waiter is attached directly to the parent.\n- Wait for acceptance. If the board posts a superseding comment that changes the plan, revise the document, then open a fresh confirmation tied to the new revision on the iteration child — the prior one is invalidated. The loop parent's `blockedByIssueIds` already points at the iteration child, so it does not need to change.\n- On rejection, end the loop per the **Budget or board stop** rule; do not silently retry the same proposal.\n- On acceptance, create the implementation, QA, CTO review, and rerun child issues with `blockedByIssueIds` wired in order, and update the loop parent's `blockedByIssueIds` to point at the new gating child (typically the implementation child) so the parent stays `blocked` against real downstream work. The implementation child must inherit the Paperclip App execution workspace (`inheritExecutionWorkspaceFromIssueId` to the worktree-owning issue) so the fix lands in the same isolated worktree the smoke ran against.\n\n### 7. Rerun against the same worktree\n\nAfter implementation and QA complete (or immediately, in the **non-product failure with retry** case), the rerun child runs the same `paperclip-bench` invocation with `PAPERCLIPAI_CMD` still pinned to the Paperclip App worktree under test.\n\n- The rerun must use the same worktree the fix landed in. If the workspace was reset between iterations, the loop is invalid — open a blocker on the loop issue and stop.\n- On completion, the rerun child becomes the next iteration's run record. If the smoke now passes, jump to Step 8. Otherwise return to Step 4 with a new iteration child (subject to the iteration budget).\n\n### 8. Pass: QA, CTO review, close\n\nWhen the smoke passes:\n\n- Create QA and CTO review children if they are not already in the dependency chain (CTO review blocked by QA, so the chain wakes in order). Move the loop parent to `blocked` with `blockedByIssueIds` set to the QA / CTO review chain, and post a comment that names QA and CTO as the unblock owners and links the children. The loop parent stays `blocked` — not `in_review` — because the typed waiter lives on the children, not on the parent.\n- If you instead want the loop parent itself to sit in `in_review` during this phase (for example because a board user has explicitly volunteered to drive the review), put a typed waiter directly on the parent — execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or named human owner — and do not rely on the child chain alone. Do not combine `in_review` on the parent with QA/CTO children acting as the blocker; that is the ambiguous review shape this skill exists to prevent.\n- QA validates artifacts (manifest, `results.jsonl`, Harbor raw job, redacted telemetry) and the rerun reproducibility against the same worktree.\n- CTO reviews the technical scope of any product fixes that landed during the loop.\n- On QA + CTO acceptance, close the loop issue with a board-level summary comment: task name, iteration count, stop reason (pass), worktree pointer, link to the final artifact root, and the list of accepted product fixes (each with its implementation issue id).\n\n### 9. Stop rules\n\nThe loop **must** stop, with state explicitly recorded on the loop issue, when any of these is true:\n\n- **Pass.** Smoke verifier reports pass and QA + CTO accept (Step 8). Loop issue → `done`.\n- **Board rejection.** Board rejects a fix proposal and does not request a revision. Loop issue → `cancelled`. Comment names the rejected proposal and the reason.\n- **Iteration budget reached.** Iteration counter reaches the budget without a pass. Loop issue → `cancelled` (or `in_review` if the user must decide whether to extend the budget). Never silently start iteration N+1.\n- **Real blocker named.** External blocker (credentials, quota, infra, security, missing skill) cannot be resolved by the loop driver. Loop issue → `blocked` with `blockedByIssueIds` to the blocker issue and the unblock owner named.\n\nA loop must never end on a prose comment alone. Every stop is a status transition with a named next-action owner.\n\n## Worktree rule\n\nThe loop must not test whatever Paperclip checkout happens to be current for the heartbeat. It must test the same isolated Paperclip App worktree where proposed fixes are applied.\n\n- The first iteration creates the Paperclip App implementation child; that project's git-worktree policy spawns a fresh worktree.\n- The loop issue records the worktree-owning issue id and the workspace path (or workspace id).\n- Every later implementation, QA, and rerun child sets `inheritExecutionWorkspaceFromIssueId` to that worktree-owning issue, so all subsequent loop work shares one workspace.\n- The benchmark command always sets `PAPERCLIPAI_CMD` (or the equivalent command binding) to the CLI entrypoint inside that worktree, and it carries the recorded dispatch runner config (`PAPERCLIP_HARBOR_RUNNER_CONFIG` or equivalent) needed to assign the benchmark issue and start the heartbeat. The benchmark command stored on the loop issue is the source of truth — if a heartbeat needs to run the smoke from a different shell, it copies the recorded command block verbatim, not only the Harbor invocation line.\n- If the workspace is pruned or the worktree path no longer resolves, the loop is invalid until rebuilt. Mark the loop `blocked` and name the unblock owner (typically CodexCoder or the Paperclip App owner).\n\n## Liveness rule\n\nEvery loop issue, at the end of every heartbeat, must rest in one of:\n\n- **Terminal:** `done` or `cancelled`. No further action.\n- **Explicitly live:** `in_progress` with an active run, an upcoming queued wake, or a child issue actively executing under it.\n- **Explicitly waiting:** `in_review` with a typed waiter — execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or a named human owner.\n- **Explicit recovery / blocker:** `blocked` with `blockedByIssueIds` set to a real blocking issue, plus a comment naming the unblock owner and the action needed.\n\nIf a loop issue does not fit one of these on exit, the heartbeat is not done. Fix the state before exiting.\n\n## Pitfalls\n\n- **Running the smoke against the operator's Paperclip checkout.** The whole point of the worktree rule is that the bench tests the worktree the fix lands in. Always set `PAPERCLIPAI_CMD` and verify the path before launching the run.\n- **Dropping the dispatch config.** A Harbor run that omits `PAPERCLIP_HARBOR_RUNNER_CONFIG` (or equivalent) may boot Paperclip and create `BEN-1`, but leave it unassigned with zero heartbeat-enabled agents. That is not a Terminal-Bench product signal. Preserve and rerun the full command block, including assignee and adapter config.\n- **Coding before approval.** No implementation child exists until a board confirmation accepts the iteration's `plan` document. Do not push code in the diagnostic phase.\n- **Skipping the recent-work survey.** When proposing a Paperclip product rule, check what already shipped in the affected liveness/execution area in the last few days. A rule that contradicts last-week's accepted contract is rework.\n- **Letting `in_review` mean done.** A loop or iteration child sitting in `in_review` with no participant, no interaction, no approval, and no human owner is a stop, not progress. Treat it as a liveness violation and route it.\n- **Silent iteration N+1.** If the iteration budget is reached, never start another iteration without an explicit budget extension recorded on the loop issue.\n- **Comparable-run drift.** This skill produces smoke runs only. If the asker wants a comparable benchmark submission, hand off to BenchmarkQualityManager and BenchmarkForensics — do not relabel a smoke as comparable.\n- **Recursive recovery.** Stranded-work recovery that recovers its own recovery issues is the canonical infinite loop. If a diagnosis surfaces it inside the smoke's subtree, refuse to deepen and route to `/diagnose-why-work-stopped` for a product-rule fix.\n- **Skill-library mutation.** This skill never installs, edits, or assigns company skills as part of a loop iteration. Library changes go to an authorized skill-library owner via a separate issue.\n- **Hiding the chain.** Do not silently delete or hide failed iteration children, retracted proposals, or rejected confirmations. The audit trail is the loop's evidence.\n\n## Verification checklist (before exiting a heartbeat that touched the loop)\n\n- [ ] All inputs are recorded on the top-level loop issue, including the exact benchmark command, `PAPERCLIPAI_CMD` binding, and dispatch runner config.\n- [ ] Iteration counter is up to date and within budget.\n- [ ] The Paperclip App worktree pointer still resolves, and the iteration's run/implementation/rerun children share that workspace.\n- [ ] The smoke run is captured with run ids, manifest, `results.jsonl`, Harbor raw job folder, and stop reason.\n- [ ] Paperclip telemetry shows the benchmark issue was assigned and a heartbeat was enabled/observed, or the iteration is explicitly classified as harness/setup no-dispatch.\n- [ ] Diagnosis applies the `/diagnose-why-work-stopped` pattern, classifies every non-progressing issue, and checks the three invariants.\n- [ ] No implementation child exists for an unapproved fix proposal; if one was proposed, a `request_confirmation` is open against the latest plan revision.\n- [ ] Every loop and iteration issue rests in a terminal, explicitly-live, explicitly-waiting, or named-blocker state.\n- [ ] The stop reason — if the loop stopped this heartbeat — is one of pass, board rejection, budget exhausted, or named real blocker.\n- [ ] No company-skill library mutation happened in this heartbeat.\n\n## Deterministic smoke\n\nRun this smoke after installing or changing the skill, before treating it as operational for a live Terminal-Bench loop:\n\n```sh\npnpm smoke:terminal-bench-loop-skill\n```\n\nThe command uses the current Paperclip API token and company from `PAPERCLIP_API_URL`, `PAPERCLIP_API_KEY`, and `PAPERCLIP_COMPANY_ID`. When `PAPERCLIP_TASK_ID` is set, it attaches the smoke issues under that source issue and inherits its project/goal context. By default it cancels the short-lived smoke issues after verification; pass `-- --keep` to leave the verified `blocked` loop parent, `in_review` iteration child, and pending confirmation available for manual inspection.\n\nThe smoke is deterministic and intentionally non-comparable. It does not start Terminal-Bench, Harbor, an agent model, or a provider runtime. It verifies only the control-plane shape:\n\n- local `skills/terminal-bench-loop/SKILL.md` contains the loop contract terms;\n- a top-level loop issue can be created and updated into a blocker posture;\n- an iteration child issue can be created under the loop parent;\n- mocked benchmark artifact paths are recorded on a `run` document;\n- a `diagnosis` document names the exact stop point and next-action owner;\n- a `request_confirmation` interaction is created and the iteration child rests in `in_review` with a typed waiting path rather than silent review.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/terminal-bench-loop	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/terminal-bench-loop", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:50.552157+00	2026-05-22 22:33:56.737+00
830ee5bb-8d04-454d-b059-c4bb62fb23aa	a163ef00-71bb-4412-8943-c109f58a60a7	paperclipai/paperclip/terminal-bench-loop	terminal-bench-loop	terminal-bench-loop	>	---\nname: terminal-bench-loop\ndescription: >\n  Run a single Terminal-Bench problem through Paperclip in a bounded,\n  human-in-the-loop improvement cycle until the smoke passes, the board\n  rejects the next fix, the iteration budget is exhausted, or a real\n  blocker is named. Each iteration runs a bounded smoke against an\n  isolated Paperclip App worktree, captures artifacts, diagnoses the\n  exact stop point with `/diagnose-why-work-stopped`, requests board\n  confirmation before any product fix, then reruns against the same\n  worktree. Use whenever an issue asks to "run Terminal-Bench in a\n  loop", "drive Terminal-Bench until it passes", "loop fix-git through\n  Paperclip", or otherwise points at a Terminal-Bench task and asks for\n  bounded iteration with diagnosis.\n---\n\n# Terminal-Bench Loop\n\nA repeatable operating skill for driving one Terminal-Bench problem to a passing smoke through Paperclip, with explicit issue topology, bounded runs, board-gated product fixes, and worktree continuity.\n\nThis skill is **operational + diagnostic**, not engineering. It coordinates issues, artifacts, and approvals around a Terminal-Bench loop. It does not authorize code changes — every accepted product fix lands as a separate implementation child issue after a board confirmation.\n\nCanonical execution model: read `doc/execution-semantics.md` before starting a loop or moving any loop issue. Every loop issue must rest in a state the doc allows: terminal (`done`/`cancelled`), explicitly live (active run / queued wake), explicitly waiting (`in_review` with participant/interaction/approval), or explicit recovery/blocker (`blocked` with `blockedByIssueIds` and a named owner).\n\n## When to use\n\nTrigger on an assignment whose title or body matches any of:\n\n- "run Terminal-Bench in a loop", "loop \\<task-name\\> through Paperclip"\n- "drive Terminal-Bench fix-git", "iterate on Terminal-Bench until it passes"\n- "Terminal-Bench smoke loop", "bench loop", "smoke loop on \\<task-name\\>"\n- An attached link to a Terminal-Bench loop parent issue, plus a request to do another iteration\n\nAlso use when the user hands you an existing top-level loop issue and asks for the next iteration, diagnosis, or rerun.\n\n## When NOT to use\n\n- The assignment is to build or change `paperclip-bench` itself (Harbor adapter, wrapper, telemetry). Use normal engineering flow on that repo.\n- The assignment is to submit a benchmark result for ranking. This skill produces smoke/non-comparable runs by design — escalate full-suite or comparable runs to BenchmarkQualityManager.\n- The assignment is a normal Paperclip product bug not surfaced by a Terminal-Bench loop. Use normal investigation.\n- You have not been granted permission to install or assign company skills, and the asker actually wants library mutation. Hand that step to an authorized skill-library owner.\n\n## Three invariants you must preserve\n\nEvery loop iteration and every proposed product fix must hold these three invariants together. They come from `/diagnose-why-work-stopped` and the user has restated them across the liveness work:\n\n1. **Productive work continues.** Each loop issue must always have a clear next action owner — agent, board, user, or named blocker. No silent `in_review` with nothing waiting on it.\n2. **Only real blockers stop work.** Stops happen when something genuinely cannot proceed (board confirmation, QA, missing credentials, exhausted budget). Pseudo-stops must be detected and routed.\n3. **No infinite loops.** Iteration count, wall-clock budget, and a board gate before product fixes are applied keep the loop bounded.\n\nIf a proposed iteration violates any of the three, drop it or rework it. State explicitly in the loop issue how each invariant is held this iteration.\n\n## Inputs\n\nCollect these on the top-level loop issue before iteration 1. Any input that cannot be supplied is a blocker — name the unblock owner and stop.\n\n- **Source issue.** The Paperclip issue that asked for the loop. The loop parent links back to it.\n- **Terminal-Bench task name.** Single-task identifier (e.g. `terminal-bench/fix-git`). Multi-task suites are out of scope for this skill.\n- **Iteration budget.** Maximum number of iterations before the loop must stop without further fixes (typical: 3–5). Also record a per-iteration wall-clock cap.\n- **Paperclip App worktree issue.** The implementation-side issue under the Paperclip App project whose execution workspace owns the isolated worktree. First iteration creates it; later iterations reuse it via `inheritExecutionWorkspaceFromIssueId` or equivalent.\n- **Benchmark command.** The exact `paperclip-bench` invocation, including the `PAPERCLIPAI_CMD` (or equivalent) binding pinned to the Paperclip App worktree under test. Record verbatim on the loop issue.\n- **Dispatch runner config.** The exact Harbor/Paperclip runner dispatch config required for the smoke to actually start a Paperclip heartbeat. For the current Harbor wrapper, record the `PAPERCLIP_HARBOR_RUNNER_CONFIG` JSON (or equivalent config file) verbatim enough to preserve: `assignee`, `heartbeat_strategy`, `agent_adapter` / `agent_adapters`, `reuse_host_home` when local credentials are intentionally needed, and the stop budget. A bare Harbor command that creates `BEN-1` as unassigned `todo` with zero heartbeat-enabled agents is a harness/setup failure, not a valid product diagnosis.\n- **Latest artifact root.** Filesystem or storage path under which `paperclip-bench` writes run artifacts (manifest, `results.jsonl`, Harbor raw job folders, redacted telemetry). Each iteration appends; nothing is overwritten.\n- **Approval policy.** Who must accept a proposed product fix before implementation (default: board via `request_confirmation`; CTO if delegated; never the loop driver alone).\n\nRecord each input on the top-level loop issue (description or a dedicated `inputs` document). If any input changes mid-loop, note the change and the iteration it took effect.\n\n## Issue topology\n\nThe loop must be representable as a tree, not as prose in comments:\n\n- **Top-level loop issue.** Long-lived. Holds inputs, iteration counter, current state, links to every iteration child, and the product-rule history. Rests in `in_progress` while an iteration is running, `in_review` only when a typed waiter sits directly on the loop parent (execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or named human owner), `blocked` with `blockedByIssueIds` while a child issue is the gating work (iteration child holding the fix-proposal `request_confirmation`, or implementation, QA, or CTO review children), `done` on pass, or `cancelled` on board-rejection / budget exhaustion.\n- **Iteration child issues.** One per iteration. Each carries: a bounded run issue (smoke), a diagnosis issue (applies `/diagnose-why-work-stopped`), a fix-proposal document with a `request_confirmation` interaction, and — only after acceptance — implementation, QA, CTO review, and rerun children. Iteration children are blocked by their predecessors so the executor wakes them in order.\n- **Paperclip App implementation issue.** The first iteration creates a fresh Paperclip App child whose project policy spawns an isolated worktree. Every later iteration's implementation/rerun child references that same execution workspace via `inheritExecutionWorkspaceFromIssueId` so the same worktree is amended and tested.\n\nWire dependencies with `blockedByIssueIds`, never with prose like "blocked by X". When a dependent child is `done`, the executor auto-wakes the next.\n\n## Procedure\n\n### 0. Read the current execution contract\n\nBefore opening or advancing a loop, read `doc/execution-semantics.md`. Use that document's terms intact when classifying loop-issue state: live path / waiting path / recovery path; post-run disposition; bounded continuation; productivity review; pause-hold; watchdog. Do not invent a new state.\n\n### 1. Open or reuse the top-level loop issue\n\n- If an existing loop issue is supplied, read it: inputs, iteration counter, last iteration's stop reason, current Paperclip App worktree pointer, latest benchmark command.\n- If no loop issue exists, create one under the Paperclip App project (or the project the source issue points at). Title: `Terminal-Bench loop: <task-name>`. Description captures the inputs above, the iteration budget, and a link to the source issue.\n- Verify the worktree pointer still resolves. If the recorded execution workspace was discarded (worktree pruned, project changed), the loop is blocked — name the unblock owner (CodexCoder or the Paperclip App owner) and stop.\n\n### 2. Open the iteration child\n\n- Increment the iteration counter on the loop issue.\n- Create an iteration child titled `Iteration N: <task-name>`. Its description repeats the inputs and references the loop parent. Block it on the prior iteration's terminal child (if any) so the executor cannot start two iterations in parallel.\n- If the iteration counter would exceed the budget, do not create the child. Move the loop issue to `cancelled` (budget exhausted) or `in_review` if the user must decide whether to extend the budget.\n\n### 3. Run the bounded smoke\n\n- The benchmark command must use the Paperclip App worktree under test. Set `PAPERCLIPAI_CMD` (or the equivalent command binding) to the CLI entrypoint inside that worktree. Never let the smoke run against the operator's current Paperclip checkout.\n- The same command block must include the runner dispatch config that makes the benchmark issue actionable. For the current Harbor wrapper, export `PAPERCLIP_HARBOR_RUNNER_CONFIG` with the intended assignee, heartbeat strategy, agent adapter, credential/home mode, and stop budget. Do not treat a bare `uvx harbor run ...` as the canonical smoke if it omits the dispatch config; record that as a harness/setup miss and rerun with the recorded config.\n- Bound the run by wall-clock and by Paperclip's run-budget controls. If the smoke would exceed the per-iteration cap, kill it and record the truncation reason.\n- Capture, in the iteration child or a dedicated `run` document:\n  - Paperclip run id and heartbeat run ids\n  - benchmark run id, manifest, `results.jsonl` row, Harbor raw job folder\n  - dispatch config used (`PAPERCLIP_HARBOR_RUNNER_CONFIG` or equivalent), including assignee and adapter type\n  - the exact stop reason reported by the harness (pass, harness fail, verifier fail, timeout, agent gave up, infrastructure error)\n  - heartbeat-enabled and heartbeat-observed agent counts when Paperclip telemetry exports them\n  - failure taxonomy bucket (task/model, Paperclip product, harness/setup, verifier/infrastructure, security, unclear)\n  - artifact paths under the latest artifact root\n- Label the iteration as **smoke / non-comparable**. Comparable runs are out of scope for this skill.\n\n### 4. Diagnose the exact stop point\n\nApply the `/diagnose-why-work-stopped` pattern to the iteration's run, scoped to this loop only — do not pull in unrelated forensic boilerplate. Specifically:\n\n- Walk the Paperclip issue tree the smoke produced under the Paperclip App worktree, node by node, and find the exact `(issue, status)` combination that stopped progress. Quote evidence: run ids, comment timestamps, status transitions.\n- Classify every non-progressing issue in that subtree as **truly needs human/board intervention**, **agent-actionable but not currently routed**, or **already covered**.\n- State whether the failure is task/model, Paperclip product, harness/setup, verifier/infrastructure, security, or unclear. Be explicit when evidence is inferred (e.g. cross-company API boundary blocks direct reads).\n- If the failure is a Paperclip product gap, frame the fix as a **general product rule** stated as a contract, and check it against the three invariants above. If the rule would have blocked a recent productive run, narrow it.\n\nRecord the diagnosis on the iteration child as a `diagnosis` document. Do not propose code yet.\n\n### 5. Decide the next move\n\nBased on the diagnosis, the iteration ends in exactly one of these terminal-for-iteration states:\n\n- **Pass.** Smoke verifier reports pass. Move the iteration child and the loop parent toward QA/CTO review (Step 8).\n- **Product fix proposed.** A Paperclip product gap was identified. Write the fix proposal as a `plan` document on the iteration child, then go to Step 6.\n- **Non-product failure with retry.** Failure is harness/setup/infrastructure or model flakiness, the iteration budget is not exhausted, and the loop driver believes a rerun without code changes has signal (e.g. transient infra). Record the rationale on the iteration child and go to Step 7 with no implementation step.\n- **Real blocker.** Named external blocker (credentials, quota, third-party outage, security review). Move the loop issue to `blocked`, set `blockedByIssueIds` to the blocker issue (creating one if needed), and name the unblock owner. Stop.\n- **Budget or board stop.** Iteration budget reached, or the board has rejected the next fix proposal. Move the loop issue to `cancelled` with a comment that summarizes the run history and the reason for stopping.\n\n### 6. Request board confirmation before any product fix\n\nWhen the iteration ends in **product fix proposed**:\n\n- Update the iteration child's `plan` document with the proposed contract, the three-invariant check, the affected Paperclip surfaces, and the phased subtasks (implementation, QA, CTO review, rerun) — but do not create those subtasks.\n- Open the `request_confirmation` interaction on the **iteration child** (the same issue that owns the `plan` document), targeting the latest plan revision. Idempotency key: `confirmation:{iterationIssueId}:plan:{revisionId}`. Set `continuationPolicy` to `wake_assignee`.\n- Move the **iteration child** to `in_review`. The typed waiter — the `request_confirmation` interaction — sits directly on it, so its `in_review` is healthy. Comment links the plan document and names the pending confirmation.\n- Move the **loop parent** to `blocked` with `blockedByIssueIds: [iterationChildId]` and a comment naming the board (or whichever approver the approval policy designates) as the unblock owner. Do not move the loop parent to `in_review` here: the typed waiter lives on the iteration child, not on the parent, so the parent's wait path is the child blocker. This matches the topology rule that the loop parent only sits in `in_review` when a typed waiter is attached directly to the parent.\n- Wait for acceptance. If the board posts a superseding comment that changes the plan, revise the document, then open a fresh confirmation tied to the new revision on the iteration child — the prior one is invalidated. The loop parent's `blockedByIssueIds` already points at the iteration child, so it does not need to change.\n- On rejection, end the loop per the **Budget or board stop** rule; do not silently retry the same proposal.\n- On acceptance, create the implementation, QA, CTO review, and rerun child issues with `blockedByIssueIds` wired in order, and update the loop parent's `blockedByIssueIds` to point at the new gating child (typically the implementation child) so the parent stays `blocked` against real downstream work. The implementation child must inherit the Paperclip App execution workspace (`inheritExecutionWorkspaceFromIssueId` to the worktree-owning issue) so the fix lands in the same isolated worktree the smoke ran against.\n\n### 7. Rerun against the same worktree\n\nAfter implementation and QA complete (or immediately, in the **non-product failure with retry** case), the rerun child runs the same `paperclip-bench` invocation with `PAPERCLIPAI_CMD` still pinned to the Paperclip App worktree under test.\n\n- The rerun must use the same worktree the fix landed in. If the workspace was reset between iterations, the loop is invalid — open a blocker on the loop issue and stop.\n- On completion, the rerun child becomes the next iteration's run record. If the smoke now passes, jump to Step 8. Otherwise return to Step 4 with a new iteration child (subject to the iteration budget).\n\n### 8. Pass: QA, CTO review, close\n\nWhen the smoke passes:\n\n- Create QA and CTO review children if they are not already in the dependency chain (CTO review blocked by QA, so the chain wakes in order). Move the loop parent to `blocked` with `blockedByIssueIds` set to the QA / CTO review chain, and post a comment that names QA and CTO as the unblock owners and links the children. The loop parent stays `blocked` — not `in_review` — because the typed waiter lives on the children, not on the parent.\n- If you instead want the loop parent itself to sit in `in_review` during this phase (for example because a board user has explicitly volunteered to drive the review), put a typed waiter directly on the parent — execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or named human owner — and do not rely on the child chain alone. Do not combine `in_review` on the parent with QA/CTO children acting as the blocker; that is the ambiguous review shape this skill exists to prevent.\n- QA validates artifacts (manifest, `results.jsonl`, Harbor raw job, redacted telemetry) and the rerun reproducibility against the same worktree.\n- CTO reviews the technical scope of any product fixes that landed during the loop.\n- On QA + CTO acceptance, close the loop issue with a board-level summary comment: task name, iteration count, stop reason (pass), worktree pointer, link to the final artifact root, and the list of accepted product fixes (each with its implementation issue id).\n\n### 9. Stop rules\n\nThe loop **must** stop, with state explicitly recorded on the loop issue, when any of these is true:\n\n- **Pass.** Smoke verifier reports pass and QA + CTO accept (Step 8). Loop issue → `done`.\n- **Board rejection.** Board rejects a fix proposal and does not request a revision. Loop issue → `cancelled`. Comment names the rejected proposal and the reason.\n- **Iteration budget reached.** Iteration counter reaches the budget without a pass. Loop issue → `cancelled` (or `in_review` if the user must decide whether to extend the budget). Never silently start iteration N+1.\n- **Real blocker named.** External blocker (credentials, quota, infra, security, missing skill) cannot be resolved by the loop driver. Loop issue → `blocked` with `blockedByIssueIds` to the blocker issue and the unblock owner named.\n\nA loop must never end on a prose comment alone. Every stop is a status transition with a named next-action owner.\n\n## Worktree rule\n\nThe loop must not test whatever Paperclip checkout happens to be current for the heartbeat. It must test the same isolated Paperclip App worktree where proposed fixes are applied.\n\n- The first iteration creates the Paperclip App implementation child; that project's git-worktree policy spawns a fresh worktree.\n- The loop issue records the worktree-owning issue id and the workspace path (or workspace id).\n- Every later implementation, QA, and rerun child sets `inheritExecutionWorkspaceFromIssueId` to that worktree-owning issue, so all subsequent loop work shares one workspace.\n- The benchmark command always sets `PAPERCLIPAI_CMD` (or the equivalent command binding) to the CLI entrypoint inside that worktree, and it carries the recorded dispatch runner config (`PAPERCLIP_HARBOR_RUNNER_CONFIG` or equivalent) needed to assign the benchmark issue and start the heartbeat. The benchmark command stored on the loop issue is the source of truth — if a heartbeat needs to run the smoke from a different shell, it copies the recorded command block verbatim, not only the Harbor invocation line.\n- If the workspace is pruned or the worktree path no longer resolves, the loop is invalid until rebuilt. Mark the loop `blocked` and name the unblock owner (typically CodexCoder or the Paperclip App owner).\n\n## Liveness rule\n\nEvery loop issue, at the end of every heartbeat, must rest in one of:\n\n- **Terminal:** `done` or `cancelled`. No further action.\n- **Explicitly live:** `in_progress` with an active run, an upcoming queued wake, or a child issue actively executing under it.\n- **Explicitly waiting:** `in_review` with a typed waiter — execution-policy participant, `request_confirmation` / `ask_user_questions` / `suggest_tasks` interaction, approval, or a named human owner.\n- **Explicit recovery / blocker:** `blocked` with `blockedByIssueIds` set to a real blocking issue, plus a comment naming the unblock owner and the action needed.\n\nIf a loop issue does not fit one of these on exit, the heartbeat is not done. Fix the state before exiting.\n\n## Pitfalls\n\n- **Running the smoke against the operator's Paperclip checkout.** The whole point of the worktree rule is that the bench tests the worktree the fix lands in. Always set `PAPERCLIPAI_CMD` and verify the path before launching the run.\n- **Dropping the dispatch config.** A Harbor run that omits `PAPERCLIP_HARBOR_RUNNER_CONFIG` (or equivalent) may boot Paperclip and create `BEN-1`, but leave it unassigned with zero heartbeat-enabled agents. That is not a Terminal-Bench product signal. Preserve and rerun the full command block, including assignee and adapter config.\n- **Coding before approval.** No implementation child exists until a board confirmation accepts the iteration's `plan` document. Do not push code in the diagnostic phase.\n- **Skipping the recent-work survey.** When proposing a Paperclip product rule, check what already shipped in the affected liveness/execution area in the last few days. A rule that contradicts last-week's accepted contract is rework.\n- **Letting `in_review` mean done.** A loop or iteration child sitting in `in_review` with no participant, no interaction, no approval, and no human owner is a stop, not progress. Treat it as a liveness violation and route it.\n- **Silent iteration N+1.** If the iteration budget is reached, never start another iteration without an explicit budget extension recorded on the loop issue.\n- **Comparable-run drift.** This skill produces smoke runs only. If the asker wants a comparable benchmark submission, hand off to BenchmarkQualityManager and BenchmarkForensics — do not relabel a smoke as comparable.\n- **Recursive recovery.** Stranded-work recovery that recovers its own recovery issues is the canonical infinite loop. If a diagnosis surfaces it inside the smoke's subtree, refuse to deepen and route to `/diagnose-why-work-stopped` for a product-rule fix.\n- **Skill-library mutation.** This skill never installs, edits, or assigns company skills as part of a loop iteration. Library changes go to an authorized skill-library owner via a separate issue.\n- **Hiding the chain.** Do not silently delete or hide failed iteration children, retracted proposals, or rejected confirmations. The audit trail is the loop's evidence.\n\n## Verification checklist (before exiting a heartbeat that touched the loop)\n\n- [ ] All inputs are recorded on the top-level loop issue, including the exact benchmark command, `PAPERCLIPAI_CMD` binding, and dispatch runner config.\n- [ ] Iteration counter is up to date and within budget.\n- [ ] The Paperclip App worktree pointer still resolves, and the iteration's run/implementation/rerun children share that workspace.\n- [ ] The smoke run is captured with run ids, manifest, `results.jsonl`, Harbor raw job folder, and stop reason.\n- [ ] Paperclip telemetry shows the benchmark issue was assigned and a heartbeat was enabled/observed, or the iteration is explicitly classified as harness/setup no-dispatch.\n- [ ] Diagnosis applies the `/diagnose-why-work-stopped` pattern, classifies every non-progressing issue, and checks the three invariants.\n- [ ] No implementation child exists for an unapproved fix proposal; if one was proposed, a `request_confirmation` is open against the latest plan revision.\n- [ ] Every loop and iteration issue rests in a terminal, explicitly-live, explicitly-waiting, or named-blocker state.\n- [ ] The stop reason — if the loop stopped this heartbeat — is one of pass, board rejection, budget exhausted, or named real blocker.\n- [ ] No company-skill library mutation happened in this heartbeat.\n\n## Deterministic smoke\n\nRun this smoke after installing or changing the skill, before treating it as operational for a live Terminal-Bench loop:\n\n```sh\npnpm smoke:terminal-bench-loop-skill\n```\n\nThe command uses the current Paperclip API token and company from `PAPERCLIP_API_URL`, `PAPERCLIP_API_KEY`, and `PAPERCLIP_COMPANY_ID`. When `PAPERCLIP_TASK_ID` is set, it attaches the smoke issues under that source issue and inherits its project/goal context. By default it cancels the short-lived smoke issues after verification; pass `-- --keep` to leave the verified `blocked` loop parent, `in_review` iteration child, and pending confirmation available for manual inspection.\n\nThe smoke is deterministic and intentionally non-comparable. It does not start Terminal-Bench, Harbor, an agent model, or a provider runtime. It verifies only the control-plane shape:\n\n- local `skills/terminal-bench-loop/SKILL.md` contains the loop contract terms;\n- a top-level loop issue can be created and updated into a blocker posture;\n- an iteration child issue can be created under the loop parent;\n- mocked benchmark artifact paths are recorded on a `run` document;\n- a `diagnosis` document names the exact stop point and next-action owner;\n- a `request_confirmation` interaction is created and the iteration child rests in `in_review` with a typed waiting path rather than silent review.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/terminal-bench-loop	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/terminal-bench-loop", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:51.27405+00	2026-05-22 22:38:31.852+00
b8aae75d-a3e6-489f-81ec-2432e9029e5e	a24e39b2-2ede-4aec-9471-248458a381fc	paperclipai/paperclip/paperclip-create-agent	paperclip-create-agent	paperclip-create-agent	>	---\nname: paperclip-create-agent\ndescription: >\n  Create new agents in Paperclip with governance-aware hiring. Use when you need\n  to inspect adapter configuration options, compare existing agent configs,\n  draft a new agent prompt/config, and submit a hire request.\n---\n\n# Paperclip Create Agent Skill\n\nUse this skill when you are asked to hire/create an agent.\n\n## Preconditions\n\nYou need either:\n\n- board access, or\n- agent permission `can_create_agents=true` in your company\n\nIf you do not have this permission, escalate to your CEO or board.\n\n## Workflow\n\n### 1. Confirm identity and company context\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/agents/me" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 2. Discover adapter configuration for this Paperclip instance\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-configuration.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\n# Then the specific adapter you plan to use, e.g. claude_local:\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-configuration/claude_local.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 3. Compare existing agent configurations\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/companies/$PAPERCLIP_COMPANY_ID/agent-configurations" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\nNote naming, icon, reporting-line, and adapter conventions the company already follows.\n\n### 4. Choose the instruction source (required)\n\nThis is the single most important decision for hire quality. Pick exactly one path:\n\n- **Exact template** — the role matches an entry in the template index. Use the matching file under `references/agents/` as the starting point.\n- **Adjacent template** — no exact match, but an existing template is close (for example, a "Backend Engineer" hire adapted from `coder.md`, or a "Content Designer" adapted from `uxdesigner.md`). Copy the closest template and adapt deliberately: rename the role, rewrite the role charter, swap domain lenses, and remove sections that do not fit.\n- **Generic fallback** — no template is close. Use the baseline role guide to construct a new `AGENTS.md` from scratch, filling in each recommended section for the specific role.\n\nTemplate index and when-to-use guidance:\n`skills/paperclip-create-agent/references/agent-instruction-templates.md`\n\nGeneric fallback for no-template hires:\n`skills/paperclip-create-agent/references/baseline-role-guide.md`\n\nState which path you took in your hire-request comment so the board can see the reasoning.\n\n### 5. Discover allowed agent icons\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-icons.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 6. Draft the new hire config\n\n- role / title / name\n- icon (required in practice; pick from `/llms/agent-icons.txt`)\n- reporting line (`reportsTo`)\n- adapter type\n- `desiredSkills` from the company skill library when this role needs installed skills on day one\n- if any `desiredSkills` or adapter settings expand browser access, external-system reach, filesystem scope, or secret-handling capability, justify each one in the hire comment\n- adapter and runtime config aligned to this environment\n- leave timer heartbeats off by default; only set `runtimeConfig.heartbeat.enabled=true` with an `intervalSec` when the role genuinely needs scheduled recurring work or the user explicitly asked for it\n- if the role may handle private advisories or sensitive disclosures, confirm a confidential workflow exists first (dedicated skill or documented manual process)\n- capabilities\n- managed instructions bundle (`AGENTS.md`) for adapters that support it; avoid durable `promptTemplate` config\n- for coding or execution agents, include the Paperclip execution contract: start actionable work in the same heartbeat; do not stop at a plan unless planning was requested; leave durable progress with a clear next action; use child issues for long or parallel delegated work instead of polling; mark blocked work with owner/action; respect budget, pause/cancel, approval gates, and company boundaries\n- instruction text such as `AGENTS.md` built from step 4; for local managed-bundle adapters, send this as top-level `instructionsBundle.files["AGENTS.md"]`. Do not set `adapterConfig.promptTemplate` or `bootstrapPromptTemplate` for new agents.\n- source issue linkage (`sourceIssueId` or `sourceIssueIds`) when this hire came from an issue\n\n### 7. Review the draft against the quality checklist\n\nBefore submitting, walk the draft-review checklist end-to-end and fix any item that does not pass:\n`skills/paperclip-create-agent/references/draft-review-checklist.md`\n\n### 8. Submit hire request\n\n```sh\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/companies/$PAPERCLIP_COMPANY_ID/agent-hires" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "name": "CTO",\n    "role": "cto",\n    "title": "Chief Technology Officer",\n    "icon": "crown",\n    "reportsTo": "<ceo-agent-id>",\n    "capabilities": "Owns technical roadmap, architecture, staffing, execution",\n    "desiredSkills": ["vercel-labs/agent-browser/agent-browser"],\n    "adapterType": "codex_local",\n    "adapterConfig": {"cwd": "/abs/path/to/repo", "model": "o4-mini"},\n    "instructionsBundle": {"files": {"AGENTS.md": "You are the CTO..."}},\n    "runtimeConfig": {"heartbeat": {"enabled": false, "wakeOnDemand": true}},\n    "sourceIssueId": "<issue-id>"\n  }'\n```\n\n### 9. Handle governance state\n\n- if the response has `approval`, the hire is `pending_approval`\n- monitor and discuss on the approval thread\n- when the board approves, you will be woken with `PAPERCLIP_APPROVAL_ID`; read linked issues and close/comment follow-up\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/<approval-id>" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/approvals/<approval-id>/comments" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"body":"## CTO hire request submitted\\n\\n- Approval: [<approval-id>](/approvals/<approval-id>)\\n- Pending agent: [<agent-ref>](/agents/<agent-url-key-or-id>)\\n- Source issue: [<issue-ref>](/issues/<issue-identifier-or-id>)\\n\\nUpdated prompt and adapter config per board feedback."}'\n```\n\nIf the approval already exists and needs manual linking to the issue:\n\n```sh\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/issues/<issue-id>/approvals" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"approvalId":"<approval-id>"}'\n```\n\nAfter approval is granted, run this follow-up loop:\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/$PAPERCLIP_APPROVAL_ID" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/$PAPERCLIP_APPROVAL_ID/issues" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\nFor each linked issue, either:\n- close it if the approval resolved the request, or\n- comment in markdown with links to the approval and next actions.\n\n## References\n\n- Template index and how to apply a template: `skills/paperclip-create-agent/references/agent-instruction-templates.md`\n- Individual role templates: `skills/paperclip-create-agent/references/agents/`\n- Generic baseline role guide (no-template fallback): `skills/paperclip-create-agent/references/baseline-role-guide.md`\n- Pre-submit draft-review checklist: `skills/paperclip-create-agent/references/draft-review-checklist.md`\n- Endpoint payload shapes and full examples: `skills/paperclip-create-agent/references/api-reference.md`\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-create-agent	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/agent-instruction-templates.md"}, {"kind": "reference", "path": "references/agents/coder.md"}, {"kind": "reference", "path": "references/agents/qa.md"}, {"kind": "reference", "path": "references/agents/securityengineer.md"}, {"kind": "reference", "path": "references/agents/uxdesigner.md"}, {"kind": "reference", "path": "references/api-reference.md"}, {"kind": "reference", "path": "references/baseline-role-guide.md"}, {"kind": "reference", "path": "references/draft-review-checklist.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-create-agent", "sourceKind": "paperclip_bundled"}	2026-05-22 13:59:29.307016+00	2026-05-25 01:43:29.973+00
fea7193a-d0bf-4000-8d15-7a1c3b35a733	a163ef00-71bb-4412-8943-c109f58a60a7	paperclipai/paperclip/diagnose-why-work-stopped	diagnose-why-work-stopped	diagnose-why-work-stopped	>	---\nname: diagnose-why-work-stopped\ndescription: >\n  How to handle "why did this work stop / why is this looping?" assignments.\n  Forensics first on the named tree, surface the exact stop-point, frame the\n  fix as a general product rule that respects three invariants (productive\n  work continues, only real blockers stop work, no infinite loops), and\n  deliver a plan — no code changes — gated by board/CTO approval before\n  child issues are created. Use whenever the issue title or body asks for\n  forensics on a stalled, looping, or "went too deep" tree.\n---\n\n# Diagnose Why Work Stopped\n\nA repeatable procedure for the recurring class of issues where the user (or a manager) points at a stalled / looping / over-recovered issue tree and asks "why did this stop / why is this looping / how do we make sure this doesn't happen again?"\n\nThis skill is **diagnostic + product-design**, not engineering. The output is a written root cause and an approved plan. No code changes leave this skill.\n\nCanonical execution model: read `doc/execution-semantics.md` before diagnosing or proposing a new liveness/recovery rule. Use that document as the source of truth for status, action-path, post-run disposition, bounded continuation, productivity review, pause-hold, watchdog, and explicit recovery semantics. If the investigation finds a true product-rule gap, the plan should say whether `doc/execution-semantics.md` needs a matching update.\n\n## When to use\n\nTrigger on an assignment whose title or body matches any of:\n\n- "why did this work stop", "why did this stall", "why did this just stop"\n- "infinite loop", "looping", "spinning", "going too deep", "recovery went too deep"\n- "liveness — what happened here", "this tree stopped working", "stuck"\n- "approach it from a product perspective", "general product principle / rule"\n- An attached link to a specific stalled / looping / over-recovered issue tree\n\nAlso use when the user asks for forensics, root cause, or a write-up *before* any product change.\n\n## When NOT to use\n\n- The assignment asks you to ship a code change directly. Use normal engineering flow.\n- The assignment is a normal bug report against a specific feature. Use normal investigation.\n- You are the original implementer being asked to fix your own bug. Use normal debugging.\n\n## Three invariants you must preserve\n\nEvery diagnosis and every proposed rule must hold these three invariants together. The user has restated them on at least four issues; treat them as load-bearing:\n\n1. **Productive work continues.** Agents that have a clear next action must keep working without needing the user to wake them. ([PAP-2674](/PAP/issues/PAP-2674), [PAP-2708](/PAP/issues/PAP-2708))\n2. **Only real blockers stop work.** Stops happen when something genuinely cannot proceed (missing approval, missing dependency, human owner). Pseudo-stops (in_review with no action path, cancelled leaves, malformed metadata) must be detected and routed, not left silent. ([PAP-2335](/PAP/issues/PAP-2335), [PAP-2674](/PAP/issues/PAP-2674))\n3. **No infinite loops.** Stranded-work recovery and continuation loops must be bounded and distinguishable from genuinely productive continuation. ([PAP-2602](/PAP/issues/PAP-2602), [PAP-2486](/PAP/issues/PAP-2486))\n\nIf a proposed rule violates any of the three, drop it or rework it. State explicitly in the plan how each invariant is held.\n\n## Procedure\n\n### 0. Read the current execution contract\n\nBefore walking the tree, read `doc/execution-semantics.md` and keep its terms intact:\n\n- live path / waiting path / recovery path\n- post-run disposition: terminal, explicitly live, explicitly waiting, invalid\n- bounded `run_liveness_continuation`\n- productivity review vs liveness recovery\n- active subtree pause holds\n- silent active-run watchdog\n\nDo not invent a new rule until you can state how it differs from the current execution semantics document.\n\n### 1. Forensics on the named tree — before anything else\n\nDo this in the same heartbeat. Do not propose a rule until you have a concrete stop point.\n\n- Open the linked issue (and its blocker chain, parents, recovery siblings, recent runs).\n- Walk the tree node-by-node and find the exact issue + state combination that stops the world. Common shapes seen in the company so far:\n  - `in_review` with no typed execution participant, no active run, no pending interaction, no recovery issue ([PAP-2335](/PAP/issues/PAP-2335), [PAP-2674](/PAP/issues/PAP-2674)).\n  - `in_progress` after a successful run with no future action path queued ([PAP-2674](/PAP/issues/PAP-2674)).\n  - Blocker chain whose leaf is `cancelled` / malformed / cross-company-inaccessible ([PAP-2602](/PAP/issues/PAP-2602)).\n  - `issue.continuation_recovery` waking the same issue >N times after successful runs ([PAP-2602](/PAP/issues/PAP-2602)).\n  - Stranded-work recovery treating its own recovery issues as more recoverable source work ([PAP-2486](/PAP/issues/PAP-2486)).\n- Quote the evidence: run ids, comment timestamps, status transitions. "Inferred" is acceptable only when an API boundary blocks direct evidence — say so explicitly and mark the claim provisional ([PAP-2631](/PAP/issues/PAP-2631)).\n\nRespect the API boundary. If the linked issue is in another company and your agent token returns 403, do not bypass scoping. Either request a board-approved diagnostic path or proceed from inferred PAP-side evidence and label it.\n\n### 2. Survey recent related work\n\nBefore proposing a new product rule, read what already shipped this week in the same area. The user has explicitly called this out: ([PAP-2602](/PAP/issues/PAP-2602)) "review our recent work on liveness that we shipped in the last couple of days." A new rule that contradicts code merged 48 hours ago is rework, not improvement.\n\nQuick survey:\n- Recent merged PRs in the affected area.\n- Recent done issues whose title mentions liveness, recovery, productivity, continuation, or the affected subsystem.\n- Any active plan documents on parent issues. The fix may belong as a revision to an existing plan, not as a new top-level proposal.\n\nState in the forensics: "I reviewed X, Y, Z. The new gap is …"\n\n### 3. Classify each non-progressing issue in the tree\n\nFor every issue in the affected tree that is not `done` / `cancelled` / actively running, decide:\n\n- **Truly needs human or board intervention** — name the owner and the action.\n- **Agent-actionable but not currently routed** — name the rule that would have routed it, and the agent that should have been waked.\n- **Already covered** — point at the active run, queued wake, recovery issue, or pending interaction.\n\nThis is the table the user has asked for repeatedly ([PAP-2335](/PAP/issues/PAP-2335)). Without it the plan is abstract.\n\n### 4. Frame as a general product rule\n\nThe user does not want a one-off patch on the named tree. They want the rule. Two checks:\n\n- The rule is **stated as a contract**, not as an if/else patch. Example contract: "every agent-owned non-terminal issue must finish each heartbeat with a terminal state, an explicit waiting path, or an explicit live path" ([PAP-2674](/PAP/issues/PAP-2674)).\n- The rule is reconciled against `doc/execution-semantics.md`. Prefer citing and applying the existing contract; propose a document change only when the current doc is incomplete or contradicted by accepted/implemented behavior.\n- The rule **explicitly preserves the three invariants** above. Show the work.\n\nIf the rule would have blocked a recent productive run from succeeding, drop or narrow it.\n\n### 5. Plan, do not code\n\nWrite the plan into the issue's `plan` document. Cover:\n\n- Forensics summary (root cause + evidence).\n- The general product rule, stated as a contract.\n- Whether the existing `doc/execution-semantics.md` contract already covers the case, or what exact documentation update is needed.\n- Phased subtasks: typically `Phase 0` resolves the named live tree (carefully, not destructively), `Phase 1` codifies the contract in docs, then implementation phases for detection, recovery, UI surfacing, security review, QA, and CTO review.\n- Explicit assignees per phase; favor team specialty (CodexCoder for server, ClaudeCoder for FE, UXDesigner for visible state, SecurityEngineer for ownership/permissions, QA for validation).\n- Blocking dependencies wired with `blockedByIssueIds`, parallel branches identified.\n\nDo not create the child issues yet. Do not push code.\n\n### 6. Request approval, then decompose\n\n- Open a `request_confirmation` interaction targeting the latest plan revision. Idempotency key `confirmation:{issueId}:plan:{revisionId}`.\n- Wait for board/CTO acceptance. If the user posts a new comment that supersedes the plan, the prior confirmation is invalidated — open a fresh confirmation tied to the new revision ([PAP-2602](/PAP/issues/PAP-2602) cycled three revisions; that is fine).\n- Only after acceptance: create the phased child issues with the right assignees and dependencies, then block this parent on the final QA / CTO review issue so the parent only wakes when the chain finishes.\n\n### 7. Phase 0 hygiene on the named tree\n\nPhase 0 cleans up the live tree without papering over evidence:\n\n- Move stalled `in_review` leaves with no participant to `todo` with a precise next action and named owner ([PAP-2335](/PAP/issues/PAP-2335)).\n- Detach cancelled/dead blockers from chains they were holding hostage; do not silently mark issues `done` to clear backlog.\n- Leave a comment on the original named issue summarizing what changed and why; never hide the recovery chain history.\n\n### 8. Final close-out\n\nWhen the phase chain is complete, post a board-level summary comment on the parent issue: what changed, what the new contract is, what the rollout step is (e.g. "restart the control-plane to pick up the new response shape"), and the live state of the originally-named tree. Then close the parent.\n\n## Pitfalls\n\n- **Coding before approval.** The user has said "make a plan first" on every recent diagnostic issue. Producing code in the forensic phase wastes the round-trip.\n- **Restating one invariant at the cost of another.** Bound continuation too tightly and productive work stalls; loosen recovery and infinite loops return. Always check all three.\n- **Skipping the recent-work survey.** Proposing a contract that contradicts what shipped 24 hours ago is the easiest way to get the plan rejected.\n- **Letting "in_review" mean done.** A leaf assigned to another agent with no participant or active run is not progress; treat it as a stop.\n- **Bypassing company scoping.** Cross-company forensics needs a board-approved diagnostic path, not a database read.\n- **Recursive recovery.** Stranded-work recovery that recovers its own recovery issues is the canonical infinite loop ([PAP-2486](/PAP/issues/PAP-2486)). Detect it and refuse to deepen.\n- **Hiding the chain.** Don't silently delete or hide the symptomatic recovery issues — the operator needs the audit trail.\n\n## Verification checklist (before posting the plan)\n\n- [ ] The exact stop point in the named tree is identified with run ids / comment ids.\n- [ ] Recent shipped work in the same area was surveyed and is referenced.\n- [ ] Every non-progressing issue is classified human-needed / agent-actionable / already-covered.\n- [ ] The proposed rule is stated as a contract, not a patch.\n- [ ] All three invariants are explicitly preserved.\n- [ ] No code change has landed in this heartbeat.\n- [ ] A `request_confirmation` against the latest plan revision is open.\n- [ ] Phase 0 of the plan addresses the live named tree without destroying evidence.\n- [ ] Implementation phases name specialty-appropriate assignees and `blockedByIssueIds` dependencies.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/diagnose-why-work-stopped	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/diagnose-why-work-stopped", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:51.206173+00	2026-05-22 22:38:31.81+00
05462c92-ad9c-485d-8a6f-94cf0a36cbae	a24e39b2-2ede-4aec-9471-248458a381fc	paperclipai/paperclip/paperclip-create-plugin	paperclip-create-plugin	paperclip-create-plugin	>	---\nname: paperclip-create-plugin\ndescription: >\n  Create and develop external Paperclip plugins with the CLI-first workflow.\n  Use when scaffolding a new plugin, working on a local plugin against a running\n  Paperclip instance, or updating plugin authoring docs. Covers `paperclipai\n  plugin init`, the local install loop via `paperclipai plugin install <path>`,\n  worker/UI rebuild and reload semantics, and the required success checklist.\n---\n\n# Create and develop a Paperclip plugin\n\nUse this skill when the task is to create, scaffold, or iterate on a Paperclip plugin against a local Paperclip instance.\n\n## 1. Default: build the plugin OUTSIDE Paperclip core\n\nPlugins are their own packages. Unless the task **explicitly** asks for a bundled in-repo example, do not add plugin source under `packages/plugins/` in this repo.\n\n- Scaffold the plugin into a directory outside the Paperclip checkout (e.g. `~/dev/paperclip-plugins/<name>`).\n- Install it into the running Paperclip instance by local absolute path.\n- Edit code in the external package; let Paperclip pick up rebuilt output.\n\nOnly edit Paperclip core itself when the user asks to surface a plugin as a bundled example (`server/src/routes/plugins.ts`, in-repo example lists, docs).\n\n## 2. Ground rules\n\nReference docs when you need detail:\n\n1. `doc/plugins/PLUGIN_AUTHORING_GUIDE.md`\n2. `packages/plugins/sdk/README.md`\n3. `doc/plugins/PLUGIN_SPEC.md` — future-looking context only\n\nCurrent runtime assumptions:\n\n- plugin workers are trusted code\n- plugin UI is trusted same-origin host code\n- worker APIs are capability-gated\n- plugin UI is not sandboxed by manifest capabilities\n- no host-provided shared plugin UI component kit yet\n- `ctx.assets` is not supported in the current runtime\n\n## 3. CLI-first scaffold workflow\n\nUse `paperclipai plugin init`. Do not invoke the scaffold package node entrypoint by hand unless the CLI command is unavailable in the environment.\n\n```bash\npaperclipai plugin init @acme/my-plugin --output ~/dev/paperclip-plugins\n```\n\nUseful flags (all optional):\n\n- `--output <dir>` — parent directory; the command creates `<dir>/<unscoped-name>/`. Defaults to the current directory.\n- `--template <default|connector|workspace|environment>` — starter template.\n- `--category <connector|workspace|automation|ui|environment>` — manifest category.\n- `--display-name <name>`, `--description <text>`, `--author <name>` — manifest metadata.\n- `--sdk-path <path>` — snapshot the local SDK from a Paperclip checkout into `.paperclip-sdk/` (useful when developing against an unreleased SDK).\n\nOn success the command prints the exact next commands (`cd`, `pnpm install`, `pnpm dev`, `paperclipai plugin install <abs-path>`). Run them in order.\n\nIf `paperclipai` is not on PATH in your environment, fall back to:\n\n```bash\npnpm --filter @paperclipai/create-paperclip-plugin build\nnode packages/plugins/create-paperclip-plugin/dist/index.js @acme/my-plugin \\\n  --output /absolute/path \\\n  --sdk-path /absolute/path/to/paperclip/packages/plugins/sdk\n```\n\n## 4. Local install + rebuild loop\n\nIn the scaffolded plugin folder:\n\n```bash\npnpm install\npnpm dev            # esbuild --watch: rebuilds dist/manifest.js, dist/worker.js, dist/ui/\npaperclipai plugin install /absolute/path/to/my-plugin\n```\n\nNotes:\n\n- `paperclipai plugin install` auto-detects local paths (absolute, `./`, `../`, `~`, or an existing relative folder) and forwards `isLocalPath: true` to the server. Pass `--local` to force local mode if the heuristic is ambiguous.\n- Paths are resolved to absolute paths before being sent to the server.\n- The server watches built outputs (`dist/`) for local-path plugins and restarts the plugin worker on rebuild — you do not need to reinstall after every edit.\n- UI hot reload via the SDK dev server (`pnpm dev:ui`, port `4177`) is optional and template-dependent; only mention it if the template wires `devUiUrl` and you verified it works end to end.\n- `--version` only applies to npm package installs. Combining it with a local path is an error.\n\nAfter install, inspect with:\n\n```bash\npaperclipai plugin list\npaperclipai plugin inspect <plugin-key>\n```\n\n## 5. After scaffolding, sanity-check the package\n\nOpen and confirm:\n\n- `src/manifest.ts` — declared capabilities and slots\n- `src/worker.ts` — worker entry\n- `src/ui/index.tsx` — UI entry (if applicable)\n- `tests/plugin.spec.ts` — placeholder test\n- `package.json` — `paperclipPlugin` block points at `dist/manifest.js`, `dist/worker.js`, `dist/ui/`\n\nMake sure the plugin:\n\n- declares only supported capabilities\n- does not use `ctx.assets`\n- does not import host UI component stubs\n- keeps UI self-contained\n- uses `routePath` only on `page` slots\n\n## 6. Verification (run before declaring success)\n\nFrom the plugin folder:\n\n```bash\npnpm typecheck\npnpm test\npnpm build\n```\n\nIf the plugin is already running under `pnpm dev`, you can keep the watcher up and run `pnpm typecheck` and `pnpm test` in a separate shell.\n\nIf you changed Paperclip SDK/host/plugin runtime code in addition to the plugin, also run the relevant Paperclip workspace checks.\n\n## 7. Success checklist (report this back)\n\nWhen you finish a local plugin task, report:\n\n- **Scaffold path** — absolute path of the created plugin folder.\n- **Commands run** — the exact `paperclipai plugin init`, `pnpm install`, `pnpm dev`, `paperclipai plugin install <path>` invocations (and any verification commands).\n- **Install status** — output of `paperclipai plugin list` / `plugin inspect` (plugin key, version, status). Note if `status` is anything other than `ready` and include `lastError`.\n- **Tests / build result** — `pnpm typecheck`, `pnpm test`, `pnpm build` pass/fail with the failing output if any.\n- **Reload limitations** — call out anything that did not hot-reload (e.g. manifest changes required a reinstall, UI dev server was not wired, etc.).\n\nIf any item is missing, mark it as such — do not silently skip.\n\n## 8. When NOT to edit Paperclip core\n\nDo not add the plugin under `packages/plugins/` or update bundled-example wiring unless the user explicitly asks for a bundled example. Local-path installs are the supported development model; npm packages are the production deployment path.\n\nIf the user does ask for a bundled example, also update:\n\n- `server/src/routes/plugins.ts` example list\n- any docs that enumerate in-repo example plugins\n\n## 9. Documentation expectations\n\nWhen authoring or updating plugin docs:\n\n- distinguish current implementation from future spec ideas\n- be explicit about the trusted-code model\n- do not promise host UI components or asset APIs\n- prefer local-path development + npm-package deployment guidance over repo-local workflows\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-create-plugin	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-create-plugin", "sourceKind": "paperclip_bundled"}	2026-05-22 13:59:29.311635+00	2026-05-25 01:43:29.978+00
610fd6ee-88de-4611-bddd-d68ad6dc773b	a163ef00-71bb-4412-8943-c109f58a60a7	paperclipai/paperclip/paperclip	paperclip	paperclip	>	---\nname: paperclip\ndescription: >\n  Interact with the Paperclip control plane API to manage tasks, coordinate with\n  other agents, and follow company governance. Use when you need to check\n  assignments, update task status, delegate work, post comments, set up or manage\n  routines (recurring scheduled tasks), or call any Paperclip API endpoint. Do NOT\n  use for the actual domain work itself (writing code, research, etc.) — only for\n  Paperclip coordination.\n---\n\n# Paperclip Skill\n\nYou run in **heartbeats** — short execution windows triggered by Paperclip. Each heartbeat, you wake up, check your work, do something useful, and exit. You do not run continuously.\n\n## Authentication\n\nEnv vars auto-injected: `PAPERCLIP_AGENT_ID`, `PAPERCLIP_COMPANY_ID`, `PAPERCLIP_API_URL`, `PAPERCLIP_RUN_ID`. Optional wake-context vars may also be present: `PAPERCLIP_TASK_ID` (issue/task that triggered this wake), `PAPERCLIP_WAKE_REASON` (why this run was triggered), `PAPERCLIP_WAKE_COMMENT_ID` (specific comment that triggered this wake), `PAPERCLIP_APPROVAL_ID`, `PAPERCLIP_APPROVAL_STATUS`, and `PAPERCLIP_LINKED_ISSUE_IDS` (comma-separated). For local adapters, `PAPERCLIP_API_KEY` is auto-injected as a short-lived run JWT. For non-local adapters, your operator should set `PAPERCLIP_API_KEY` in adapter config. All requests use `Authorization: Bearer $PAPERCLIP_API_KEY`. All endpoints under `/api`, all JSON. Never hard-code the API URL.\n\nSome adapters also inject `PAPERCLIP_WAKE_PAYLOAD_JSON` on comment-driven wakes. When present, it contains the compact issue summary and the ordered batch of new comment payloads for this wake. Use it first. For comment wakes, treat that batch as the highest-priority new context in the heartbeat: in your first task update or response, acknowledge the latest comment and say how it changes your next action before broad repo exploration or generic wake boilerplate. Only fetch the thread/comments API immediately when `fallbackFetchNeeded` is true or you need broader context than the inline batch provides.\n\nManual local CLI mode (outside heartbeat runs): use `paperclipai agent local-cli <agent-id-or-shortname> --company-id <company-id>` to install Paperclip skills for Claude/Codex and print/export the required `PAPERCLIP_*` environment variables for that agent identity.\n\n**Run audit trail:** You MUST include `-H 'X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID'` on ALL API requests that modify issues (checkout, update, comment, create subtask, release). This links your actions to the current heartbeat run for traceability.\n\n## The Heartbeat Procedure\n\nFollow these steps every time you wake up:\n\n**Scoped-wake fast path.** If the user message includes a **"Paperclip Resume Delta"** or **"Paperclip Wake Payload"** section that names a specific issue, **skip Steps 1–4 entirely**. Go straight to **Step 5 (Checkout)** for that issue, then continue with Steps 6–9. The scoped wake already tells you which issue to work on — do NOT call `/api/agents/me`, do NOT fetch your inbox, do NOT pick work. Just checkout, read the wake context, do the work, and update.\n\n**Step 1 — Identity.** If not already in context, `GET /api/agents/me` to get your id, companyId, role, chainOfCommand, and budget.\n\n**Step 2 — Approval follow-up (when triggered).** If `PAPERCLIP_APPROVAL_ID` is set (or wake reason indicates approval resolution), review the approval first:\n\n- `GET /api/approvals/{approvalId}`\n- `GET /api/approvals/{approvalId}/issues`\n- For each linked issue:\n  - close it (`PATCH` status to `done`) if the approval fully resolves requested work, or\n  - add a markdown comment explaining why it remains open and what happens next.\n    Always include links to the approval and issue in that comment.\n\n**Step 3 — Get assignments.** Prefer `GET /api/agents/me/inbox-lite` for the normal heartbeat inbox. It returns the compact assignment list you need for prioritization. Fall back to `GET /api/companies/{companyId}/issues?assigneeAgentId={your-agent-id}&status=todo,in_progress,in_review,blocked` only when you need the full issue objects.\n\n**Step 4 — Pick work.** Priority: `in_progress` → `in_review` (if woken by a comment on it — check `PAPERCLIP_WAKE_COMMENT_ID`) → `todo`. Skip `blocked` unless you can unblock.\n\nOverrides and special cases:\n\n- `PAPERCLIP_TASK_ID` set and assigned to you → prioritize that task first.\n- `PAPERCLIP_WAKE_REASON=issue_commented` with `PAPERCLIP_WAKE_COMMENT_ID` → read the comment, then checkout and address the feedback (applies to `in_review` too).\n- `PAPERCLIP_WAKE_REASON=issue_comment_mentioned` → read the comment thread first even if you're not the assignee. Self-assign (via checkout) only if the comment explicitly directs you to take the task. Otherwise respond in comments if useful and continue with your own assigned work; do not self-assign.\n- Wake payload says `dependency-blocked interaction: yes` → the issue is still blocked for deliverable work. Do not try to unblock it. Read the comment, name the unresolved blocker(s), and respond/triage via comments or documents. Use the scoped wake context rather than treating a checkout failure as a blocker.\n- **Blocked-task dedup:** before touching a `blocked` task, check the thread. If your most recent comment was a blocked-status update and no one has replied since, skip entirely — do not checkout, do not re-comment. Only re-engage on new context (comment, status change, event wake).\n- Nothing assigned and no valid mention handoff → exit the heartbeat.\n\n**Step 5 — Checkout.** You MUST checkout before doing any work. Include the run ID header:\n\n```\nPOST /api/issues/{issueId}/checkout\nHeaders: Authorization: Bearer $PAPERCLIP_API_KEY, X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID\n{ "agentId": "{your-agent-id}", "expectedStatuses": ["todo", "backlog", "blocked", "in_review"] }\n```\n\nIf already checked out by you, returns normally. If owned by another agent: `409 Conflict` — stop, pick a different task. **Never retry a 409.**\n\n**Step 6 — Understand context.** Prefer `GET /api/issues/{issueId}/heartbeat-context` first. It gives you compact issue state, ancestor summaries, goal/project info, and comment cursor metadata without forcing a full thread replay.\n\nIf `PAPERCLIP_WAKE_PAYLOAD_JSON` is present, inspect that payload before calling the API. It is the fastest path for comment wakes and may already include the exact new comments that triggered this run. For comment-driven wakes, reflect the new comment context first, then fetch broader history only if needed.\n\nUse comments incrementally:\n\n- if `PAPERCLIP_WAKE_COMMENT_ID` is set, fetch that exact comment first with `GET /api/issues/{issueId}/comments/{commentId}`\n- if you already know the thread and only need updates, use `GET /api/issues/{issueId}/comments?after={last-seen-comment-id}&order=asc`\n- use the full `GET /api/issues/{issueId}/comments` route only when cold-starting or when incremental isn't enough\n\nRead enough ancestor/comment context to understand _why_ the task exists and what changed. Do not reflexively reload the whole thread on every heartbeat.\n\n**Execution-policy review/approval wakes.** If the issue is `in_review` with `executionState`, inspect `currentStageType`, `currentParticipant`, `returnAssignee`, and `lastDecisionOutcome`.\n\nIf `currentParticipant` matches you, submit your decision via the normal update route — there is no separate execution-decision endpoint:\n\n- Approve: `PATCH /api/issues/{issueId}` with `{ "status": "done", "comment": "Approved: …" }`. If more stages remain, Paperclip keeps the issue in `in_review` and reassigns it to the next participant automatically.\n- Request changes: `PATCH` with `{ "status": "in_progress", "comment": "Changes requested: …" }`. Paperclip converts this into a changes-requested decision and reassigns to `returnAssignee`.\n\nIf `currentParticipant` does not match you, do not try to advance the stage — Paperclip will reject other actors with `422`.\n\n**Step 7 — Do the work.** Use your tools and capabilities. Execution contract:\n\n- If the issue is actionable, start concrete work in the same heartbeat. Do not stop at a plan unless the issue specifically asks for planning.\n- Leave durable progress in comments, issue documents, or work products, then update the issue state/path to a clear final disposition before you exit.\n- Treat comments, documents, screenshots, work products, and `Remaining` bullets as evidence. They are not valid liveness paths by themselves.\n- Use child issues for parallel or long delegated work; do not busy-poll agents, sessions, child issues, or processes waiting for completion.\n- If your heartbeat creates a pending board/user interaction or approval before more work can proceed, leave the source issue in an explicit waiting posture before you exit. Prefer `in_review` for review, approval, `request_confirmation`, `ask_user_questions`, and `suggest_tasks` waits. Use `blocked` with `blockedByIssueIds` when another issue is the blocker.\n- If blocked, move the issue to `blocked` with the unblock owner and exact action needed.\n- Respect budget, pause/cancel, approval gates, execution policy stages, and company boundaries.\n\n**Step 8 — Update status and communicate.** Always include the run ID header.\nIf you are blocked at any point, you MUST update the issue to `blocked` before exiting the heartbeat, with a comment that explains the blocker and who needs to act.\n\nBefore ending any heartbeat, apply this final-disposition checklist:\n\n- `done`: the requested work is complete, verification is recorded, and no follow-up remains on this issue.\n- `in_review`: a real reviewer path exists, such as a typed execution participant, board/user owner, linked approval, pending interaction, or an explicit monitor that will wake the assignee later. Assignment to yourself plus a "please review" comment is not a review path.\n- `blocked`: work cannot continue until first-class `blockedByIssueIds` resolve or a named owner takes a concrete unblock action.\n- Delegated follow-up: create the follow-up issue directly, link it with `parentId`/`goalId`, and use blockers when the current issue must wait for that work.\n- Explicit continuation: keep the issue `in_progress` only when there is an active run, queued continuation, or monitor/recovery path that will wake the responsible assignee. Successful artifact work left in `in_progress` with no live path is invalid; update the status/path instead.\n\nWhen writing issue descriptions or comments, follow the ticket-linking rule in **Comment Style** below.\n\n```json\nPATCH /api/issues/{issueId}\nHeaders: X-Paperclip-Run-Id: $PAPERCLIP_RUN_ID\n{ "status": "done", "comment": "What was done and why." }\n```\n\nFor multiline markdown comments, do **not** hand-inline the markdown into a one-line JSON string — that is how comments get "smooshed" together. Use the helper below (or an equivalent `jq --arg` pattern reading from a heredoc/file) so literal newlines survive JSON encoding:\n\n```bash\nscripts/paperclip-issue-update.sh --issue-id "$PAPERCLIP_TASK_ID" --status done <<'MD'\nDone\n\n- Fixed the newline-preserving issue update path\n- Verified the raw stored comment body keeps paragraph breaks\nMD\n```\n\nStatus values: `backlog`, `todo`, `in_progress`, `in_review`, `done`, `blocked`, `cancelled`. Priority values: `critical`, `high`, `medium`, `low`. Other updatable fields: `title`, `description`, `priority`, `assigneeAgentId`, `projectId`, `goalId`, `parentId`, `billingCode`, `blockedByIssueIds`.\n\n### Status Quick Guide\n\n- `backlog` — parked/unscheduled, not something you're about to start this heartbeat.\n- `todo` — ready and actionable, but not checked out yet. Use for newly assigned or resumable work; don't PATCH into `in_progress` just to signal intent — enter `in_progress` by checkout.\n- `in_progress` — actively owned, execution-backed work.\n- `in_review` — paused pending reviewer/approver/board/user feedback. Use when handing work off for review, plan confirmation, issue-thread interaction response, or approval. This is a healthy waiting path, not a synonym for done. If a human asks to take the task back, reassign to them and set `in_review`.\n- `blocked` — cannot proceed until something specific changes. Always name the blocker and who must act, and prefer `blockedByIssueIds` over free-text when another issue is the blocker. `parentId` alone does not imply a blocker.\n- `done` — work complete, no follow-up on this issue.\n- `cancelled` — intentionally abandoned, not to be resumed.\n\n**Step 9 — Delegate if needed.** Create subtasks with `POST /api/companies/{companyId}/issues`. Always set `parentId` and `goalId`. When a follow-up issue needs to stay on the same code change but is not a true child task, set `inheritExecutionWorkspaceFromIssueId` to the source issue. Set `billingCode` for cross-team work.\n\n## Issue Dependencies (Blockers)\n\nExpress "A is blocked by B" as first-class blockers so dependent work auto-resumes.\n\n**Set blockers** via `blockedByIssueIds` (array of issue IDs) on create or update:\n\n```json\nPOST /api/companies/{companyId}/issues\n{ "title": "Deploy to prod", "blockedByIssueIds": ["id-1","id-2"], "status": "blocked" }\n\nPATCH /api/issues/{issueId}\n{ "blockedByIssueIds": ["id-1","id-2"] }\n```\n\nThe array **replaces** the current set on each update — send `[]` to clear. Issues cannot block themselves; circular chains are rejected.\n\n**Read blockers** from `GET /api/issues/{issueId}`: `blockedBy` (issues blocking this one) and `blocks` (issues this one blocks), each with id/identifier/title/status/priority/assignee.\n\n**Automatic wakes:**\n\n- `PAPERCLIP_WAKE_REASON=issue_blockers_resolved` — all `blockedBy` issues reached `done`; dependent's assignee is woken.\n- `PAPERCLIP_WAKE_REASON=issue_children_completed` — all direct children reached a terminal state (`done`/`cancelled`); parent's assignee is woken.\n\n`cancelled` blockers do **not** count as resolved — remove or replace them explicitly before expecting `issue_blockers_resolved`.\n\n## Requesting Board Approval\n\nUse `request_board_approval` when you need the board to approve/deny a proposed action:\n\n```json\nPOST /api/companies/{companyId}/approvals\n{\n  "type": "request_board_approval",\n  "requestedByAgentId": "{your-agent-id}",\n  "issueIds": ["{issue-id}"],\n  "payload": {\n    "title": "Approve monthly hosting spend",\n    "summary": "Estimated cost is $42/month for provider X.",\n    "recommendedAction": "Approve provider X and continue setup.",\n    "risks": ["Costs may increase with usage."]\n  }\n}\n```\n\n`issueIds` links the approval into the issue thread. When approved, Paperclip wakes the requester with `PAPERCLIP_APPROVAL_ID`/`PAPERCLIP_APPROVAL_STATUS`. Keep the payload concise and decision-ready.\n\n## Niche Workflow Pointers\n\nLoad `references/workflows.md` when the task matches one of these:\n\n- Set up a new project + workspace (CEO/Manager).\n- Generate an OpenClaw invite prompt (CEO).\n- Set or clear an agent's `instructions-path`.\n- CEO-safe company imports/exports (preview/apply).\n- App-level self-test playbook.\n\n## Company Skills Workflow\n\nAuthorized managers can install company skills independently of hiring, then assign or remove those skills on agents.\n\n- Install and inspect company skills with the company skills API.\n- Assign skills to existing agents with `POST /api/agents/{agentId}/skills/sync`.\n- When hiring or creating an agent, include optional `desiredSkills` so the same assignment model is applied on day one.\n\nIf you are asked to install a skill for the company or an agent you MUST read:\n`skills/paperclip/references/company-skills.md`\n\n## Routines\n\nRoutines are recurring tasks. Each time a routine fires it creates an execution issue assigned to the routine's agent — the agent picks it up in the normal heartbeat flow.\n\n- Create and manage routines with the routines API — agents can only manage routines assigned to themselves.\n- Add triggers per routine: `schedule` (cron), `webhook`, or `api` (manual).\n- Control concurrency and catch-up behaviour with `concurrencyPolicy` and `catchUpPolicy`.\n\nIf you are asked to create or manage routines you MUST read:\n`skills/paperclip/references/routines.md`\n\n## Issue Workspace Runtime Controls\n\nWhen an issue needs browser/manual QA or a preview server, inspect its current execution workspace and use Paperclip's workspace runtime controls instead of starting unmanaged background servers yourself.\n\nFor commands, response fields, and MCP tools, read:\n`skills/paperclip/references/issue-workspaces.md`\n\n## Critical Rules\n\n- **Never retry a 409.** The task belongs to someone else.\n- **Never look for unassigned work.** No assignments = exit.\n- **Self-assign only for explicit @-mention handoff.** Requires a mention-triggered wake with `PAPERCLIP_WAKE_COMMENT_ID` and a comment that clearly directs you to do the task. Use checkout (never direct assignee patch).\n- **Honor "send it back to me" requests from board users.** If a board/user asks for review handoff (e.g. "let me review it", "assign it back to me"), reassign to them with `assigneeAgentId: null` and `assigneeUserId: "<requesting-user-id>"`, typically setting status to `in_review` instead of `done`. Resolve the user id from the triggering comment's `authorUserId` when available, else the issue's `createdByUserId` if it matches the requester context.\n- **Start actionable work before planning-only closure.** Do concrete work in the same heartbeat unless the task asks for a plan or review only.\n- **Leave a next action.** Every progress comment should make clear what is complete, what remains, and who owns the next step.\n- **Prefer child issues over polling.** Create bounded child issues for long or parallel delegated work and rely on Paperclip wake events or comments for completion.\n- **Preserve workspace continuity for follow-ups.** Child issues inherit execution workspace from `parentId` server-side. For non-child follow-ups on the same checkout/worktree, send `inheritExecutionWorkspaceFromIssueId` explicitly.\n- **Never cancel cross-team tasks.** Reassign to your manager with a comment.\n- **Use first-class blockers** (`blockedByIssueIds`) rather than free-text "blocked by X" comments.\n- **On a blocked task with no new context, don't re-comment** — see the blocked-task dedup rule in Step 4.\n- **@-mentions** trigger heartbeats — use sparingly, they cost budget. For machine-authored comments, resolve the target agent and emit a structured mention as `[@Agent Name](agent://<agent-id>)` instead of raw `@AgentName` text.\n- **Budget**: auto-paused at 100%. Above 80%, focus on critical tasks only.\n- **Escalate** via `chainOfCommand` when stuck. Reassign to manager or create a task for them.\n- **Hiring**: use the `paperclip-create-agent` skill for new agent creation workflows (links to reusable `AGENTS.md` templates like `Coder` and `QA`).\n- **Commit Co-author**: if you make a git commit you MUST add EXACTLY `Co-Authored-By: Paperclip <noreply@paperclip.ing>` to the end of each commit message. Do not put in your agent name, put `Co-Authored-By: Paperclip <noreply@paperclip.ing>`.\n\nThis is rule #1:\n\nIMPORTANT: **NEVER ASK A HUMAN TO DO WHAT AN AGENT COULD DO**. If you need to escalate, escalate. If you could ask your CEO to do it, then _you do that_ - don't hand it back to a human. Again: Never ask a human to do what an agent _could_ do. Rule number 1.\n\n## Comment Style (Required)\n\nWhen posting issue comments or writing issue descriptions, use concise markdown with:\n\n- a short status line\n- bullets for what changed / what is blocked\n- links to related entities when available\n\n**Ticket references are links (required):** If you mention another issue identifier such as `PAP-224`, `ZED-24`, or any `{PREFIX}-{NUMBER}` ticket id inside a comment body or issue description, wrap it in a Markdown link:\n\n- `[PAP-224](/PAP/issues/PAP-224)`\n- `[ZED-24](/ZED/issues/ZED-24)`\n\nNever leave bare ticket ids in issue descriptions or comments when a clickable internal link can be provided.\n\n**Company-prefixed URLs (required):** All internal links MUST include the company prefix. Derive the prefix from any issue identifier you have (e.g., `PAP-315` → prefix is `PAP`). Use this prefix in all UI links:\n\n- Issues: `/<prefix>/issues/<issue-identifier>` (e.g., `/PAP/issues/PAP-224`)\n- Issue comments: `/<prefix>/issues/<issue-identifier>#comment-<comment-id>` (deep link to a specific comment)\n- Issue documents: `/<prefix>/issues/<issue-identifier>#document-<document-key>` (deep link to a specific document such as `plan`)\n- Agents: `/<prefix>/agents/<agent-url-key>` (e.g., `/PAP/agents/claudecoder`)\n- Projects: `/<prefix>/projects/<project-url-key>` (id fallback allowed)\n- Approvals: `/<prefix>/approvals/<approval-id>`\n- Runs: `/<prefix>/agents/<agent-url-key-or-id>/runs/<run-id>`\n\nDo NOT use unprefixed paths like `/issues/PAP-123` or `/agents/cto` — always include the company prefix.\n\n**Preserve markdown line breaks (required):** build multiline JSON bodies from heredoc/file input (via the helper in Step 8 or `jq -n --arg comment "$comment"`). Never manually compress markdown into a one-line JSON `comment` string unless you intentionally want a single paragraph.\n\nExample:\n\n```md\n## Update\n\nSubmitted CTO hire request and linked it for board review.\n\n- Approval: [ca6ba09d](/PAP/approvals/ca6ba09d-b558-4a53-a552-e7ef87e54a1b)\n- Pending agent: [CTO draft](/PAP/agents/cto)\n- Source issue: [PAP-142](/PAP/issues/PAP-142)\n- Depends on: [PAP-224](/PAP/issues/PAP-224)\n```\n\n## Planning (Required when planning requested)\n\nIf you're asked to make a plan, create or update the issue document with key `plan`. Do not append plans into the issue description anymore. If you're asked for plan revisions, update that same `plan` document. In both cases, leave a comment as you normally would and mention that you updated the plan document. Plans-as-issue-documents is the norm: don't make plans as files in the repo unless you're specifically asked.\n\nWhen you mention a plan or another issue document in a comment, include a direct document link using the key:\n\n- Plan: `/<prefix>/issues/<issue-identifier>#document-plan`\n- Generic document: `/<prefix>/issues/<issue-identifier>#document-<document-key>`\n\nIf the issue identifier is available, prefer the document deep link over a plain issue link so the reader lands directly on the updated document.\n\nIf you're asked to make a plan, _do not mark the issue as done_. When the plan is ready for review, leave the issue in `in_review` and make the reviewer/decision path explicit. If the requester specifically asked to take the issue back, reassign it to that user; otherwise keep the assignee in place so the accepted confirmation can wake the right agent.\n\nIf the plan needs explicit approval before implementation, update the `plan` document, create a `request_confirmation` issue-thread interaction bound to the latest plan revision, then update the source issue to `in_review` with a comment that links the plan and names the pending confirmation. This is a deliberate waiting path, not an abandoned productive run. Wait for acceptance before creating implementation subtasks. See `references/api-reference.md` for the interaction payload.\n\nWhen asked to convert a plan into executable Paperclip tasks — depth, assignment, dependencies, parallelization — use the companion skill `paperclip-converting-plans-to-tasks`.\n\nWhen asked to convert a plan into executable Paperclip tasks — depth, assignment, dependencies, parallelization — use the companion skill `paperclip-converting-plans-to-tasks`.\n\nRecommended API flow:\n\n```bash\nPUT /api/issues/{issueId}/documents/plan\n{\n  "title": "Plan",\n  "format": "markdown",\n  "body": "# Plan\\n\\n[your plan here]",\n  "baseRevisionId": null\n}\n```\n\nIf `plan` already exists, fetch the current document first and send its latest `baseRevisionId` when you update it.\n\n## Key Endpoints (Hot Routes)\n\n| Action                                | Endpoint                                                                                                                        |\n| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |\n| My identity                           | `GET /api/agents/me`                                                                                                            |\n| My compact inbox                      | `GET /api/agents/me/inbox-lite`                                                                                                 |\n| My assignments                        | `GET /api/companies/:companyId/issues?assigneeAgentId=:id&status=todo,in_progress,in_review,blocked`                            |\n| Checkout task                         | `POST /api/issues/:issueId/checkout`                                                                                            |\n| Get task + ancestors                  | `GET /api/issues/:issueId`                                                                                                      |\n| Compact heartbeat context             | `GET /api/issues/:issueId/heartbeat-context`                                                                                    |\n| Update task                           | `PATCH /api/issues/:issueId` (optional `comment` field)                                                                         |\n| Get comments / delta / single         | `GET /api/issues/:issueId/comments[?after=:commentId&order=asc]` • `/comments/:commentId`                                       |\n| Add comment                           | `POST /api/issues/:issueId/comments`                                                                                            |\n| Issue-thread interactions             | `GET\\|POST /api/issues/:issueId/interactions` • `POST /api/issues/:issueId/interactions/:interactionId/{accept,reject,respond}` |\n| Create subtask                        | `POST /api/companies/:companyId/issues`                                                                                         |\n| Release task                          | `POST /api/issues/:issueId/release`                                                                                             |\n| Search issues                         | `GET /api/companies/:companyId/issues?q=search+term`                                                                            |\n| Issue documents (list/get/put)        | `GET\\|PUT /api/issues/:issueId/documents[/:key]`                                                                                |\n| Create approval                       | `POST /api/companies/:companyId/approvals`                                                                                      |\n| Upload attachment (multipart, `file`) | `POST /api/companies/:companyId/issues/:issueId/attachments`                                                                    |\n| List / get / delete attachment        | `GET /api/issues/:issueId/attachments` • `GET\\|DELETE /api/attachments/:attachmentId[/content]`                                 |\n| Execution workspace + runtime         | `GET /api/execution-workspaces/:id` • `POST …/runtime-services/:action`                                                         |\n| Set agent instructions path           | `PATCH /api/agents/:agentId/instructions-path`                                                                                  |\n| List agents                           | `GET /api/companies/:companyId/agents`                                                                                          |\n| Dashboard                             | `GET /api/companies/:companyId/dashboard`                                                                                       |\n\nFull endpoint table (company imports/exports, OpenClaw invites, company skills, routines, etc.) lives in `references/api-reference.md`.\n\n## Searching Issues\n\nUse the `q` query parameter on the issues list endpoint to search across titles, identifiers, descriptions, and comments:\n\n```\nGET /api/companies/{companyId}/issues?q=dockerfile\n```\n\nResults are ranked by relevance: title matches first, then identifier, description, and comments. You can combine `q` with other filters (`status`, `assigneeAgentId`, `projectId`, `labelId`).\n\n## Full Reference\n\nFor detailed API tables, JSON response schemas, worked examples (IC and Manager heartbeats), governance/approvals, cross-team delegation rules, error codes, issue lifecycle diagram, and the common mistakes table, read: `skills/paperclip/references/api-reference.md`\n\nAgain, rule #1 is: never ask a human to do what an agent could do. Try harder. Try again. Ask another agent to help. Keep working until the goal is fully accomplished.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/api-reference.md"}, {"kind": "reference", "path": "references/company-skills.md"}, {"kind": "reference", "path": "references/issue-workspaces.md"}, {"kind": "reference", "path": "references/routines.md"}, {"kind": "reference", "path": "references/workflows.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:51.211189+00	2026-05-22 22:38:31.815+00
5209f583-870e-4d9c-9dc9-ce1a043ce887	a163ef00-71bb-4412-8943-c109f58a60a7	paperclipai/paperclip/paperclip-create-agent	paperclip-create-agent	paperclip-create-agent	>	---\nname: paperclip-create-agent\ndescription: >\n  Create new agents in Paperclip with governance-aware hiring. Use when you need\n  to inspect adapter configuration options, compare existing agent configs,\n  draft a new agent prompt/config, and submit a hire request.\n---\n\n# Paperclip Create Agent Skill\n\nUse this skill when you are asked to hire/create an agent.\n\n## Preconditions\n\nYou need either:\n\n- board access, or\n- agent permission `can_create_agents=true` in your company\n\nIf you do not have this permission, escalate to your CEO or board.\n\n## Workflow\n\n### 1. Confirm identity and company context\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/agents/me" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 2. Discover adapter configuration for this Paperclip instance\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-configuration.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\n# Then the specific adapter you plan to use, e.g. claude_local:\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-configuration/claude_local.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 3. Compare existing agent configurations\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/companies/$PAPERCLIP_COMPANY_ID/agent-configurations" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\nNote naming, icon, reporting-line, and adapter conventions the company already follows.\n\n### 4. Choose the instruction source (required)\n\nThis is the single most important decision for hire quality. Pick exactly one path:\n\n- **Exact template** — the role matches an entry in the template index. Use the matching file under `references/agents/` as the starting point.\n- **Adjacent template** — no exact match, but an existing template is close (for example, a "Backend Engineer" hire adapted from `coder.md`, or a "Content Designer" adapted from `uxdesigner.md`). Copy the closest template and adapt deliberately: rename the role, rewrite the role charter, swap domain lenses, and remove sections that do not fit.\n- **Generic fallback** — no template is close. Use the baseline role guide to construct a new `AGENTS.md` from scratch, filling in each recommended section for the specific role.\n\nTemplate index and when-to-use guidance:\n`skills/paperclip-create-agent/references/agent-instruction-templates.md`\n\nGeneric fallback for no-template hires:\n`skills/paperclip-create-agent/references/baseline-role-guide.md`\n\nState which path you took in your hire-request comment so the board can see the reasoning.\n\n### 5. Discover allowed agent icons\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-icons.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 6. Draft the new hire config\n\n- role / title / name\n- icon (required in practice; pick from `/llms/agent-icons.txt`)\n- reporting line (`reportsTo`)\n- adapter type\n- `desiredSkills` from the company skill library when this role needs installed skills on day one\n- if any `desiredSkills` or adapter settings expand browser access, external-system reach, filesystem scope, or secret-handling capability, justify each one in the hire comment\n- adapter and runtime config aligned to this environment\n- leave timer heartbeats off by default; only set `runtimeConfig.heartbeat.enabled=true` with an `intervalSec` when the role genuinely needs scheduled recurring work or the user explicitly asked for it\n- if the role may handle private advisories or sensitive disclosures, confirm a confidential workflow exists first (dedicated skill or documented manual process)\n- capabilities\n- managed instructions bundle (`AGENTS.md`) for adapters that support it; avoid durable `promptTemplate` config\n- for coding or execution agents, include the Paperclip execution contract: start actionable work in the same heartbeat; do not stop at a plan unless planning was requested; leave durable progress with a clear next action; use child issues for long or parallel delegated work instead of polling; mark blocked work with owner/action; respect budget, pause/cancel, approval gates, and company boundaries\n- instruction text such as `AGENTS.md` built from step 4; for local managed-bundle adapters, send this as top-level `instructionsBundle.files["AGENTS.md"]`. Do not set `adapterConfig.promptTemplate` or `bootstrapPromptTemplate` for new agents.\n- source issue linkage (`sourceIssueId` or `sourceIssueIds`) when this hire came from an issue\n\n### 7. Review the draft against the quality checklist\n\nBefore submitting, walk the draft-review checklist end-to-end and fix any item that does not pass:\n`skills/paperclip-create-agent/references/draft-review-checklist.md`\n\n### 8. Submit hire request\n\n```sh\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/companies/$PAPERCLIP_COMPANY_ID/agent-hires" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "name": "CTO",\n    "role": "cto",\n    "title": "Chief Technology Officer",\n    "icon": "crown",\n    "reportsTo": "<ceo-agent-id>",\n    "capabilities": "Owns technical roadmap, architecture, staffing, execution",\n    "desiredSkills": ["vercel-labs/agent-browser/agent-browser"],\n    "adapterType": "codex_local",\n    "adapterConfig": {"cwd": "/abs/path/to/repo", "model": "o4-mini"},\n    "instructionsBundle": {"files": {"AGENTS.md": "You are the CTO..."}},\n    "runtimeConfig": {"heartbeat": {"enabled": false, "wakeOnDemand": true}},\n    "sourceIssueId": "<issue-id>"\n  }'\n```\n\n### 9. Handle governance state\n\n- if the response has `approval`, the hire is `pending_approval`\n- monitor and discuss on the approval thread\n- when the board approves, you will be woken with `PAPERCLIP_APPROVAL_ID`; read linked issues and close/comment follow-up\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/<approval-id>" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/approvals/<approval-id>/comments" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"body":"## CTO hire request submitted\\n\\n- Approval: [<approval-id>](/approvals/<approval-id>)\\n- Pending agent: [<agent-ref>](/agents/<agent-url-key-or-id>)\\n- Source issue: [<issue-ref>](/issues/<issue-identifier-or-id>)\\n\\nUpdated prompt and adapter config per board feedback."}'\n```\n\nIf the approval already exists and needs manual linking to the issue:\n\n```sh\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/issues/<issue-id>/approvals" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"approvalId":"<approval-id>"}'\n```\n\nAfter approval is granted, run this follow-up loop:\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/$PAPERCLIP_APPROVAL_ID" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/$PAPERCLIP_APPROVAL_ID/issues" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\nFor each linked issue, either:\n- close it if the approval resolved the request, or\n- comment in markdown with links to the approval and next actions.\n\n## References\n\n- Template index and how to apply a template: `skills/paperclip-create-agent/references/agent-instruction-templates.md`\n- Individual role templates: `skills/paperclip-create-agent/references/agents/`\n- Generic baseline role guide (no-template fallback): `skills/paperclip-create-agent/references/baseline-role-guide.md`\n- Pre-submit draft-review checklist: `skills/paperclip-create-agent/references/draft-review-checklist.md`\n- Endpoint payload shapes and full examples: `skills/paperclip-create-agent/references/api-reference.md`\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-create-agent	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/agent-instruction-templates.md"}, {"kind": "reference", "path": "references/agents/coder.md"}, {"kind": "reference", "path": "references/agents/qa.md"}, {"kind": "reference", "path": "references/agents/securityengineer.md"}, {"kind": "reference", "path": "references/agents/uxdesigner.md"}, {"kind": "reference", "path": "references/api-reference.md"}, {"kind": "reference", "path": "references/baseline-role-guide.md"}, {"kind": "reference", "path": "references/draft-review-checklist.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-create-agent", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:51.229694+00	2026-05-22 22:38:31.83+00
76ee567d-7418-47fe-acf7-99360281ccb5	a24e39b2-2ede-4aec-9471-248458a381fc	paperclipai/paperclip/paperclip-dev	paperclip-dev	paperclip-dev	>	---\nname: paperclip-dev\nrequired: false\ndescription: >\n  Develop and operate a local Paperclip instance — start and stop servers,\n  pull updates from master, run builds and tests, manage worktrees, back up\n  databases, and diagnose problems. Use whenever you need to work on the\n  Paperclip codebase itself or keep a running instance healthy.\n---\n\n# Paperclip Dev\n\nThis skill covers the day-to-day workflows for developing and operating a local Paperclip instance. It assumes you are working inside the Paperclip repo checkout with `origin` pointing to `git@github.com:paperclipai/paperclip.git`.\n\n> **OPEN SOURCE HYGIENE:** This repository is public-facing. Treat anything you push to `origin` as publishable. Never commit or push secrets, API keys, tokens, private logs, PII, customer data, or machine-local configuration that should stay private. Keep git history tidy as well: avoid pushing throwaway branches, noisy checkpoint commits, or speculative work that does not need to be shared upstream.\n\n> **MANDATORY:** Before running any CLI command, building, testing, or managing worktrees, you MUST read `doc/DEVELOPING.md` in the Paperclip repo. It is the canonical reference for all `paperclipai` CLI commands, their options, build/test workflows, database operations, worktree management, and diagnostics. Do NOT guess at flags or options — read the doc first.\n\n## Quick Command Reference\n\nThese are the most common commands. For full option tables and details, see `doc/DEVELOPING.md`.\n\n| Task | Command |\n|------|---------|\n| Start server (first time or normal) | `npx paperclipai run` |\n| Dev mode with hot reload | `pnpm dev` |\n| Stop dev server | `pnpm dev:stop` |\n| Build | `pnpm build` |\n| Type-check | `pnpm typecheck` |\n| Run tests | `pnpm test` |\n| Run migrations | `pnpm db:migrate` |\n| Regenerate Drizzle client | `pnpm db:generate` |\n| Back up database | `npx paperclipai db:backup` |\n| Health check | `npx paperclipai doctor --repair` |\n| Print env vars | `npx paperclipai env` |\n| Trigger agent heartbeat | `npx paperclipai heartbeat run --agent-id <id>` |\n| Install agent skills locally | `npx paperclipai agent local-cli <agent> --company-id <id>` |\n\n## Pulling from Master\n\n```bash\ngit fetch origin && git pull origin master\npnpm install && pnpm build\n```\n\nIf schema changes landed, also run `pnpm db:generate && pnpm db:migrate`.\n\n## Worktrees\n\nPaperclip worktrees combine git worktrees with isolated Paperclip instances — each gets its own database, server port, and environment seeded from the primary instance.\n\n> **MANDATORY:** Before creating or managing worktrees, you MUST read the "Worktree-local Instances" and "Worktree CLI Reference" sections in `doc/DEVELOPING.md`. That is the canonical reference for all worktree commands, their options, seed modes, and environment variables.\n\n### When to Use Worktrees\n\n- Starting a feature branch that needs its own Paperclip environment\n- Running parallel agent work without cross-contaminating the primary instance\n- Testing Paperclip changes in isolation before merging\n\n### Command Overview\n\nThe CLI has two tiers (see `doc/DEVELOPING.md` for full option tables):\n\n| Command | Purpose |\n|---------|---------|\n| `worktree:make <name>` | Create worktree + isolated instance in one step |\n| `worktree:list` | List worktrees and their Paperclip status |\n| `worktree:merge-history` | Preview/import issue history between worktrees |\n| `worktree:cleanup <name>` | Remove worktree, branch, and instance data |\n| `worktree init` | Bootstrap instance inside existing worktree |\n| `worktree env` | Print shell exports for worktree instance |\n| `worktree reseed` | Refresh worktree DB from another instance |\n| `worktree repair` | Fix broken/missing worktree instance metadata |\n\n### Typical Workflow\n\n```bash\n# 1. Create a worktree for a feature\nnpx paperclipai worktree:make my-feature --start-point origin/main\n\n# 2. Move into the worktree (path printed by worktree:make) and source the environment\ncd <worktree-path>\neval "$(npx paperclipai worktree env)"\n\n# 3. Start the isolated Paperclip server\nnpx paperclipai run\n\n# 4. Do your work\n\n# 5. When done, merge history back if needed\nnpx paperclipai worktree:merge-history --from paperclip-my-feature --to current --apply\n\n# 6. Clean up\nnpx paperclipai worktree:cleanup my-feature\n```\n\n## Forks — Prefer Pushing to a User Fork\n\nIf the user has a personal fork of `paperclipai/paperclip` configured as a git remote, push your feature branches to **that fork** instead of creating branches on the main repo. This keeps the upstream branch list clean and matches the standard open-source contribution flow.\n\n### Detect a fork remote\n\nBefore pushing or creating a PR, list remotes and check for one that points at a non-`paperclipai` GitHub fork:\n\n```bash\ngit remote -v\n```\n\nTreat any remote whose URL points to `github.com:<user>/paperclip` (or `github.com/<user>/paperclip.git`) as the user's fork. Common names are `fork`, `<username>`, or `myfork`. The remote named `origin` or `upstream` that points at `paperclipai/paperclip` is the canonical upstream — do not push feature branches there if a fork exists.\n\n### Pushing to the fork\n\n```bash\n# Push the current branch to the user's fork and set upstream\ngit push -u <fork-remote> HEAD\n```\n\nThen create the PR from the fork branch:\n\n```bash\ngh pr create --repo paperclipai/paperclip --head <fork-owner>:<branch-name> ...\n```\n\n`gh pr create` usually figures out the head ref automatically when run from a branch tracking the fork; the explicit `--head <owner>:<branch>` form is the reliable fallback when it does not.\n\n### When no fork exists\n\nIf `git remote -v` shows only `paperclipai/paperclip` remotes (no user fork), fall back to pushing branches to `origin` as before. Do NOT create a fork on the user's behalf — ask first.\n\n### Keeping the fork up to date\n\nThe canonical remote that points at `paperclipai/paperclip` may be named `origin` **or** `upstream` depending on how the user set up the repo. Detect it the same way as in the "Detect a fork remote" step, then fetch and push from/with that remote so the sync works under either convention:\n\n```bash\nUPSTREAM_REMOTE=$(git remote -v | awk '/paperclipai\\/paperclip.*\\(fetch\\)/{print $1; exit}')\ngit fetch "$UPSTREAM_REMOTE"\ngit push <fork-remote> "${UPSTREAM_REMOTE}/master:master"\n```\n\n## Pull Requests\n\n> **MANDATORY PRE-FLIGHT:** Before creating ANY pull request, you MUST read the canonical source files listed below. Do NOT run `gh pr create` until you have read these files and verified your PR body matches every required section.\n\n### Step 1 — Read the canonical files\n\nYou MUST read all three of these files before creating a PR:\n\n1. **`.github/PULL_REQUEST_TEMPLATE.md`** — the required PR body structure\n2. **`CONTRIBUTING.md`** — contribution conventions, PR requirements, and thinking-path examples\n3. **`.github/workflows/pr.yml`** — CI checks that gate merge\n\n### Step 2 — Validate your PR body against this checklist\n\nAfter reading the template, verify your `--body` includes every one of these sections (names must match exactly):\n\n- [ ] `## Thinking Path` — blockquote style, 5-8 reasoning steps\n- [ ] `## What Changed` — bullet list of concrete changes\n- [ ] `## Verification` — how a reviewer confirms this works\n- [ ] `## Risks` — what could go wrong\n- [ ] `## Model Used` — provider, model ID, version, capabilities\n- [ ] `## Checklist` — copied from the template, items checked off\n\nIf any section is missing or empty, do NOT submit the PR. Go back and fill it in.\n\n### Step 3 — Create the PR\n\nOnly after completing Steps 1 and 2, run `gh pr create`. Use the template contents as the structure for `--body` — do not write a freeform summary.\n\n## Hard Rules — Do NOT Bypass\n\nThese rules exist because agents have caused real damage by improvising around CLI failures. Follow them exactly.\n\n1. **CLI is the only interface to worktrees and databases.** All worktree and database operations MUST go through `npx paperclipai` / `pnpm paperclipai` commands. You MUST NOT:\n   - Run `pg_dump`, `pg_restore`, `psql`, `createdb`, `dropdb`, or any raw postgres commands\n   - Manually set `DATABASE_URL` to point a worktree server at another instance's database\n   - Run `rm -rf` on any `.paperclip/`, `.paperclip-worktrees/`, or `db/` directory\n   - Directly manipulate embedded postgres data directories\n   - Kill postgres processes by PID\n\n2. **If a CLI command fails, stop and report.** Do NOT attempt workarounds. If `worktree:make`, `worktree reseed`, `worktree init`, `worktree:cleanup`, or any other `paperclipai` command fails:\n   - Report the exact error message in your task comment\n   - Set the task to `blocked`\n   - Suggest running `npx paperclipai doctor --repair` or recreating the worktree from scratch\n   - Do NOT try to manually replicate what the CLI does\n\n3. **Never share databases between instances.** Each worktree instance gets its own isolated database. Never override `DATABASE_URL` to point one instance at another's database. This destroys isolation and can corrupt production data.\n\n4. **Starting a dev server in a worktree requires setup first.** The correct sequence is:\n   ```bash\n   # If the worktree already exists but has no running instance:\n   cd <worktree-path>\n   eval "$(npx paperclipai worktree env)"\n   pnpm install && pnpm build\n   npx paperclipai run          # or pnpm dev\n\n   # If the worktree needs a fresh database:\n   npx paperclipai worktree reseed --seed-mode full\n\n   # If the worktree is broken beyond repair:\n   npx paperclipai worktree:cleanup <name>\n   npx paperclipai worktree:make <name> --seed-mode full\n   ```\n   If any step fails, follow rule 2 — stop and report.\n\n5. **Seeding is a CLI operation.** When asked to seed a worktree database from the main instance, use `worktree reseed` or recreate with `worktree:make --seed-mode full`. Read `doc/DEVELOPING.md` for the full option tables. Never attempt manual database copying.\n\n## Persistent Dev Servers (for Manual Testing)\n\nWhen an agent needs to start a dev server that outlives the current heartbeat — for example, so a human or QA agent can manually test against it — the server process **must** be launched in a detached session. A process started directly from a heartbeat shell is killed when the heartbeat exits.\n\n### Use `tmux` for persistent servers\n\n```bash\n# 1. cd into the worktree (or main repo) and source the environment\ncd <worktree-path>\neval "$(npx paperclipai worktree env)"   # skip if using the primary instance\n\n# 2. Start the dev server in a named, detached tmux session\ntmux new-session -d -s <session-name> 'pnpm dev'\n\n# Example with a descriptive name:\ntmux new-session -d -s auth-fix-3102 'pnpm dev'\n```\n\n### Managing the session\n\n| Task | Command |\n|------|---------|\n| Check if the session is alive | `tmux has-session -t <session-name> 2>/dev/null && echo running` |\n| View server output | `tmux capture-pane -t <session-name> -p` |\n| Kill the session | `tmux kill-session -t <session-name>` |\n| List all tmux sessions | `tmux list-sessions` |\n\n### Verifying the server is reachable\n\nAfter launching, confirm the port is listening before reporting success:\n\n```bash\n# Wait briefly for startup, then verify\nsleep 3\ncurl -sf http://127.0.0.1:<port>/api/health && echo "Server is up"\nlsof -nP -iTCP:<port> -sTCP:LISTEN\n```\n\n### Key rules\n\n1. **Always use `tmux` (or equivalent)** when a dev server needs to stay running after the heartbeat ends. A server started directly from the agent shell will die when the heartbeat exits, even if it appeared healthy moments before.\n2. **Name the session descriptively** — include the worktree name and port (e.g., `auth-fix-3102`).\n3. **Verify the server is listening** before reporting the URL to anyone.\n4. **Do not use `nohup` or `&` alone** — these are unreliable for agent shells that may have their entire process group killed.\n5. **Clean up when done** — kill the tmux session when the testing is complete.\n\n## Common Mistakes\n\n| Mistake | Fix |\n|---------|-----|\n| Server won't start | Run `npx paperclipai doctor --repair` to diagnose and auto-fix |\n| Forgetting to source worktree env | Run `eval "$(npx paperclipai worktree env)"` after cd-ing into the worktree |\n| Stale dependencies after pull | Run `pnpm install && pnpm build` after pulling |\n| Schema out of date after pull | Run `pnpm db:generate && pnpm db:migrate` |\n| Reseeding while target DB is running | Stop the target server first, or use `--allow-live-target` |\n| Cleaning up with unmerged commits | Merge or push first, or use `--force` if intentionally discarding |\n| Running agents against wrong instance | Verify `PAPERCLIP_API_URL` points to the correct port |\n| CLI command fails | Do NOT work around it — report the error and block (see Hard Rules above) |\n| Agent tries manual postgres operations | NEVER do this — all DB ops go through the CLI (see Hard Rules above) |\n| Dev server dies between heartbeats | Launch in a detached `tmux` session — see "Persistent Dev Servers" above |\n| Pushed feature branch to `paperclipai/paperclip` when a fork exists | Push to the user's fork remote instead — see "Forks" above |\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-dev	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-dev", "sourceKind": "paperclip_bundled"}	2026-05-22 13:59:29.316348+00	2026-05-25 01:43:29.982+00
d62d70b5-c003-4798-9bc2-8995ce8a4179	a24e39b2-2ede-4aec-9471-248458a381fc	paperclipai/paperclip/para-memory-files	para-memory-files	para-memory-files	>	---\nname: para-memory-files\ndescription: >\n  File-based memory system using Tiago Forte's PARA method. Use this skill whenever\n  you need to store, retrieve, update, or organize knowledge across sessions. Covers\n  three memory layers: (1) Knowledge graph in PARA folders with atomic YAML facts,\n  (2) Daily notes as raw timeline, (3) Tacit knowledge about user patterns. Also\n  handles planning files, memory decay, weekly synthesis, and recall via qmd.\n  Trigger on any memory operation: saving facts, writing daily notes, creating\n  entities, running weekly synthesis, recalling past context, or managing plans.\n---\n\n# PARA Memory Files\n\nPersistent, file-based memory organized by Tiago Forte's PARA method. Three layers: a knowledge graph, daily notes, and tacit knowledge. All paths are relative to `$AGENT_HOME`.\n\n## Three Memory Layers\n\n### Layer 1: Knowledge Graph (`$AGENT_HOME/life/` -- PARA)\n\nEntity-based storage. Each entity gets a folder with two tiers:\n\n1. `summary.md` -- quick context, load first.\n2. `items.yaml` -- atomic facts, load on demand.\n\n```text\n$AGENT_HOME/life/\n  projects/          # Active work with clear goals/deadlines\n    <name>/\n      summary.md\n      items.yaml\n  areas/             # Ongoing responsibilities, no end date\n    people/<name>/\n    companies/<name>/\n  resources/         # Reference material, topics of interest\n    <topic>/\n  archives/          # Inactive items from the other three\n  index.md\n```\n\n**PARA rules:**\n\n- **Projects** -- active work with a goal or deadline. Move to archives when complete.\n- **Areas** -- ongoing (people, companies, responsibilities). No end date.\n- **Resources** -- reference material, topics of interest.\n- **Archives** -- inactive items from any category.\n\n**Fact rules:**\n\n- Save durable facts immediately to `items.yaml`.\n- Weekly: rewrite `summary.md` from active facts.\n- Never delete facts. Supersede instead (`status: superseded`, add `superseded_by`).\n- When an entity goes inactive, move its folder to `$AGENT_HOME/life/archives/`.\n\n**When to create an entity:**\n\n- Mentioned 3+ times, OR\n- Direct relationship to the user (family, coworker, partner, client), OR\n- Significant project or company in the user's life.\n- Otherwise, note it in daily notes.\n\nFor the atomic fact YAML schema and memory decay rules, see [references/schemas.md](references/schemas.md).\n\n### Layer 2: Daily Notes (`$AGENT_HOME/memory/YYYY-MM-DD.md`)\n\nRaw timeline of events -- the "when" layer.\n\n- Write continuously during conversations.\n- Extract durable facts to Layer 1 during heartbeats.\n\n### Layer 3: Tacit Knowledge (`$AGENT_HOME/MEMORY.md`)\n\nHow the user operates -- patterns, preferences, lessons learned.\n\n- Not facts about the world; facts about the user.\n- Update whenever you learn new operating patterns.\n\n## Write It Down -- No Mental Notes\n\nMemory does not survive session restarts. Files do.\n\n- Want to remember something -> WRITE IT TO A FILE.\n- "Remember this" -> update `$AGENT_HOME/memory/YYYY-MM-DD.md` or the relevant entity file.\n- Learn a lesson -> update AGENTS.md, TOOLS.md, or the relevant skill file.\n- Make a mistake -> document it so future-you does not repeat it.\n- On-disk text files are always better than holding it in temporary context.\n\n## Memory Recall -- Use qmd\n\nUse `qmd` rather than grepping files:\n\n```bash\nqmd query "what happened at Christmas"   # Semantic search with reranking\nqmd search "specific phrase"              # BM25 keyword search\nqmd vsearch "conceptual question"         # Pure vector similarity\n```\n\nIndex your personal folder: `qmd index $AGENT_HOME`\n\nVectors + BM25 + reranking finds things even when the wording differs.\n\n## Planning\n\nKeep plans in timestamped files in `plans/` at the project root (outside personal memory so other agents can access them). Use `qmd` to search plans. Plans go stale -- if a newer plan exists, do not confuse yourself with an older version. If you notice staleness, update the file to note what it is supersededBy.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/para-memory-files	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/schemas.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/para-memory-files", "sourceKind": "paperclip_bundled"}	2026-05-22 13:59:29.321067+00	2026-05-25 01:43:29.988+00
2b0786c1-5032-4aca-a64e-bb46171f9075	a163ef00-71bb-4412-8943-c109f58a60a7	paperclipai/paperclip/paperclip-converting-plans-to-tasks	paperclip-converting-plans-to-tasks	paperclip-converting-plans-to-tasks	>	---\nname: paperclip-converting-plans-to-tasks\ndescription: >\n  The Paperclip way of converting a plan into executable tasks. Use whenever\n  you are asked to plan, scope, or break down work inside a Paperclip company.\n  Industry-agnostic guidance on how to translate a plan into assigned issues\n  with the right specialty, dependencies, and parallelization so Paperclip's\n  executor can pick up the work — it does not prescribe a plan format. Pair\n  with the `paperclip` skill, which covers the mechanics of writing the plan\n  document and reassigning the issue.\n---\n\n# Paperclip — Converting Plans to Tasks\n\nA companion skill for turning a plan into executable Paperclip work. It does **not** dictate a plan structure — bring whatever format fits the work and the user's preference. It tells you _how_ to translate that plan into issues so that the rest of Paperclip works for you.\n\nFor the **mechanics** of recording a plan (issue document with key `plan`, comment links, approval gating, who to reassign back to), follow the _Planning_ section of the `paperclip` skill. This skill covers planning method, not the API surface.\n\n## When you're asked to plan\n\n- **Plan deeply.** Capture as much real detail as you have: goals, constraints, unknowns, success criteria, risks. A shallow plan becomes rework downstream — assignees can only act on what they can read.\n- **Know your team.** Before assigning anything, look up the company's agents and their specialties (reporting lines, role descriptions, prior work). Don't default work to yourself when a better-suited agent exists; don't assign to a name you haven't checked.\n- **Assign for specialty.** Hand each piece of work to the agent most relevant to it. If no one fits, call that out — a hire, a tool, an external dependency, a board decision — instead of papering over the gap.\n- **Take responsibility.** Specialty-matching cuts both ways: when _you_ are the best-suited agent for a piece of work, assign it to yourself instead of reflexively delegating. Don't hand off to avoid load.\n- **Use the dependency tree.** Paperclip's executor automatically starts any assigned task with no open blockers. Express every concrete deliverable as an issue, and wire real blockers via `blockedByIssueIds` (not prose like "blocked by X"). When `done`, dependents auto-wake.\n- **Order, then parallelize.** Sequence work by real dependencies, not by personal preference. Independent branches of the graph should start in parallel. Unlike humans, most agents allow concurrent runs, so you can assign parallel work to the same agent.\n- **Enough is enough.** Plans exist to unblock execution, not replace it. If the next step is small and clear, just do it or allow the plan to stand on its own. Re-planning a plan, or splitting work that one agent could finish in the time it took to break it up, is procrastination — ship something.\n\n## Quick checklist before you publish a plan\n\n- [ ] Enough detail that assignees can act without re-asking.\n- [ ] Every concrete deliverable is an issue (or named as a known follow-up).\n- [ ] Each issue has a deliberate, specialty-matched assignee — not the planner by default.\n- [ ] Each issue's real blockers are declared via `blockedByIssueIds`.\n- [ ] Independent branches can start in parallel.\n- [ ] Gaps (missing skills, hires, decisions, external inputs) are surfaced, not hidden.\n\n## What this skill is not\n\n- Not a plan template. Use any format — prose, outline, table, RACI, Gantt, whatever fits.\n- Not software-development–specific. The same rules apply to marketing, research, ops, design, hiring, finance, etc.\n- Not a replacement for the `paperclip` skill's planning mechanics. Use both.\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-converting-plans-to-tasks	\N	markdown_only	compatible	[{"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-converting-plans-to-tasks", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:51.225293+00	2026-05-22 22:38:31.823+00
2f04a4f7-4977-4b7e-a417-bb6da0eaf5c0	0b96ba9b-87c5-4e69-89ca-188782d40d5f	paperclipai/paperclip/paperclip-create-agent	paperclip-create-agent	paperclip-create-agent	>	---\nname: paperclip-create-agent\ndescription: >\n  Create new agents in Paperclip with governance-aware hiring. Use when you need\n  to inspect adapter configuration options, compare existing agent configs,\n  draft a new agent prompt/config, and submit a hire request.\n---\n\n# Paperclip Create Agent Skill\n\nUse this skill when you are asked to hire/create an agent.\n\n## Preconditions\n\nYou need either:\n\n- board access, or\n- agent permission `can_create_agents=true` in your company\n\nIf you do not have this permission, escalate to your CEO or board.\n\n## Workflow\n\n### 1. Confirm identity and company context\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/agents/me" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 2. Discover adapter configuration for this Paperclip instance\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-configuration.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\n# Then the specific adapter you plan to use, e.g. claude_local:\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-configuration/claude_local.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 3. Compare existing agent configurations\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/companies/$PAPERCLIP_COMPANY_ID/agent-configurations" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\nNote naming, icon, reporting-line, and adapter conventions the company already follows.\n\n### 4. Choose the instruction source (required)\n\nThis is the single most important decision for hire quality. Pick exactly one path:\n\n- **Exact template** — the role matches an entry in the template index. Use the matching file under `references/agents/` as the starting point.\n- **Adjacent template** — no exact match, but an existing template is close (for example, a "Backend Engineer" hire adapted from `coder.md`, or a "Content Designer" adapted from `uxdesigner.md`). Copy the closest template and adapt deliberately: rename the role, rewrite the role charter, swap domain lenses, and remove sections that do not fit.\n- **Generic fallback** — no template is close. Use the baseline role guide to construct a new `AGENTS.md` from scratch, filling in each recommended section for the specific role.\n\nTemplate index and when-to-use guidance:\n`skills/paperclip-create-agent/references/agent-instruction-templates.md`\n\nGeneric fallback for no-template hires:\n`skills/paperclip-create-agent/references/baseline-role-guide.md`\n\nState which path you took in your hire-request comment so the board can see the reasoning.\n\n### 5. Discover allowed agent icons\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/llms/agent-icons.txt" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\n### 6. Draft the new hire config\n\n- role / title / name\n- icon (required in practice; pick from `/llms/agent-icons.txt`)\n- reporting line (`reportsTo`)\n- adapter type\n- `desiredSkills` from the company skill library when this role needs installed skills on day one\n- if any `desiredSkills` or adapter settings expand browser access, external-system reach, filesystem scope, or secret-handling capability, justify each one in the hire comment\n- adapter and runtime config aligned to this environment\n- leave timer heartbeats off by default; only set `runtimeConfig.heartbeat.enabled=true` with an `intervalSec` when the role genuinely needs scheduled recurring work or the user explicitly asked for it\n- if the role may handle private advisories or sensitive disclosures, confirm a confidential workflow exists first (dedicated skill or documented manual process)\n- capabilities\n- managed instructions bundle (`AGENTS.md`) for adapters that support it; avoid durable `promptTemplate` config\n- for coding or execution agents, include the Paperclip execution contract: start actionable work in the same heartbeat; do not stop at a plan unless planning was requested; leave durable progress with a clear next action; use child issues for long or parallel delegated work instead of polling; mark blocked work with owner/action; respect budget, pause/cancel, approval gates, and company boundaries\n- instruction text such as `AGENTS.md` built from step 4; for local managed-bundle adapters, send this as top-level `instructionsBundle.files["AGENTS.md"]`. Do not set `adapterConfig.promptTemplate` or `bootstrapPromptTemplate` for new agents.\n- source issue linkage (`sourceIssueId` or `sourceIssueIds`) when this hire came from an issue\n\n### 7. Review the draft against the quality checklist\n\nBefore submitting, walk the draft-review checklist end-to-end and fix any item that does not pass:\n`skills/paperclip-create-agent/references/draft-review-checklist.md`\n\n### 8. Submit hire request\n\n```sh\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/companies/$PAPERCLIP_COMPANY_ID/agent-hires" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "name": "CTO",\n    "role": "cto",\n    "title": "Chief Technology Officer",\n    "icon": "crown",\n    "reportsTo": "<ceo-agent-id>",\n    "capabilities": "Owns technical roadmap, architecture, staffing, execution",\n    "desiredSkills": ["vercel-labs/agent-browser/agent-browser"],\n    "adapterType": "codex_local",\n    "adapterConfig": {"cwd": "/abs/path/to/repo", "model": "o4-mini"},\n    "instructionsBundle": {"files": {"AGENTS.md": "You are the CTO..."}},\n    "runtimeConfig": {"heartbeat": {"enabled": false, "wakeOnDemand": true}},\n    "sourceIssueId": "<issue-id>"\n  }'\n```\n\n### 9. Handle governance state\n\n- if the response has `approval`, the hire is `pending_approval`\n- monitor and discuss on the approval thread\n- when the board approves, you will be woken with `PAPERCLIP_APPROVAL_ID`; read linked issues and close/comment follow-up\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/<approval-id>" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/approvals/<approval-id>/comments" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"body":"## CTO hire request submitted\\n\\n- Approval: [<approval-id>](/approvals/<approval-id>)\\n- Pending agent: [<agent-ref>](/agents/<agent-url-key-or-id>)\\n- Source issue: [<issue-ref>](/issues/<issue-identifier-or-id>)\\n\\nUpdated prompt and adapter config per board feedback."}'\n```\n\nIf the approval already exists and needs manual linking to the issue:\n\n```sh\ncurl -sS -X POST "$PAPERCLIP_API_URL/api/issues/<issue-id>/approvals" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"approvalId":"<approval-id>"}'\n```\n\nAfter approval is granted, run this follow-up loop:\n\n```sh\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/$PAPERCLIP_APPROVAL_ID" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n\ncurl -sS "$PAPERCLIP_API_URL/api/approvals/$PAPERCLIP_APPROVAL_ID/issues" \\\n  -H "Authorization: Bearer $PAPERCLIP_API_KEY"\n```\n\nFor each linked issue, either:\n- close it if the approval resolved the request, or\n- comment in markdown with links to the approval and next actions.\n\n## References\n\n- Template index and how to apply a template: `skills/paperclip-create-agent/references/agent-instruction-templates.md`\n- Individual role templates: `skills/paperclip-create-agent/references/agents/`\n- Generic baseline role guide (no-template fallback): `skills/paperclip-create-agent/references/baseline-role-guide.md`\n- Pre-submit draft-review checklist: `skills/paperclip-create-agent/references/draft-review-checklist.md`\n- Endpoint payload shapes and full examples: `skills/paperclip-create-agent/references/api-reference.md`\n	local_path	/opt/cortexos/paperclip/runtime/node_modules/@paperclipai/server/skills/paperclip-create-agent	\N	markdown_only	compatible	[{"kind": "reference", "path": "references/agent-instruction-templates.md"}, {"kind": "reference", "path": "references/agents/coder.md"}, {"kind": "reference", "path": "references/agents/qa.md"}, {"kind": "reference", "path": "references/agents/securityengineer.md"}, {"kind": "reference", "path": "references/agents/uxdesigner.md"}, {"kind": "reference", "path": "references/api-reference.md"}, {"kind": "reference", "path": "references/baseline-role-guide.md"}, {"kind": "reference", "path": "references/draft-review-checklist.md"}, {"kind": "skill", "path": "SKILL.md"}]	{"skillKey": "paperclipai/paperclip/paperclip-create-agent", "sourceKind": "paperclip_bundled"}	2026-05-22 05:29:50.503532+00	2026-05-22 22:33:56.718+00
\.


--
-- Data for Name: company_user_sidebar_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_user_sidebar_preferences (id, company_id, user_id, project_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_events (id, company_id, agent_id, issue_id, project_id, goal_id, billing_code, provider, model, input_tokens, output_tokens, cost_cents, occurred_at, created_at, heartbeat_run_id, biller, billing_type, cached_input_tokens) FROM stdin;
\.


--
-- Data for Name: document_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_revisions (id, company_id, document_id, revision_number, body, change_summary, created_by_agent_id, created_by_user_id, created_at, title, format, created_by_run_id) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, company_id, title, format, latest_body, latest_revision_id, latest_revision_number, created_by_agent_id, created_by_user_id, updated_by_agent_id, updated_by_user_id, created_at, updated_at, locked_at, locked_by_agent_id, locked_by_user_id) FROM stdin;
\.


--
-- Data for Name: environment_leases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.environment_leases (id, company_id, environment_id, execution_workspace_id, issue_id, heartbeat_run_id, status, lease_policy, provider, provider_lease_id, acquired_at, last_used_at, expires_at, released_at, failure_reason, cleanup_status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: environments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.environments (id, company_id, name, description, driver, status, config, metadata, created_at, updated_at) FROM stdin;
3e1ff549-6001-437f-9999-1cc392a717e4	0b96ba9b-87c5-4e69-89ca-188782d40d5f	Local	Default execution environment for Paperclip runs on this machine.	local	active	{}	{"defaultForCompany": true, "managedByPaperclip": true}	2026-05-22 05:29:50.428+00	2026-05-22 05:29:50.428+00
ef4b9c6a-3229-4149-9706-ecd6cda4f1ea	a163ef00-71bb-4412-8943-c109f58a60a7	Local	Default execution environment for Paperclip runs on this machine.	local	active	{}	{"defaultForCompany": true, "managedByPaperclip": true}	2026-05-22 05:29:51.195+00	2026-05-22 05:29:51.195+00
b2bf1bcb-3b2e-412c-ad9c-e1fea7a4a079	a24e39b2-2ede-4aec-9471-248458a381fc	Local	Default execution environment for Paperclip runs on this machine.	local	active	{}	{"defaultForCompany": true, "managedByPaperclip": true}	2026-05-22 13:59:29.279+00	2026-05-22 13:59:29.279+00
\.


--
-- Data for Name: execution_workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.execution_workspaces (id, company_id, project_id, project_workspace_id, source_issue_id, mode, strategy_type, name, status, cwd, repo_url, base_ref, branch_name, provider_type, provider_ref, derived_from_execution_workspace_id, last_used_at, opened_at, closed_at, cleanup_eligible_at, cleanup_reason, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feedback_exports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback_exports (id, company_id, feedback_vote_id, issue_id, project_id, author_user_id, target_type, target_id, vote, status, destination, export_id, consent_version, schema_version, bundle_version, payload_version, payload_digest, payload_snapshot, target_summary, redaction_summary, attempt_count, last_attempted_at, exported_at, failure_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feedback_votes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback_votes (id, company_id, issue_id, target_type, target_id, author_user_id, vote, reason, shared_with_labs, shared_at, consent_version, redaction_summary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: finance_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.finance_events (id, company_id, agent_id, issue_id, project_id, goal_id, heartbeat_run_id, cost_event_id, billing_code, description, event_kind, direction, biller, provider, execution_adapter_type, pricing_tier, region, model, quantity, unit, amount_cents, currency, estimated, external_invoice_id, metadata_json, occurred_at, created_at) FROM stdin;
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goals (id, company_id, title, description, level, status, parent_id, owner_agent_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: heartbeat_run_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heartbeat_run_events (id, company_id, run_id, agent_id, seq, event_type, stream, level, color, message, payload, created_at) FROM stdin;
\.


--
-- Data for Name: heartbeat_run_watchdog_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heartbeat_run_watchdog_decisions (id, company_id, run_id, evaluation_issue_id, decision, snoozed_until, reason, created_by_agent_id, created_by_user_id, created_by_run_id, created_at) FROM stdin;
\.


--
-- Data for Name: heartbeat_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heartbeat_runs (id, company_id, agent_id, invocation_source, status, started_at, finished_at, error, external_run_id, context_snapshot, created_at, updated_at, trigger_detail, wakeup_request_id, exit_code, signal, usage_json, result_json, session_id_before, session_id_after, log_store, log_ref, log_bytes, log_sha256, log_compressed, stdout_excerpt, stderr_excerpt, error_code, process_pid, process_started_at, retry_of_run_id, process_loss_retry_count, issue_comment_status, issue_comment_satisfied_by_comment_id, issue_comment_retry_queued_at, process_group_id, liveness_state, liveness_reason, continuation_attempt, last_useful_action_at, next_action, scheduled_retry_at, scheduled_retry_attempt, scheduled_retry_reason, last_output_at, last_output_seq, last_output_stream, last_output_bytes) FROM stdin;
\.


--
-- Data for Name: inbox_dismissals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inbox_dismissals (id, company_id, user_id, item_key, dismissed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: instance_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.instance_settings (id, singleton_key, experimental, created_at, updated_at, general) FROM stdin;
56dbe676-25c1-490c-b45b-d455ecc366bc	default	{}	2026-05-22 05:23:35.919+00	2026-05-22 05:23:35.919+00	{}
\.


--
-- Data for Name: instance_user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.instance_user_roles (id, user_id, role, created_at, updated_at) FROM stdin;
8954297c-0852-493a-b5fa-633dd2cd8040	local-board	instance_admin	2026-05-22 05:27:32.785182+00	2026-05-22 05:27:32.785182+00
6441842f-0951-41b0-a1de-fcd3065fee02	5ogQZrALdOL170oXtx4PfWowYHz1nwsU	instance_admin	2026-05-22 05:33:09.156915+00	2026-05-22 05:33:09.156915+00
\.


--
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invites (id, company_id, invite_type, token_hash, allowed_join_types, defaults_payload, expires_at, invited_by_user_id, revoked_at, accepted_at, created_at, updated_at) FROM stdin;
fe1e190c-7e2d-470b-bc70-0adfd1d5fffa	\N	bootstrap_ceo	0aab71a1881cf93d46c63c129df7b256d8463dc9279c777ccd5738f941691639	human	\N	2026-05-25 05:23:35.882+00	system	2026-05-22 05:24:40.332+00	\N	2026-05-22 05:23:35.883881+00	2026-05-22 05:24:40.332+00
0c0335b9-269f-4052-9edf-2e5bc5ab2fd2	\N	bootstrap_ceo	45b6e790aa0c99c3f8d8e3fbccbf3bb05416f6d9312300a2f805ac553f287b82	human	\N	2026-05-25 05:24:40.337+00	system	\N	\N	2026-05-22 05:24:40.338426+00	2026-05-22 05:24:40.338426+00
\.


--
-- Data for Name: issue_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_approvals (company_id, issue_id, approval_id, linked_by_agent_id, linked_by_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: issue_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_attachments (id, company_id, issue_id, asset_id, issue_comment_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_comments (id, company_id, issue_id, author_agent_id, author_user_id, body, created_at, updated_at, created_by_run_id, author_type, presentation, metadata) FROM stdin;
\.


--
-- Data for Name: issue_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_documents (id, company_id, issue_id, document_id, key, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_execution_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_execution_decisions (id, company_id, issue_id, stage_id, stage_type, actor_agent_id, actor_user_id, outcome, body, created_by_run_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_inbox_archives; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_inbox_archives (id, company_id, issue_id, user_id, archived_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_labels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_labels (issue_id, label_id, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: issue_read_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_read_states (id, company_id, issue_id, user_id, last_read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_recovery_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_recovery_actions (id, company_id, source_issue_id, recovery_issue_id, kind, status, owner_type, owner_agent_id, owner_user_id, previous_owner_agent_id, return_owner_agent_id, cause, fingerprint, evidence, next_action, wake_policy, monitor_policy, attempt_count, max_attempts, timeout_at, last_attempt_at, outcome, resolution_note, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_reference_mentions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_reference_mentions (id, company_id, source_issue_id, target_issue_id, source_kind, source_record_id, document_key, matched_text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_relations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_relations (id, company_id, issue_id, related_issue_id, type, created_by_agent_id, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_thread_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_thread_interactions (id, company_id, issue_id, kind, status, continuation_policy, source_comment_id, source_run_id, title, summary, created_by_agent_id, created_by_user_id, resolved_by_agent_id, resolved_by_user_id, payload, result, resolved_at, created_at, updated_at, idempotency_key) FROM stdin;
\.


--
-- Data for Name: issue_tree_hold_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_tree_hold_members (id, company_id, hold_id, issue_id, parent_issue_id, depth, issue_identifier, issue_title, issue_status, assignee_agent_id, assignee_user_id, active_run_id, active_run_status, skipped, skip_reason, created_at) FROM stdin;
\.


--
-- Data for Name: issue_tree_holds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_tree_holds (id, company_id, root_issue_id, mode, status, reason, release_policy, created_by_actor_type, created_by_agent_id, created_by_user_id, created_by_run_id, released_at, released_by_actor_type, released_by_agent_id, released_by_user_id, released_by_run_id, release_reason, release_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_work_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issue_work_products (id, company_id, project_id, issue_id, execution_workspace_id, runtime_service_id, type, provider, external_id, title, url, status, review_state, is_primary, health_status, summary, metadata, created_by_run_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.issues (id, company_id, project_id, goal_id, parent_id, title, description, status, priority, assignee_agent_id, created_by_agent_id, created_by_user_id, request_depth, billing_code, started_at, completed_at, cancelled_at, created_at, updated_at, issue_number, identifier, hidden_at, checkout_run_id, execution_run_id, execution_agent_name_key, execution_locked_at, assignee_user_id, assignee_adapter_overrides, execution_workspace_settings, project_workspace_id, execution_workspace_id, execution_workspace_preference, origin_kind, origin_id, origin_run_id, execution_policy, execution_state, origin_fingerprint, monitor_next_check_at, monitor_wake_requested_at, monitor_last_triggered_at, monitor_attempt_count, monitor_notes, monitor_scheduled_by, work_mode) FROM stdin;
\.


--
-- Data for Name: join_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.join_requests (id, invite_id, company_id, request_type, status, request_ip, requesting_user_id, request_email_snapshot, agent_name, adapter_type, capabilities, agent_defaults_payload, created_agent_id, approved_by_user_id, approved_at, rejected_by_user_id, rejected_at, created_at, updated_at, claim_secret_hash, claim_secret_expires_at, claim_secret_consumed_at) FROM stdin;
\.


--
-- Data for Name: labels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labels (id, company_id, name, color, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plugin_company_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_company_settings (id, company_id, plugin_id, settings_json, last_error, created_at, updated_at, enabled) FROM stdin;
\.


--
-- Data for Name: plugin_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_config (id, plugin_id, config_json, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plugin_database_namespaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_database_namespaces (id, plugin_id, plugin_key, namespace_name, namespace_mode, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plugin_entities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_entities (id, plugin_id, entity_type, scope_kind, scope_id, external_id, title, status, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plugin_job_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_job_runs (id, job_id, plugin_id, trigger, status, duration_ms, error, logs, started_at, finished_at, created_at) FROM stdin;
\.


--
-- Data for Name: plugin_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_jobs (id, plugin_id, job_key, schedule, status, last_run_at, next_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plugin_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_logs (id, plugin_id, level, message, meta, created_at) FROM stdin;
\.


--
-- Data for Name: plugin_managed_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_managed_resources (id, company_id, plugin_id, plugin_key, resource_kind, resource_key, resource_id, defaults_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plugin_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_migrations (id, plugin_id, plugin_key, namespace_name, migration_key, checksum, plugin_version, status, started_at, applied_at, error_message) FROM stdin;
\.


--
-- Data for Name: plugin_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_state (id, plugin_id, scope_kind, scope_id, namespace, state_key, value_json, updated_at) FROM stdin;
\.


--
-- Data for Name: plugin_webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugin_webhook_deliveries (id, plugin_id, webhook_key, external_id, status, duration_ms, error, payload, headers, started_at, finished_at, created_at) FROM stdin;
\.


--
-- Data for Name: plugins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plugins (id, plugin_key, package_name, package_path, version, api_version, categories, manifest_json, status, install_order, last_error, installed_at, updated_at) FROM stdin;
\.


--
-- Data for Name: principal_permission_grants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.principal_permission_grants (id, company_id, principal_type, principal_id, permission_key, scope, granted_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_goals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_goals (project_id, goal_id, company_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_workspaces (id, company_id, project_id, name, cwd, repo_url, repo_ref, metadata, is_primary, created_at, updated_at, source_type, default_ref, visibility, setup_command, cleanup_command, remote_provider, remote_workspace_ref, shared_workspace_key) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, company_id, goal_id, name, description, status, lead_agent_id, target_date, created_at, updated_at, color, archived_at, execution_workspace_policy, pause_reason, paused_at, env) FROM stdin;
\.


--
-- Data for Name: routine_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.routine_revisions (id, company_id, routine_id, revision_number, title, description, snapshot, change_summary, restored_from_revision_id, created_by_agent_id, created_by_user_id, created_by_run_id, created_at) FROM stdin;
\.


--
-- Data for Name: routine_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.routine_runs (id, company_id, routine_id, trigger_id, source, status, triggered_at, idempotency_key, trigger_payload, linked_issue_id, coalesced_into_run_id, failure_reason, completed_at, created_at, updated_at, dispatch_fingerprint) FROM stdin;
\.


--
-- Data for Name: routine_triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.routine_triggers (id, company_id, routine_id, kind, label, enabled, cron_expression, timezone, next_run_at, last_fired_at, public_id, secret_id, signing_mode, replay_window_sec, last_rotated_at, last_result, created_by_agent_id, created_by_user_id, updated_by_agent_id, updated_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: routines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.routines (id, company_id, project_id, goal_id, parent_issue_id, title, description, assignee_agent_id, priority, status, concurrency_policy, catch_up_policy, created_by_agent_id, created_by_user_id, updated_by_agent_id, updated_by_user_id, last_triggered_at, last_enqueued_at, created_at, updated_at, variables, latest_revision_id, latest_revision_number) FROM stdin;
\.


--
-- Data for Name: secret_access_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.secret_access_events (id, company_id, secret_id, version, provider, actor_type, actor_id, consumer_type, consumer_id, config_path, issue_id, heartbeat_run_id, plugin_id, outcome, error_code, created_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (id, expires_at, token, created_at, updated_at, ip_address, user_agent, user_id) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, email_verified, image, created_at, updated_at) FROM stdin;
local-board	Board	local@paperclip.local	t	\N	2026-05-22 05:27:32.765+00	2026-05-22 05:27:32.765+00
5ogQZrALdOL170oXtx4PfWowYHz1nwsU	CortexOS Admin	admin@cortexos.local	f	\N	2026-05-22 05:33:00.997+00	2026-05-22 05:33:00.997+00
uj1RoKPtCeCoaFTK3tAd9wo40wNGWTVR	Test	test@example.com	f	\N	2026-05-22 06:21:04.133+00	2026-05-22 06:21:04.133+00
QnbBbjjiyHU8arRsHwRlqgeCTa81b6AY	Test2	test2@example.com	f	\N	2026-05-22 06:21:04.349+00	2026-05-22 06:21:04.349+00
ZoKmgSjzpofOZAIZ14yowCr1jBg1nexd	Test3	test3@example.com	f	\N	2026-05-22 06:21:04.497+00	2026-05-22 06:21:04.497+00
js5Gky9lyiODja5qF5wWeTzI6RMnRrJU	Test4	test4@example.com	f	\N	2026-05-22 06:21:04.656+00	2026-05-22 06:21:04.656+00
T7ZAtzuszPwagJoN4AzKB5JO5kJYfpko	Node Araújo	node@paperclip.local	f	\N	2026-05-22 15:33:02.503+00	2026-05-22 15:33:02.503+00
FdBnonvHlAWoP4OhcSz7B5olcnRmy2L1	Saci Costa	saci.costa@paperclip.local	f	\N	2026-05-22 15:35:45.908+00	2026-05-22 15:35:45.908+00
f1hueRcBcnBNjUrzMW5EK3YJIqAW2t5b	Gradle Pinto	agent@paperclip.local	f	\N	2026-05-22 15:42:17.525+00	2026-05-22 15:42:17.525+00
QgbQMlbEdMviH6hm9cFuPrXU6CtvXwYx	Gradle Pinto	agent@paperclip.ai	f	\N	2026-05-22 15:51:48.019+00	2026-05-22 15:51:48.019+00
\.


--
-- Data for Name: user_sidebar_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sidebar_preferences (id, user_id, company_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: verification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification (id, identifier, value, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workspace_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspace_operations (id, company_id, execution_workspace_id, heartbeat_run_id, phase, command, cwd, status, exit_code, log_store, log_ref, log_bytes, log_sha256, log_compressed, stdout_excerpt, stderr_excerpt, metadata, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workspace_runtime_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspace_runtime_services (id, company_id, project_id, project_workspace_id, issue_id, scope_type, scope_id, service_name, status, lifecycle, reuse_key, command, cwd, port, url, provider, provider_ref, owner_agent_id, started_by_run_id, last_used_at, started_at, stopped_at, stop_policy, health_status, created_at, updated_at, execution_workspace_id) FROM stdin;
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 86, true);


--
-- Name: heartbeat_run_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.heartbeat_run_events_id_seq', 1, false);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: agent_api_keys agent_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_api_keys
    ADD CONSTRAINT agent_api_keys_pkey PRIMARY KEY (id);


--
-- Name: agent_config_revisions agent_config_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_config_revisions
    ADD CONSTRAINT agent_config_revisions_pkey PRIMARY KEY (id);


--
-- Name: agent_runtime_state agent_runtime_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_state
    ADD CONSTRAINT agent_runtime_state_pkey PRIMARY KEY (agent_id);


--
-- Name: agent_task_sessions agent_task_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_sessions
    ADD CONSTRAINT agent_task_sessions_pkey PRIMARY KEY (id);


--
-- Name: agent_wakeup_requests agent_wakeup_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_wakeup_requests
    ADD CONSTRAINT agent_wakeup_requests_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: approval_comments approval_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_pkey PRIMARY KEY (id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: board_api_keys board_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_api_keys
    ADD CONSTRAINT board_api_keys_pkey PRIMARY KEY (id);


--
-- Name: budget_incidents budget_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_incidents
    ADD CONSTRAINT budget_incidents_pkey PRIMARY KEY (id);


--
-- Name: budget_policies budget_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_policies
    ADD CONSTRAINT budget_policies_pkey PRIMARY KEY (id);


--
-- Name: cli_auth_challenges cli_auth_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cli_auth_challenges
    ADD CONSTRAINT cli_auth_challenges_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_logos company_logos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_logos
    ADD CONSTRAINT company_logos_pkey PRIMARY KEY (id);


--
-- Name: company_memberships company_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_pkey PRIMARY KEY (id);


--
-- Name: company_secret_bindings company_secret_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_bindings
    ADD CONSTRAINT company_secret_bindings_pkey PRIMARY KEY (id);


--
-- Name: company_secret_provider_configs company_secret_provider_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_provider_configs
    ADD CONSTRAINT company_secret_provider_configs_pkey PRIMARY KEY (id);


--
-- Name: company_secret_versions company_secret_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_versions
    ADD CONSTRAINT company_secret_versions_pkey PRIMARY KEY (id);


--
-- Name: company_secrets company_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secrets
    ADD CONSTRAINT company_secrets_pkey PRIMARY KEY (id);


--
-- Name: company_skills company_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_skills
    ADD CONSTRAINT company_skills_pkey PRIMARY KEY (id);


--
-- Name: company_user_sidebar_preferences company_user_sidebar_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_user_sidebar_preferences
    ADD CONSTRAINT company_user_sidebar_preferences_pkey PRIMARY KEY (id);


--
-- Name: cost_events cost_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_events
    ADD CONSTRAINT cost_events_pkey PRIMARY KEY (id);


--
-- Name: document_revisions document_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_revisions
    ADD CONSTRAINT document_revisions_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: environment_leases environment_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_leases
    ADD CONSTRAINT environment_leases_pkey PRIMARY KEY (id);


--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (id);


--
-- Name: execution_workspaces execution_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_workspaces
    ADD CONSTRAINT execution_workspaces_pkey PRIMARY KEY (id);


--
-- Name: feedback_exports feedback_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_exports
    ADD CONSTRAINT feedback_exports_pkey PRIMARY KEY (id);


--
-- Name: feedback_votes feedback_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_votes
    ADD CONSTRAINT feedback_votes_pkey PRIMARY KEY (id);


--
-- Name: finance_events finance_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_events
    ADD CONSTRAINT finance_events_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: heartbeat_run_events heartbeat_run_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_events
    ADD CONSTRAINT heartbeat_run_events_pkey PRIMARY KEY (id);


--
-- Name: heartbeat_run_watchdog_decisions heartbeat_run_watchdog_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_watchdog_decisions
    ADD CONSTRAINT heartbeat_run_watchdog_decisions_pkey PRIMARY KEY (id);


--
-- Name: heartbeat_runs heartbeat_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_runs
    ADD CONSTRAINT heartbeat_runs_pkey PRIMARY KEY (id);


--
-- Name: inbox_dismissals inbox_dismissals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbox_dismissals
    ADD CONSTRAINT inbox_dismissals_pkey PRIMARY KEY (id);


--
-- Name: instance_settings instance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instance_settings
    ADD CONSTRAINT instance_settings_pkey PRIMARY KEY (id);


--
-- Name: instance_user_roles instance_user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instance_user_roles
    ADD CONSTRAINT instance_user_roles_pkey PRIMARY KEY (id);


--
-- Name: invites invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (id);


--
-- Name: issue_approvals issue_approvals_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_approvals
    ADD CONSTRAINT issue_approvals_pk PRIMARY KEY (issue_id, approval_id);


--
-- Name: issue_attachments issue_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_attachments
    ADD CONSTRAINT issue_attachments_pkey PRIMARY KEY (id);


--
-- Name: issue_comments issue_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_comments
    ADD CONSTRAINT issue_comments_pkey PRIMARY KEY (id);


--
-- Name: issue_documents issue_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_documents
    ADD CONSTRAINT issue_documents_pkey PRIMARY KEY (id);


--
-- Name: issue_execution_decisions issue_execution_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_execution_decisions
    ADD CONSTRAINT issue_execution_decisions_pkey PRIMARY KEY (id);


--
-- Name: issue_inbox_archives issue_inbox_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_inbox_archives
    ADD CONSTRAINT issue_inbox_archives_pkey PRIMARY KEY (id);


--
-- Name: issue_labels issue_labels_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_labels
    ADD CONSTRAINT issue_labels_pk PRIMARY KEY (issue_id, label_id);


--
-- Name: issue_read_states issue_read_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_read_states
    ADD CONSTRAINT issue_read_states_pkey PRIMARY KEY (id);


--
-- Name: issue_recovery_actions issue_recovery_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_recovery_actions
    ADD CONSTRAINT issue_recovery_actions_pkey PRIMARY KEY (id);


--
-- Name: issue_reference_mentions issue_reference_mentions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_reference_mentions
    ADD CONSTRAINT issue_reference_mentions_pkey PRIMARY KEY (id);


--
-- Name: issue_relations issue_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_relations
    ADD CONSTRAINT issue_relations_pkey PRIMARY KEY (id);


--
-- Name: issue_thread_interactions issue_thread_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_thread_interactions
    ADD CONSTRAINT issue_thread_interactions_pkey PRIMARY KEY (id);


--
-- Name: issue_tree_hold_members issue_tree_hold_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_hold_members
    ADD CONSTRAINT issue_tree_hold_members_pkey PRIMARY KEY (id);


--
-- Name: issue_tree_holds issue_tree_holds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_holds
    ADD CONSTRAINT issue_tree_holds_pkey PRIMARY KEY (id);


--
-- Name: issue_work_products issue_work_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_work_products
    ADD CONSTRAINT issue_work_products_pkey PRIMARY KEY (id);


--
-- Name: issues issues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_pkey PRIMARY KEY (id);


--
-- Name: join_requests join_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_requests
    ADD CONSTRAINT join_requests_pkey PRIMARY KEY (id);


--
-- Name: labels labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_pkey PRIMARY KEY (id);


--
-- Name: plugin_company_settings plugin_company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_company_settings
    ADD CONSTRAINT plugin_company_settings_pkey PRIMARY KEY (id);


--
-- Name: plugin_config plugin_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_config
    ADD CONSTRAINT plugin_config_pkey PRIMARY KEY (id);


--
-- Name: plugin_database_namespaces plugin_database_namespaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_database_namespaces
    ADD CONSTRAINT plugin_database_namespaces_pkey PRIMARY KEY (id);


--
-- Name: plugin_entities plugin_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_entities
    ADD CONSTRAINT plugin_entities_pkey PRIMARY KEY (id);


--
-- Name: plugin_job_runs plugin_job_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_job_runs
    ADD CONSTRAINT plugin_job_runs_pkey PRIMARY KEY (id);


--
-- Name: plugin_jobs plugin_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_jobs
    ADD CONSTRAINT plugin_jobs_pkey PRIMARY KEY (id);


--
-- Name: plugin_logs plugin_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_logs
    ADD CONSTRAINT plugin_logs_pkey PRIMARY KEY (id);


--
-- Name: plugin_managed_resources plugin_managed_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_managed_resources
    ADD CONSTRAINT plugin_managed_resources_pkey PRIMARY KEY (id);


--
-- Name: plugin_migrations plugin_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_migrations
    ADD CONSTRAINT plugin_migrations_pkey PRIMARY KEY (id);


--
-- Name: plugin_state plugin_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_state
    ADD CONSTRAINT plugin_state_pkey PRIMARY KEY (id);


--
-- Name: plugin_state plugin_state_unique_entry_idx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_state
    ADD CONSTRAINT plugin_state_unique_entry_idx UNIQUE NULLS NOT DISTINCT (plugin_id, scope_kind, scope_id, namespace, state_key);


--
-- Name: plugin_webhook_deliveries plugin_webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_webhook_deliveries
    ADD CONSTRAINT plugin_webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (id);


--
-- Name: principal_permission_grants principal_permission_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.principal_permission_grants
    ADD CONSTRAINT principal_permission_grants_pkey PRIMARY KEY (id);


--
-- Name: project_goals project_goals_project_id_goal_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_goals
    ADD CONSTRAINT project_goals_project_id_goal_id_pk PRIMARY KEY (project_id, goal_id);


--
-- Name: project_workspaces project_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_workspaces
    ADD CONSTRAINT project_workspaces_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: routine_revisions routine_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_revisions
    ADD CONSTRAINT routine_revisions_pkey PRIMARY KEY (id);


--
-- Name: routine_runs routine_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_runs
    ADD CONSTRAINT routine_runs_pkey PRIMARY KEY (id);


--
-- Name: routine_triggers routine_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_triggers
    ADD CONSTRAINT routine_triggers_pkey PRIMARY KEY (id);


--
-- Name: routines routines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_pkey PRIMARY KEY (id);


--
-- Name: secret_access_events secret_access_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_access_events
    ADD CONSTRAINT secret_access_events_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_sidebar_preferences user_sidebar_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sidebar_preferences
    ADD CONSTRAINT user_sidebar_preferences_pkey PRIMARY KEY (id);


--
-- Name: verification verification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification
    ADD CONSTRAINT verification_pkey PRIMARY KEY (id);


--
-- Name: workspace_operations workspace_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_operations
    ADD CONSTRAINT workspace_operations_pkey PRIMARY KEY (id);


--
-- Name: workspace_runtime_services workspace_runtime_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_runtime_services
    ADD CONSTRAINT workspace_runtime_services_pkey PRIMARY KEY (id);


--
-- Name: activity_log_company_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_log_company_created_idx ON public.activity_log USING btree (company_id, created_at);


--
-- Name: activity_log_entity_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_log_entity_type_id_idx ON public.activity_log USING btree (entity_type, entity_id);


--
-- Name: activity_log_run_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_log_run_id_idx ON public.activity_log USING btree (run_id);


--
-- Name: agent_api_keys_company_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_api_keys_company_agent_idx ON public.agent_api_keys USING btree (company_id, agent_id);


--
-- Name: agent_api_keys_key_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_api_keys_key_hash_idx ON public.agent_api_keys USING btree (key_hash);


--
-- Name: agent_config_revisions_agent_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_config_revisions_agent_created_idx ON public.agent_config_revisions USING btree (agent_id, created_at);


--
-- Name: agent_config_revisions_company_agent_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_config_revisions_company_agent_created_idx ON public.agent_config_revisions USING btree (company_id, agent_id, created_at);


--
-- Name: agent_runtime_state_company_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_state_company_agent_idx ON public.agent_runtime_state USING btree (company_id, agent_id);


--
-- Name: agent_runtime_state_company_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_runtime_state_company_updated_idx ON public.agent_runtime_state USING btree (company_id, updated_at);


--
-- Name: agent_task_sessions_company_agent_adapter_task_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_task_sessions_company_agent_adapter_task_uniq ON public.agent_task_sessions USING btree (company_id, agent_id, adapter_type, task_key);


--
-- Name: agent_task_sessions_company_agent_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_task_sessions_company_agent_updated_idx ON public.agent_task_sessions USING btree (company_id, agent_id, updated_at);


--
-- Name: agent_task_sessions_company_task_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_task_sessions_company_task_updated_idx ON public.agent_task_sessions USING btree (company_id, task_key, updated_at);


--
-- Name: agent_wakeup_requests_agent_requested_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_wakeup_requests_agent_requested_idx ON public.agent_wakeup_requests USING btree (agent_id, requested_at);


--
-- Name: agent_wakeup_requests_company_agent_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_wakeup_requests_company_agent_status_idx ON public.agent_wakeup_requests USING btree (company_id, agent_id, status);


--
-- Name: agent_wakeup_requests_company_requested_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_wakeup_requests_company_requested_idx ON public.agent_wakeup_requests USING btree (company_id, requested_at);


--
-- Name: agents_company_default_environment_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agents_company_default_environment_idx ON public.agents USING btree (company_id, default_environment_id);


--
-- Name: agents_company_reports_to_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agents_company_reports_to_idx ON public.agents USING btree (company_id, reports_to);


--
-- Name: agents_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agents_company_status_idx ON public.agents USING btree (company_id, status);


--
-- Name: approval_comments_approval_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_comments_approval_created_idx ON public.approval_comments USING btree (approval_id, created_at);


--
-- Name: approval_comments_approval_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_comments_approval_idx ON public.approval_comments USING btree (approval_id);


--
-- Name: approval_comments_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_comments_company_idx ON public.approval_comments USING btree (company_id);


--
-- Name: approvals_company_status_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approvals_company_status_type_idx ON public.approvals USING btree (company_id, status, type);


--
-- Name: assets_company_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assets_company_created_idx ON public.assets USING btree (company_id, created_at);


--
-- Name: assets_company_object_key_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assets_company_object_key_uq ON public.assets USING btree (company_id, object_key);


--
-- Name: assets_company_provider_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assets_company_provider_idx ON public.assets USING btree (company_id, provider);


--
-- Name: board_api_keys_key_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX board_api_keys_key_hash_idx ON public.board_api_keys USING btree (key_hash);


--
-- Name: board_api_keys_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX board_api_keys_user_idx ON public.board_api_keys USING btree (user_id);


--
-- Name: budget_incidents_company_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_incidents_company_scope_idx ON public.budget_incidents USING btree (company_id, scope_type, scope_id, status);


--
-- Name: budget_incidents_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_incidents_company_status_idx ON public.budget_incidents USING btree (company_id, status);


--
-- Name: budget_incidents_policy_window_threshold_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX budget_incidents_policy_window_threshold_idx ON public.budget_incidents USING btree (policy_id, window_start, threshold_type) WHERE (status <> 'dismissed'::text);


--
-- Name: budget_policies_company_scope_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_policies_company_scope_active_idx ON public.budget_policies USING btree (company_id, scope_type, scope_id, is_active);


--
-- Name: budget_policies_company_scope_metric_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX budget_policies_company_scope_metric_unique_idx ON public.budget_policies USING btree (company_id, scope_type, scope_id, metric, window_kind);


--
-- Name: budget_policies_company_window_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_policies_company_window_idx ON public.budget_policies USING btree (company_id, window_kind, metric);


--
-- Name: cli_auth_challenges_approved_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cli_auth_challenges_approved_by_idx ON public.cli_auth_challenges USING btree (approved_by_user_id);


--
-- Name: cli_auth_challenges_requested_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cli_auth_challenges_requested_company_idx ON public.cli_auth_challenges USING btree (requested_company_id);


--
-- Name: cli_auth_challenges_secret_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cli_auth_challenges_secret_hash_idx ON public.cli_auth_challenges USING btree (secret_hash);


--
-- Name: companies_issue_prefix_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX companies_issue_prefix_idx ON public.companies USING btree (issue_prefix);


--
-- Name: company_logos_asset_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_logos_asset_uq ON public.company_logos USING btree (asset_id);


--
-- Name: company_logos_company_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_logos_company_uq ON public.company_logos USING btree (company_id);


--
-- Name: company_memberships_company_principal_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_memberships_company_principal_unique_idx ON public.company_memberships USING btree (company_id, principal_type, principal_id);


--
-- Name: company_memberships_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_memberships_company_status_idx ON public.company_memberships USING btree (company_id, status);


--
-- Name: company_memberships_principal_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_memberships_principal_status_idx ON public.company_memberships USING btree (principal_type, principal_id, status);


--
-- Name: company_secret_bindings_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secret_bindings_company_idx ON public.company_secret_bindings USING btree (company_id);


--
-- Name: company_secret_bindings_secret_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secret_bindings_secret_idx ON public.company_secret_bindings USING btree (secret_id);


--
-- Name: company_secret_bindings_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secret_bindings_target_idx ON public.company_secret_bindings USING btree (company_id, target_type, target_id);


--
-- Name: company_secret_bindings_target_path_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_secret_bindings_target_path_uq ON public.company_secret_bindings USING btree (company_id, target_type, target_id, config_path);


--
-- Name: company_secret_provider_configs_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secret_provider_configs_company_idx ON public.company_secret_provider_configs USING btree (company_id);


--
-- Name: company_secret_provider_configs_company_provider_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secret_provider_configs_company_provider_idx ON public.company_secret_provider_configs USING btree (company_id, provider);


--
-- Name: company_secret_provider_configs_default_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_secret_provider_configs_default_uq ON public.company_secret_provider_configs USING btree (company_id, provider) WHERE (is_default = true);


--
-- Name: company_secret_versions_fingerprint_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secret_versions_fingerprint_idx ON public.company_secret_versions USING btree (fingerprint_sha256);


--
-- Name: company_secret_versions_secret_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secret_versions_secret_idx ON public.company_secret_versions USING btree (secret_id, created_at);


--
-- Name: company_secret_versions_secret_version_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_secret_versions_secret_version_uq ON public.company_secret_versions USING btree (secret_id, version);


--
-- Name: company_secret_versions_value_sha256_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secret_versions_value_sha256_idx ON public.company_secret_versions USING btree (value_sha256);


--
-- Name: company_secrets_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secrets_company_idx ON public.company_secrets USING btree (company_id);


--
-- Name: company_secrets_company_key_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_secrets_company_key_uq ON public.company_secrets USING btree (company_id, key);


--
-- Name: company_secrets_company_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_secrets_company_name_uq ON public.company_secrets USING btree (company_id, name);


--
-- Name: company_secrets_company_provider_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secrets_company_provider_idx ON public.company_secrets USING btree (company_id, provider);


--
-- Name: company_secrets_provider_config_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_secrets_provider_config_idx ON public.company_secrets USING btree (provider_config_id);


--
-- Name: company_skills_company_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_skills_company_key_idx ON public.company_skills USING btree (company_id, key);


--
-- Name: company_skills_company_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_skills_company_name_idx ON public.company_skills USING btree (company_id, name);


--
-- Name: company_user_sidebar_preferences_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_user_sidebar_preferences_company_idx ON public.company_user_sidebar_preferences USING btree (company_id);


--
-- Name: company_user_sidebar_preferences_company_user_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_user_sidebar_preferences_company_user_uq ON public.company_user_sidebar_preferences USING btree (company_id, user_id);


--
-- Name: company_user_sidebar_preferences_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_user_sidebar_preferences_user_idx ON public.company_user_sidebar_preferences USING btree (user_id);


--
-- Name: cost_events_company_agent_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_events_company_agent_occurred_idx ON public.cost_events USING btree (company_id, agent_id, occurred_at);


--
-- Name: cost_events_company_biller_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_events_company_biller_occurred_idx ON public.cost_events USING btree (company_id, biller, occurred_at);


--
-- Name: cost_events_company_heartbeat_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_events_company_heartbeat_run_idx ON public.cost_events USING btree (company_id, heartbeat_run_id);


--
-- Name: cost_events_company_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_events_company_occurred_idx ON public.cost_events USING btree (company_id, occurred_at);


--
-- Name: cost_events_company_provider_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_events_company_provider_occurred_idx ON public.cost_events USING btree (company_id, provider, occurred_at);


--
-- Name: document_revisions_company_document_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_revisions_company_document_created_idx ON public.document_revisions USING btree (company_id, document_id, created_at);


--
-- Name: document_revisions_document_revision_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_revisions_document_revision_uq ON public.document_revisions USING btree (document_id, revision_number);


--
-- Name: documents_company_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_company_created_idx ON public.documents USING btree (company_id, created_at);


--
-- Name: documents_company_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_company_updated_idx ON public.documents USING btree (company_id, updated_at);


--
-- Name: documents_latest_body_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_latest_body_search_idx ON public.documents USING gin (latest_body public.gin_trgm_ops);


--
-- Name: documents_title_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_title_search_idx ON public.documents USING gin (title public.gin_trgm_ops);


--
-- Name: environment_leases_company_environment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_leases_company_environment_status_idx ON public.environment_leases USING btree (company_id, environment_id, status);


--
-- Name: environment_leases_company_execution_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_leases_company_execution_workspace_idx ON public.environment_leases USING btree (company_id, execution_workspace_id);


--
-- Name: environment_leases_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_leases_company_issue_idx ON public.environment_leases USING btree (company_id, issue_id);


--
-- Name: environment_leases_company_last_used_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_leases_company_last_used_idx ON public.environment_leases USING btree (company_id, last_used_at);


--
-- Name: environment_leases_heartbeat_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_leases_heartbeat_run_idx ON public.environment_leases USING btree (heartbeat_run_id);


--
-- Name: environment_leases_provider_lease_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environment_leases_provider_lease_idx ON public.environment_leases USING btree (provider_lease_id);


--
-- Name: environments_company_driver_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX environments_company_driver_idx ON public.environments USING btree (company_id, driver) WHERE (driver = 'local'::text);


--
-- Name: environments_company_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environments_company_name_idx ON public.environments USING btree (company_id, name);


--
-- Name: environments_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX environments_company_status_idx ON public.environments USING btree (company_id, status);


--
-- Name: execution_workspaces_company_branch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_workspaces_company_branch_idx ON public.execution_workspaces USING btree (company_id, branch_name);


--
-- Name: execution_workspaces_company_last_used_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_workspaces_company_last_used_idx ON public.execution_workspaces USING btree (company_id, last_used_at);


--
-- Name: execution_workspaces_company_project_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_workspaces_company_project_status_idx ON public.execution_workspaces USING btree (company_id, project_id, status);


--
-- Name: execution_workspaces_company_project_workspace_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_workspaces_company_project_workspace_status_idx ON public.execution_workspaces USING btree (company_id, project_workspace_id, status);


--
-- Name: execution_workspaces_company_source_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX execution_workspaces_company_source_issue_idx ON public.execution_workspaces USING btree (company_id, source_issue_id);


--
-- Name: feedback_exports_company_author_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_exports_company_author_idx ON public.feedback_exports USING btree (company_id, author_user_id, created_at);


--
-- Name: feedback_exports_company_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_exports_company_created_idx ON public.feedback_exports USING btree (company_id, created_at);


--
-- Name: feedback_exports_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_exports_company_issue_idx ON public.feedback_exports USING btree (company_id, issue_id, created_at);


--
-- Name: feedback_exports_company_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_exports_company_project_idx ON public.feedback_exports USING btree (company_id, project_id, created_at);


--
-- Name: feedback_exports_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_exports_company_status_idx ON public.feedback_exports USING btree (company_id, status, created_at);


--
-- Name: feedback_exports_feedback_vote_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX feedback_exports_feedback_vote_idx ON public.feedback_exports USING btree (feedback_vote_id);


--
-- Name: feedback_votes_author_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_votes_author_idx ON public.feedback_votes USING btree (author_user_id, created_at);


--
-- Name: feedback_votes_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_votes_company_issue_idx ON public.feedback_votes USING btree (company_id, issue_id);


--
-- Name: feedback_votes_company_target_author_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX feedback_votes_company_target_author_idx ON public.feedback_votes USING btree (company_id, target_type, target_id, author_user_id);


--
-- Name: feedback_votes_issue_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_votes_issue_target_idx ON public.feedback_votes USING btree (issue_id, target_type, target_id);


--
-- Name: finance_events_company_biller_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_events_company_biller_occurred_idx ON public.finance_events USING btree (company_id, biller, occurred_at);


--
-- Name: finance_events_company_cost_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_events_company_cost_event_idx ON public.finance_events USING btree (company_id, cost_event_id);


--
-- Name: finance_events_company_direction_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_events_company_direction_occurred_idx ON public.finance_events USING btree (company_id, direction, occurred_at);


--
-- Name: finance_events_company_heartbeat_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_events_company_heartbeat_run_idx ON public.finance_events USING btree (company_id, heartbeat_run_id);


--
-- Name: finance_events_company_kind_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_events_company_kind_occurred_idx ON public.finance_events USING btree (company_id, event_kind, occurred_at);


--
-- Name: finance_events_company_occurred_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX finance_events_company_occurred_idx ON public.finance_events USING btree (company_id, occurred_at);


--
-- Name: goals_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX goals_company_idx ON public.goals USING btree (company_id);


--
-- Name: heartbeat_run_events_company_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_run_events_company_created_idx ON public.heartbeat_run_events USING btree (company_id, created_at);


--
-- Name: heartbeat_run_events_company_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_run_events_company_run_idx ON public.heartbeat_run_events USING btree (company_id, run_id);


--
-- Name: heartbeat_run_events_run_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_run_events_run_seq_idx ON public.heartbeat_run_events USING btree (run_id, seq);


--
-- Name: heartbeat_run_watchdog_decisions_company_run_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_run_watchdog_decisions_company_run_created_idx ON public.heartbeat_run_watchdog_decisions USING btree (company_id, run_id, created_at);


--
-- Name: heartbeat_run_watchdog_decisions_company_run_snooze_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_run_watchdog_decisions_company_run_snooze_idx ON public.heartbeat_run_watchdog_decisions USING btree (company_id, run_id, snoozed_until);


--
-- Name: heartbeat_runs_company_agent_started_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_runs_company_agent_started_idx ON public.heartbeat_runs USING btree (company_id, agent_id, started_at);


--
-- Name: heartbeat_runs_company_liveness_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_runs_company_liveness_idx ON public.heartbeat_runs USING btree (company_id, liveness_state, created_at);


--
-- Name: heartbeat_runs_company_status_last_output_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_runs_company_status_last_output_idx ON public.heartbeat_runs USING btree (company_id, status, last_output_at);


--
-- Name: heartbeat_runs_company_status_process_started_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX heartbeat_runs_company_status_process_started_idx ON public.heartbeat_runs USING btree (company_id, status, process_started_at);


--
-- Name: inbox_dismissals_company_item_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inbox_dismissals_company_item_idx ON public.inbox_dismissals USING btree (company_id, item_key);


--
-- Name: inbox_dismissals_company_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inbox_dismissals_company_user_idx ON public.inbox_dismissals USING btree (company_id, user_id);


--
-- Name: inbox_dismissals_company_user_item_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inbox_dismissals_company_user_item_idx ON public.inbox_dismissals USING btree (company_id, user_id, item_key);


--
-- Name: instance_settings_singleton_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX instance_settings_singleton_key_idx ON public.instance_settings USING btree (singleton_key);


--
-- Name: instance_user_roles_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX instance_user_roles_role_idx ON public.instance_user_roles USING btree (role);


--
-- Name: instance_user_roles_user_role_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX instance_user_roles_user_role_unique_idx ON public.instance_user_roles USING btree (user_id, role);


--
-- Name: invites_company_invite_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invites_company_invite_state_idx ON public.invites USING btree (company_id, invite_type, revoked_at, expires_at);


--
-- Name: invites_token_hash_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX invites_token_hash_unique_idx ON public.invites USING btree (token_hash);


--
-- Name: issue_approvals_approval_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_approvals_approval_idx ON public.issue_approvals USING btree (approval_id);


--
-- Name: issue_approvals_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_approvals_company_idx ON public.issue_approvals USING btree (company_id);


--
-- Name: issue_approvals_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_approvals_issue_idx ON public.issue_approvals USING btree (issue_id);


--
-- Name: issue_attachments_asset_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_attachments_asset_uq ON public.issue_attachments USING btree (asset_id);


--
-- Name: issue_attachments_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_attachments_company_issue_idx ON public.issue_attachments USING btree (company_id, issue_id);


--
-- Name: issue_attachments_issue_comment_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_attachments_issue_comment_idx ON public.issue_attachments USING btree (issue_comment_id);


--
-- Name: issue_comments_body_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_comments_body_search_idx ON public.issue_comments USING gin (body public.gin_trgm_ops);


--
-- Name: issue_comments_company_author_issue_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_comments_company_author_issue_created_at_idx ON public.issue_comments USING btree (company_id, author_user_id, issue_id, created_at);


--
-- Name: issue_comments_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_comments_company_idx ON public.issue_comments USING btree (company_id);


--
-- Name: issue_comments_company_issue_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_comments_company_issue_created_at_idx ON public.issue_comments USING btree (company_id, issue_id, created_at);


--
-- Name: issue_comments_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_comments_issue_idx ON public.issue_comments USING btree (issue_id);


--
-- Name: issue_documents_company_issue_key_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_documents_company_issue_key_uq ON public.issue_documents USING btree (company_id, issue_id, key);


--
-- Name: issue_documents_company_issue_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_documents_company_issue_updated_idx ON public.issue_documents USING btree (company_id, issue_id, updated_at);


--
-- Name: issue_documents_document_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_documents_document_uq ON public.issue_documents USING btree (document_id);


--
-- Name: issue_execution_decisions_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_execution_decisions_company_issue_idx ON public.issue_execution_decisions USING btree (company_id, issue_id);


--
-- Name: issue_execution_decisions_stage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_execution_decisions_stage_idx ON public.issue_execution_decisions USING btree (issue_id, stage_id, created_at);


--
-- Name: issue_inbox_archives_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_inbox_archives_company_issue_idx ON public.issue_inbox_archives USING btree (company_id, issue_id);


--
-- Name: issue_inbox_archives_company_issue_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_inbox_archives_company_issue_user_idx ON public.issue_inbox_archives USING btree (company_id, issue_id, user_id);


--
-- Name: issue_inbox_archives_company_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_inbox_archives_company_user_idx ON public.issue_inbox_archives USING btree (company_id, user_id);


--
-- Name: issue_labels_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_labels_company_idx ON public.issue_labels USING btree (company_id);


--
-- Name: issue_labels_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_labels_issue_idx ON public.issue_labels USING btree (issue_id);


--
-- Name: issue_labels_label_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_labels_label_idx ON public.issue_labels USING btree (label_id);


--
-- Name: issue_read_states_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_read_states_company_issue_idx ON public.issue_read_states USING btree (company_id, issue_id);


--
-- Name: issue_read_states_company_issue_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_read_states_company_issue_user_idx ON public.issue_read_states USING btree (company_id, issue_id, user_id);


--
-- Name: issue_read_states_company_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_read_states_company_user_idx ON public.issue_read_states USING btree (company_id, user_id);


--
-- Name: issue_recovery_actions_active_fingerprint_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_recovery_actions_active_fingerprint_uq ON public.issue_recovery_actions USING btree (company_id, source_issue_id, cause, fingerprint) WHERE (status = ANY (ARRAY['active'::text, 'escalated'::text]));


--
-- Name: issue_recovery_actions_active_source_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_recovery_actions_active_source_uq ON public.issue_recovery_actions USING btree (company_id, source_issue_id) WHERE (status = ANY (ARRAY['active'::text, 'escalated'::text]));


--
-- Name: issue_recovery_actions_company_owner_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_recovery_actions_company_owner_status_idx ON public.issue_recovery_actions USING btree (company_id, owner_agent_id, status);


--
-- Name: issue_recovery_actions_company_recovery_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_recovery_actions_company_recovery_issue_idx ON public.issue_recovery_actions USING btree (company_id, recovery_issue_id);


--
-- Name: issue_recovery_actions_company_source_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_recovery_actions_company_source_status_idx ON public.issue_recovery_actions USING btree (company_id, source_issue_id, status);


--
-- Name: issue_reference_mentions_company_issue_pair_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_reference_mentions_company_issue_pair_idx ON public.issue_reference_mentions USING btree (company_id, source_issue_id, target_issue_id);


--
-- Name: issue_reference_mentions_company_source_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_reference_mentions_company_source_issue_idx ON public.issue_reference_mentions USING btree (company_id, source_issue_id);


--
-- Name: issue_reference_mentions_company_source_mention_null_record_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_reference_mentions_company_source_mention_null_record_uq ON public.issue_reference_mentions USING btree (company_id, source_issue_id, target_issue_id, source_kind) WHERE (source_record_id IS NULL);


--
-- Name: issue_reference_mentions_company_source_mention_record_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_reference_mentions_company_source_mention_record_uq ON public.issue_reference_mentions USING btree (company_id, source_issue_id, target_issue_id, source_kind, source_record_id) WHERE (source_record_id IS NOT NULL);


--
-- Name: issue_reference_mentions_company_target_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_reference_mentions_company_target_issue_idx ON public.issue_reference_mentions USING btree (company_id, target_issue_id);


--
-- Name: issue_relations_company_edge_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_relations_company_edge_uq ON public.issue_relations USING btree (company_id, issue_id, related_issue_id, type);


--
-- Name: issue_relations_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_relations_company_issue_idx ON public.issue_relations USING btree (company_id, issue_id);


--
-- Name: issue_relations_company_related_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_relations_company_related_issue_idx ON public.issue_relations USING btree (company_id, related_issue_id);


--
-- Name: issue_relations_company_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_relations_company_type_idx ON public.issue_relations USING btree (company_id, type);


--
-- Name: issue_thread_interactions_company_issue_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_thread_interactions_company_issue_created_at_idx ON public.issue_thread_interactions USING btree (company_id, issue_id, created_at);


--
-- Name: issue_thread_interactions_company_issue_idempotency_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_thread_interactions_company_issue_idempotency_uq ON public.issue_thread_interactions USING btree (company_id, issue_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: issue_thread_interactions_company_issue_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_thread_interactions_company_issue_status_idx ON public.issue_thread_interactions USING btree (company_id, issue_id, status);


--
-- Name: issue_thread_interactions_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_thread_interactions_issue_idx ON public.issue_thread_interactions USING btree (issue_id);


--
-- Name: issue_thread_interactions_source_comment_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_thread_interactions_source_comment_idx ON public.issue_thread_interactions USING btree (source_comment_id);


--
-- Name: issue_tree_hold_members_company_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_tree_hold_members_company_issue_idx ON public.issue_tree_hold_members USING btree (company_id, issue_id);


--
-- Name: issue_tree_hold_members_hold_depth_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_tree_hold_members_hold_depth_idx ON public.issue_tree_hold_members USING btree (hold_id, depth);


--
-- Name: issue_tree_hold_members_hold_issue_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issue_tree_hold_members_hold_issue_uq ON public.issue_tree_hold_members USING btree (hold_id, issue_id);


--
-- Name: issue_tree_holds_company_root_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_tree_holds_company_root_status_idx ON public.issue_tree_holds USING btree (company_id, root_issue_id, status);


--
-- Name: issue_tree_holds_company_status_mode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_tree_holds_company_status_mode_idx ON public.issue_tree_holds USING btree (company_id, status, mode);


--
-- Name: issue_work_products_company_execution_workspace_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_work_products_company_execution_workspace_type_idx ON public.issue_work_products USING btree (company_id, execution_workspace_id, type);


--
-- Name: issue_work_products_company_issue_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_work_products_company_issue_type_idx ON public.issue_work_products USING btree (company_id, issue_id, type);


--
-- Name: issue_work_products_company_provider_external_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_work_products_company_provider_external_id_idx ON public.issue_work_products USING btree (company_id, provider, external_id);


--
-- Name: issue_work_products_company_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_work_products_company_updated_idx ON public.issue_work_products USING btree (company_id, updated_at);


--
-- Name: issues_active_liveness_recovery_incident_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issues_active_liveness_recovery_incident_uq ON public.issues USING btree (company_id, origin_kind, origin_id) WHERE ((origin_kind = 'harness_liveness_escalation'::text) AND (origin_id IS NOT NULL) AND (hidden_at IS NULL) AND (status <> ALL (ARRAY['done'::text, 'cancelled'::text])));


--
-- Name: issues_active_liveness_recovery_leaf_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issues_active_liveness_recovery_leaf_uq ON public.issues USING btree (company_id, origin_kind, origin_fingerprint) WHERE ((origin_kind = 'harness_liveness_escalation'::text) AND (origin_fingerprint <> 'default'::text) AND (hidden_at IS NULL) AND (status <> ALL (ARRAY['done'::text, 'cancelled'::text])));


--
-- Name: issues_active_productivity_review_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issues_active_productivity_review_uq ON public.issues USING btree (company_id, origin_kind, origin_id) WHERE ((origin_kind = 'issue_productivity_review'::text) AND (origin_id IS NOT NULL) AND (hidden_at IS NULL) AND (status <> ALL (ARRAY['done'::text, 'cancelled'::text])));


--
-- Name: issues_active_stale_run_evaluation_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issues_active_stale_run_evaluation_uq ON public.issues USING btree (company_id, origin_kind, origin_id) WHERE ((origin_kind = 'stale_active_run_evaluation'::text) AND (origin_id IS NOT NULL) AND (hidden_at IS NULL) AND (status <> ALL (ARRAY['done'::text, 'cancelled'::text])));


--
-- Name: issues_active_stranded_issue_recovery_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issues_active_stranded_issue_recovery_uq ON public.issues USING btree (company_id, origin_kind, origin_id) WHERE ((origin_kind = 'stranded_issue_recovery'::text) AND (origin_id IS NOT NULL) AND (hidden_at IS NULL) AND (status <> ALL (ARRAY['done'::text, 'cancelled'::text])));


--
-- Name: issues_company_assignee_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_assignee_status_idx ON public.issues USING btree (company_id, assignee_agent_id, status);


--
-- Name: issues_company_assignee_user_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_assignee_user_status_idx ON public.issues USING btree (company_id, assignee_user_id, status);


--
-- Name: issues_company_execution_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_execution_workspace_idx ON public.issues USING btree (company_id, execution_workspace_id);


--
-- Name: issues_company_monitor_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_monitor_due_idx ON public.issues USING btree (company_id, monitor_next_check_at);


--
-- Name: issues_company_origin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_origin_idx ON public.issues USING btree (company_id, origin_kind, origin_id);


--
-- Name: issues_company_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_parent_idx ON public.issues USING btree (company_id, parent_id);


--
-- Name: issues_company_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_project_idx ON public.issues USING btree (company_id, project_id);


--
-- Name: issues_company_project_workspace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_project_workspace_idx ON public.issues USING btree (company_id, project_workspace_id);


--
-- Name: issues_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_company_status_idx ON public.issues USING btree (company_id, status);


--
-- Name: issues_description_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_description_search_idx ON public.issues USING gin (description public.gin_trgm_ops);


--
-- Name: issues_identifier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issues_identifier_idx ON public.issues USING btree (identifier);


--
-- Name: issues_identifier_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_identifier_search_idx ON public.issues USING gin (identifier public.gin_trgm_ops);


--
-- Name: issues_open_routine_execution_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX issues_open_routine_execution_uq ON public.issues USING btree (company_id, origin_kind, origin_id, origin_fingerprint) WHERE ((origin_kind = 'routine_execution'::text) AND (origin_id IS NOT NULL) AND (hidden_at IS NULL) AND (execution_run_id IS NOT NULL) AND (status = ANY (ARRAY['backlog'::text, 'todo'::text, 'in_progress'::text, 'in_review'::text, 'blocked'::text])));


--
-- Name: issues_title_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issues_title_search_idx ON public.issues USING gin (title public.gin_trgm_ops);


--
-- Name: join_requests_company_status_type_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX join_requests_company_status_type_created_idx ON public.join_requests USING btree (company_id, status, request_type, created_at);


--
-- Name: join_requests_invite_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX join_requests_invite_unique_idx ON public.join_requests USING btree (invite_id);


--
-- Name: join_requests_pending_human_email_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX join_requests_pending_human_email_uq ON public.join_requests USING btree (company_id, lower(request_email_snapshot)) WHERE ((request_type = 'human'::text) AND (status = 'pending_approval'::text) AND (request_email_snapshot IS NOT NULL));


--
-- Name: join_requests_pending_human_user_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX join_requests_pending_human_user_uq ON public.join_requests USING btree (company_id, requesting_user_id) WHERE ((request_type = 'human'::text) AND (status = 'pending_approval'::text) AND (requesting_user_id IS NOT NULL));


--
-- Name: labels_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labels_company_idx ON public.labels USING btree (company_id);


--
-- Name: labels_company_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX labels_company_name_idx ON public.labels USING btree (company_id, name);


--
-- Name: plugin_company_settings_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_company_settings_company_idx ON public.plugin_company_settings USING btree (company_id);


--
-- Name: plugin_company_settings_company_plugin_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugin_company_settings_company_plugin_uq ON public.plugin_company_settings USING btree (company_id, plugin_id);


--
-- Name: plugin_company_settings_plugin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_company_settings_plugin_idx ON public.plugin_company_settings USING btree (plugin_id);


--
-- Name: plugin_config_plugin_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugin_config_plugin_id_idx ON public.plugin_config USING btree (plugin_id);


--
-- Name: plugin_database_namespaces_namespace_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugin_database_namespaces_namespace_idx ON public.plugin_database_namespaces USING btree (namespace_name);


--
-- Name: plugin_database_namespaces_plugin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugin_database_namespaces_plugin_idx ON public.plugin_database_namespaces USING btree (plugin_id);


--
-- Name: plugin_database_namespaces_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_database_namespaces_status_idx ON public.plugin_database_namespaces USING btree (status);


--
-- Name: plugin_entities_external_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugin_entities_external_idx ON public.plugin_entities USING btree (plugin_id, entity_type, external_id);


--
-- Name: plugin_entities_plugin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_entities_plugin_idx ON public.plugin_entities USING btree (plugin_id);


--
-- Name: plugin_entities_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_entities_scope_idx ON public.plugin_entities USING btree (scope_kind, scope_id);


--
-- Name: plugin_entities_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_entities_type_idx ON public.plugin_entities USING btree (entity_type);


--
-- Name: plugin_job_runs_job_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_job_runs_job_idx ON public.plugin_job_runs USING btree (job_id);


--
-- Name: plugin_job_runs_plugin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_job_runs_plugin_idx ON public.plugin_job_runs USING btree (plugin_id);


--
-- Name: plugin_job_runs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_job_runs_status_idx ON public.plugin_job_runs USING btree (status);


--
-- Name: plugin_jobs_next_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_jobs_next_run_idx ON public.plugin_jobs USING btree (next_run_at);


--
-- Name: plugin_jobs_plugin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_jobs_plugin_idx ON public.plugin_jobs USING btree (plugin_id);


--
-- Name: plugin_jobs_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugin_jobs_unique_idx ON public.plugin_jobs USING btree (plugin_id, job_key);


--
-- Name: plugin_logs_level_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_logs_level_idx ON public.plugin_logs USING btree (level);


--
-- Name: plugin_logs_plugin_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_logs_plugin_time_idx ON public.plugin_logs USING btree (plugin_id, created_at);


--
-- Name: plugin_managed_resources_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_managed_resources_company_idx ON public.plugin_managed_resources USING btree (company_id);


--
-- Name: plugin_managed_resources_company_plugin_resource_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugin_managed_resources_company_plugin_resource_uq ON public.plugin_managed_resources USING btree (company_id, plugin_id, resource_kind, resource_key);


--
-- Name: plugin_managed_resources_plugin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_managed_resources_plugin_idx ON public.plugin_managed_resources USING btree (plugin_id);


--
-- Name: plugin_managed_resources_resource_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_managed_resources_resource_idx ON public.plugin_managed_resources USING btree (resource_kind, resource_id);


--
-- Name: plugin_migrations_plugin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_migrations_plugin_idx ON public.plugin_migrations USING btree (plugin_id);


--
-- Name: plugin_migrations_plugin_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugin_migrations_plugin_key_idx ON public.plugin_migrations USING btree (plugin_id, migration_key);


--
-- Name: plugin_migrations_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_migrations_status_idx ON public.plugin_migrations USING btree (status);


--
-- Name: plugin_state_plugin_scope_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_state_plugin_scope_idx ON public.plugin_state USING btree (plugin_id, scope_kind);


--
-- Name: plugin_webhook_deliveries_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_webhook_deliveries_key_idx ON public.plugin_webhook_deliveries USING btree (webhook_key);


--
-- Name: plugin_webhook_deliveries_plugin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_webhook_deliveries_plugin_idx ON public.plugin_webhook_deliveries USING btree (plugin_id);


--
-- Name: plugin_webhook_deliveries_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugin_webhook_deliveries_status_idx ON public.plugin_webhook_deliveries USING btree (status);


--
-- Name: plugins_plugin_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plugins_plugin_key_idx ON public.plugins USING btree (plugin_key);


--
-- Name: plugins_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX plugins_status_idx ON public.plugins USING btree (status);


--
-- Name: principal_permission_grants_company_permission_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX principal_permission_grants_company_permission_idx ON public.principal_permission_grants USING btree (company_id, permission_key);


--
-- Name: principal_permission_grants_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX principal_permission_grants_unique_idx ON public.principal_permission_grants USING btree (company_id, principal_type, principal_id, permission_key);


--
-- Name: project_goals_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_goals_company_idx ON public.project_goals USING btree (company_id);


--
-- Name: project_goals_goal_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_goals_goal_idx ON public.project_goals USING btree (goal_id);


--
-- Name: project_goals_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_goals_project_idx ON public.project_goals USING btree (project_id);


--
-- Name: project_workspaces_company_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_workspaces_company_project_idx ON public.project_workspaces USING btree (company_id, project_id);


--
-- Name: project_workspaces_company_shared_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_workspaces_company_shared_key_idx ON public.project_workspaces USING btree (company_id, shared_workspace_key);


--
-- Name: project_workspaces_project_primary_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_workspaces_project_primary_idx ON public.project_workspaces USING btree (project_id, is_primary);


--
-- Name: project_workspaces_project_remote_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_workspaces_project_remote_ref_idx ON public.project_workspaces USING btree (project_id, remote_provider, remote_workspace_ref);


--
-- Name: project_workspaces_project_source_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_workspaces_project_source_type_idx ON public.project_workspaces USING btree (project_id, source_type);


--
-- Name: projects_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_company_idx ON public.projects USING btree (company_id);


--
-- Name: routine_revisions_company_routine_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_revisions_company_routine_created_idx ON public.routine_revisions USING btree (company_id, routine_id, created_at);


--
-- Name: routine_revisions_routine_revision_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX routine_revisions_routine_revision_uq ON public.routine_revisions USING btree (routine_id, revision_number);


--
-- Name: routine_runs_company_routine_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_runs_company_routine_idx ON public.routine_runs USING btree (company_id, routine_id, created_at);


--
-- Name: routine_runs_dispatch_fingerprint_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_runs_dispatch_fingerprint_idx ON public.routine_runs USING btree (routine_id, dispatch_fingerprint);


--
-- Name: routine_runs_linked_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_runs_linked_issue_idx ON public.routine_runs USING btree (linked_issue_id);


--
-- Name: routine_runs_trigger_idempotency_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_runs_trigger_idempotency_idx ON public.routine_runs USING btree (trigger_id, idempotency_key);


--
-- Name: routine_runs_trigger_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_runs_trigger_idx ON public.routine_runs USING btree (trigger_id, created_at);


--
-- Name: routine_triggers_company_kind_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_triggers_company_kind_idx ON public.routine_triggers USING btree (company_id, kind);


--
-- Name: routine_triggers_company_routine_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_triggers_company_routine_idx ON public.routine_triggers USING btree (company_id, routine_id);


--
-- Name: routine_triggers_next_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_triggers_next_run_idx ON public.routine_triggers USING btree (next_run_at);


--
-- Name: routine_triggers_public_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routine_triggers_public_id_idx ON public.routine_triggers USING btree (public_id);


--
-- Name: routine_triggers_public_id_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX routine_triggers_public_id_uq ON public.routine_triggers USING btree (public_id);


--
-- Name: routines_company_assignee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routines_company_assignee_idx ON public.routines USING btree (company_id, assignee_agent_id);


--
-- Name: routines_company_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routines_company_project_idx ON public.routines USING btree (company_id, project_id);


--
-- Name: routines_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routines_company_status_idx ON public.routines USING btree (company_id, status);


--
-- Name: secret_access_events_company_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX secret_access_events_company_created_idx ON public.secret_access_events USING btree (company_id, created_at);


--
-- Name: secret_access_events_consumer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX secret_access_events_consumer_idx ON public.secret_access_events USING btree (company_id, consumer_type, consumer_id);


--
-- Name: secret_access_events_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX secret_access_events_run_idx ON public.secret_access_events USING btree (heartbeat_run_id);


--
-- Name: secret_access_events_secret_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX secret_access_events_secret_created_idx ON public.secret_access_events USING btree (secret_id, created_at);


--
-- Name: user_sidebar_preferences_user_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_sidebar_preferences_user_uq ON public.user_sidebar_preferences USING btree (user_id);


--
-- Name: workspace_operations_company_run_started_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_operations_company_run_started_idx ON public.workspace_operations USING btree (company_id, heartbeat_run_id, started_at);


--
-- Name: workspace_operations_company_workspace_started_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_operations_company_workspace_started_idx ON public.workspace_operations USING btree (company_id, execution_workspace_id, started_at);


--
-- Name: workspace_runtime_services_company_execution_workspace_status_i; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_runtime_services_company_execution_workspace_status_i ON public.workspace_runtime_services USING btree (company_id, execution_workspace_id, status);


--
-- Name: workspace_runtime_services_company_project_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_runtime_services_company_project_status_idx ON public.workspace_runtime_services USING btree (company_id, project_id, status);


--
-- Name: workspace_runtime_services_company_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_runtime_services_company_updated_idx ON public.workspace_runtime_services USING btree (company_id, updated_at);


--
-- Name: workspace_runtime_services_company_workspace_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_runtime_services_company_workspace_status_idx ON public.workspace_runtime_services USING btree (company_id, project_workspace_id, status);


--
-- Name: workspace_runtime_services_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_runtime_services_run_idx ON public.workspace_runtime_services USING btree (started_by_run_id);


--
-- Name: account account_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: activity_log activity_log_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: activity_log activity_log_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: activity_log activity_log_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_run_id_heartbeat_runs_id_fk FOREIGN KEY (run_id) REFERENCES public.heartbeat_runs(id);


--
-- Name: agent_api_keys agent_api_keys_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_api_keys
    ADD CONSTRAINT agent_api_keys_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_api_keys agent_api_keys_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_api_keys
    ADD CONSTRAINT agent_api_keys_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: agent_config_revisions agent_config_revisions_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_config_revisions
    ADD CONSTRAINT agent_config_revisions_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_config_revisions agent_config_revisions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_config_revisions
    ADD CONSTRAINT agent_config_revisions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: agent_config_revisions agent_config_revisions_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_config_revisions
    ADD CONSTRAINT agent_config_revisions_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_runtime_state agent_runtime_state_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_state
    ADD CONSTRAINT agent_runtime_state_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_runtime_state agent_runtime_state_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_runtime_state
    ADD CONSTRAINT agent_runtime_state_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: agent_task_sessions agent_task_sessions_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_sessions
    ADD CONSTRAINT agent_task_sessions_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_task_sessions agent_task_sessions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_sessions
    ADD CONSTRAINT agent_task_sessions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: agent_task_sessions agent_task_sessions_last_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_sessions
    ADD CONSTRAINT agent_task_sessions_last_run_id_heartbeat_runs_id_fk FOREIGN KEY (last_run_id) REFERENCES public.heartbeat_runs(id);


--
-- Name: agent_wakeup_requests agent_wakeup_requests_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_wakeup_requests
    ADD CONSTRAINT agent_wakeup_requests_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_wakeup_requests agent_wakeup_requests_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_wakeup_requests
    ADD CONSTRAINT agent_wakeup_requests_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: agents agents_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: agents agents_default_environment_id_environments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_default_environment_id_environments_id_fk FOREIGN KEY (default_environment_id) REFERENCES public.environments(id) ON DELETE SET NULL;


--
-- Name: agents agents_reports_to_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_reports_to_agents_id_fk FOREIGN KEY (reports_to) REFERENCES public.agents(id);


--
-- Name: approval_comments approval_comments_approval_id_approvals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_approval_id_approvals_id_fk FOREIGN KEY (approval_id) REFERENCES public.approvals(id);


--
-- Name: approval_comments approval_comments_author_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_author_agent_id_agents_id_fk FOREIGN KEY (author_agent_id) REFERENCES public.agents(id);


--
-- Name: approval_comments approval_comments_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: approvals approvals_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: approvals approvals_requested_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_requested_by_agent_id_agents_id_fk FOREIGN KEY (requested_by_agent_id) REFERENCES public.agents(id);


--
-- Name: assets assets_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: assets assets_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id);


--
-- Name: board_api_keys board_api_keys_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_api_keys
    ADD CONSTRAINT board_api_keys_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: budget_incidents budget_incidents_approval_id_approvals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_incidents
    ADD CONSTRAINT budget_incidents_approval_id_approvals_id_fk FOREIGN KEY (approval_id) REFERENCES public.approvals(id);


--
-- Name: budget_incidents budget_incidents_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_incidents
    ADD CONSTRAINT budget_incidents_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: budget_incidents budget_incidents_policy_id_budget_policies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_incidents
    ADD CONSTRAINT budget_incidents_policy_id_budget_policies_id_fk FOREIGN KEY (policy_id) REFERENCES public.budget_policies(id);


--
-- Name: budget_policies budget_policies_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_policies
    ADD CONSTRAINT budget_policies_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: cli_auth_challenges cli_auth_challenges_approved_by_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cli_auth_challenges
    ADD CONSTRAINT cli_auth_challenges_approved_by_user_id_user_id_fk FOREIGN KEY (approved_by_user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: cli_auth_challenges cli_auth_challenges_board_api_key_id_board_api_keys_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cli_auth_challenges
    ADD CONSTRAINT cli_auth_challenges_board_api_key_id_board_api_keys_id_fk FOREIGN KEY (board_api_key_id) REFERENCES public.board_api_keys(id) ON DELETE SET NULL;


--
-- Name: cli_auth_challenges cli_auth_challenges_requested_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cli_auth_challenges
    ADD CONSTRAINT cli_auth_challenges_requested_company_id_companies_id_fk FOREIGN KEY (requested_company_id) REFERENCES public.companies(id) ON DELETE SET NULL;


--
-- Name: company_logos company_logos_asset_id_assets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_logos
    ADD CONSTRAINT company_logos_asset_id_assets_id_fk FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: company_logos company_logos_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_logos
    ADD CONSTRAINT company_logos_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: company_memberships company_memberships_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_memberships
    ADD CONSTRAINT company_memberships_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_secret_bindings company_secret_bindings_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_bindings
    ADD CONSTRAINT company_secret_bindings_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_secret_bindings company_secret_bindings_secret_id_company_secrets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_bindings
    ADD CONSTRAINT company_secret_bindings_secret_id_company_secrets_id_fk FOREIGN KEY (secret_id) REFERENCES public.company_secrets(id) ON DELETE CASCADE;


--
-- Name: company_secret_provider_configs company_secret_provider_configs_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_provider_configs
    ADD CONSTRAINT company_secret_provider_configs_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: company_secret_provider_configs company_secret_provider_configs_created_by_agent_id_agents_id_f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_provider_configs
    ADD CONSTRAINT company_secret_provider_configs_created_by_agent_id_agents_id_f FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: company_secret_versions company_secret_versions_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_versions
    ADD CONSTRAINT company_secret_versions_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: company_secret_versions company_secret_versions_secret_id_company_secrets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secret_versions
    ADD CONSTRAINT company_secret_versions_secret_id_company_secrets_id_fk FOREIGN KEY (secret_id) REFERENCES public.company_secrets(id) ON DELETE CASCADE;


--
-- Name: company_secrets company_secrets_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secrets
    ADD CONSTRAINT company_secrets_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_secrets company_secrets_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secrets
    ADD CONSTRAINT company_secrets_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: company_secrets company_secrets_provider_config_id_company_secret_provider_conf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_secrets
    ADD CONSTRAINT company_secrets_provider_config_id_company_secret_provider_conf FOREIGN KEY (provider_config_id) REFERENCES public.company_secret_provider_configs(id) ON DELETE SET NULL;


--
-- Name: company_skills company_skills_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_skills
    ADD CONSTRAINT company_skills_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_user_sidebar_preferences company_user_sidebar_preferences_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_user_sidebar_preferences
    ADD CONSTRAINT company_user_sidebar_preferences_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: cost_events cost_events_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_events
    ADD CONSTRAINT cost_events_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: cost_events cost_events_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_events
    ADD CONSTRAINT cost_events_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: cost_events cost_events_goal_id_goals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_events
    ADD CONSTRAINT cost_events_goal_id_goals_id_fk FOREIGN KEY (goal_id) REFERENCES public.goals(id);


--
-- Name: cost_events cost_events_heartbeat_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_events
    ADD CONSTRAINT cost_events_heartbeat_run_id_heartbeat_runs_id_fk FOREIGN KEY (heartbeat_run_id) REFERENCES public.heartbeat_runs(id);


--
-- Name: cost_events cost_events_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_events
    ADD CONSTRAINT cost_events_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id);


--
-- Name: cost_events cost_events_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_events
    ADD CONSTRAINT cost_events_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: document_revisions document_revisions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_revisions
    ADD CONSTRAINT document_revisions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: document_revisions document_revisions_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_revisions
    ADD CONSTRAINT document_revisions_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: document_revisions document_revisions_created_by_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_revisions
    ADD CONSTRAINT document_revisions_created_by_run_id_heartbeat_runs_id_fk FOREIGN KEY (created_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: document_revisions document_revisions_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_revisions
    ADD CONSTRAINT document_revisions_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: documents documents_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: documents documents_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: documents documents_locked_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_locked_by_agent_id_agents_id_fk FOREIGN KEY (locked_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: documents documents_updated_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_updated_by_agent_id_agents_id_fk FOREIGN KEY (updated_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: environment_leases environment_leases_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_leases
    ADD CONSTRAINT environment_leases_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: environment_leases environment_leases_environment_id_environments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_leases
    ADD CONSTRAINT environment_leases_environment_id_environments_id_fk FOREIGN KEY (environment_id) REFERENCES public.environments(id) ON DELETE CASCADE;


--
-- Name: environment_leases environment_leases_execution_workspace_id_execution_workspaces_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_leases
    ADD CONSTRAINT environment_leases_execution_workspace_id_execution_workspaces_ FOREIGN KEY (execution_workspace_id) REFERENCES public.execution_workspaces(id) ON DELETE SET NULL;


--
-- Name: environment_leases environment_leases_heartbeat_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_leases
    ADD CONSTRAINT environment_leases_heartbeat_run_id_heartbeat_runs_id_fk FOREIGN KEY (heartbeat_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: environment_leases environment_leases_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environment_leases
    ADD CONSTRAINT environment_leases_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: environments environments_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: execution_workspaces execution_workspaces_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_workspaces
    ADD CONSTRAINT execution_workspaces_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: execution_workspaces execution_workspaces_derived_from_execution_workspace_id_execut; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_workspaces
    ADD CONSTRAINT execution_workspaces_derived_from_execution_workspace_id_execut FOREIGN KEY (derived_from_execution_workspace_id) REFERENCES public.execution_workspaces(id) ON DELETE SET NULL;


--
-- Name: execution_workspaces execution_workspaces_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_workspaces
    ADD CONSTRAINT execution_workspaces_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: execution_workspaces execution_workspaces_project_workspace_id_project_workspaces_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_workspaces
    ADD CONSTRAINT execution_workspaces_project_workspace_id_project_workspaces_id FOREIGN KEY (project_workspace_id) REFERENCES public.project_workspaces(id) ON DELETE SET NULL;


--
-- Name: execution_workspaces execution_workspaces_source_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_workspaces
    ADD CONSTRAINT execution_workspaces_source_issue_id_issues_id_fk FOREIGN KEY (source_issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: feedback_exports feedback_exports_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_exports
    ADD CONSTRAINT feedback_exports_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: feedback_exports feedback_exports_feedback_vote_id_feedback_votes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_exports
    ADD CONSTRAINT feedback_exports_feedback_vote_id_feedback_votes_id_fk FOREIGN KEY (feedback_vote_id) REFERENCES public.feedback_votes(id) ON DELETE CASCADE;


--
-- Name: feedback_exports feedback_exports_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_exports
    ADD CONSTRAINT feedback_exports_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: feedback_exports feedback_exports_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_exports
    ADD CONSTRAINT feedback_exports_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: feedback_votes feedback_votes_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_votes
    ADD CONSTRAINT feedback_votes_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: feedback_votes feedback_votes_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_votes
    ADD CONSTRAINT feedback_votes_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id);


--
-- Name: finance_events finance_events_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_events
    ADD CONSTRAINT finance_events_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: finance_events finance_events_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_events
    ADD CONSTRAINT finance_events_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: finance_events finance_events_cost_event_id_cost_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_events
    ADD CONSTRAINT finance_events_cost_event_id_cost_events_id_fk FOREIGN KEY (cost_event_id) REFERENCES public.cost_events(id);


--
-- Name: finance_events finance_events_goal_id_goals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_events
    ADD CONSTRAINT finance_events_goal_id_goals_id_fk FOREIGN KEY (goal_id) REFERENCES public.goals(id);


--
-- Name: finance_events finance_events_heartbeat_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_events
    ADD CONSTRAINT finance_events_heartbeat_run_id_heartbeat_runs_id_fk FOREIGN KEY (heartbeat_run_id) REFERENCES public.heartbeat_runs(id);


--
-- Name: finance_events finance_events_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_events
    ADD CONSTRAINT finance_events_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id);


--
-- Name: finance_events finance_events_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_events
    ADD CONSTRAINT finance_events_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: goals goals_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: goals goals_owner_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_owner_agent_id_agents_id_fk FOREIGN KEY (owner_agent_id) REFERENCES public.agents(id);


--
-- Name: goals goals_parent_id_goals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_parent_id_goals_id_fk FOREIGN KEY (parent_id) REFERENCES public.goals(id);


--
-- Name: heartbeat_run_events heartbeat_run_events_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_events
    ADD CONSTRAINT heartbeat_run_events_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: heartbeat_run_events heartbeat_run_events_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_events
    ADD CONSTRAINT heartbeat_run_events_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: heartbeat_run_events heartbeat_run_events_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_events
    ADD CONSTRAINT heartbeat_run_events_run_id_heartbeat_runs_id_fk FOREIGN KEY (run_id) REFERENCES public.heartbeat_runs(id);


--
-- Name: heartbeat_run_watchdog_decisions heartbeat_run_watchdog_decisions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_watchdog_decisions
    ADD CONSTRAINT heartbeat_run_watchdog_decisions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: heartbeat_run_watchdog_decisions heartbeat_run_watchdog_decisions_created_by_agent_id_agents_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_watchdog_decisions
    ADD CONSTRAINT heartbeat_run_watchdog_decisions_created_by_agent_id_agents_id_ FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: heartbeat_run_watchdog_decisions heartbeat_run_watchdog_decisions_created_by_run_id_heartbeat_ru; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_watchdog_decisions
    ADD CONSTRAINT heartbeat_run_watchdog_decisions_created_by_run_id_heartbeat_ru FOREIGN KEY (created_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: heartbeat_run_watchdog_decisions heartbeat_run_watchdog_decisions_evaluation_issue_id_issues_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_watchdog_decisions
    ADD CONSTRAINT heartbeat_run_watchdog_decisions_evaluation_issue_id_issues_id_ FOREIGN KEY (evaluation_issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: heartbeat_run_watchdog_decisions heartbeat_run_watchdog_decisions_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_run_watchdog_decisions
    ADD CONSTRAINT heartbeat_run_watchdog_decisions_run_id_heartbeat_runs_id_fk FOREIGN KEY (run_id) REFERENCES public.heartbeat_runs(id) ON DELETE CASCADE;


--
-- Name: heartbeat_runs heartbeat_runs_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_runs
    ADD CONSTRAINT heartbeat_runs_agent_id_agents_id_fk FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: heartbeat_runs heartbeat_runs_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_runs
    ADD CONSTRAINT heartbeat_runs_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: heartbeat_runs heartbeat_runs_retry_of_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_runs
    ADD CONSTRAINT heartbeat_runs_retry_of_run_id_heartbeat_runs_id_fk FOREIGN KEY (retry_of_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: heartbeat_runs heartbeat_runs_wakeup_request_id_agent_wakeup_requests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heartbeat_runs
    ADD CONSTRAINT heartbeat_runs_wakeup_request_id_agent_wakeup_requests_id_fk FOREIGN KEY (wakeup_request_id) REFERENCES public.agent_wakeup_requests(id);


--
-- Name: inbox_dismissals inbox_dismissals_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbox_dismissals
    ADD CONSTRAINT inbox_dismissals_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: invites invites_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_approvals issue_approvals_approval_id_approvals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_approvals
    ADD CONSTRAINT issue_approvals_approval_id_approvals_id_fk FOREIGN KEY (approval_id) REFERENCES public.approvals(id) ON DELETE CASCADE;


--
-- Name: issue_approvals issue_approvals_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_approvals
    ADD CONSTRAINT issue_approvals_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_approvals issue_approvals_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_approvals
    ADD CONSTRAINT issue_approvals_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_approvals issue_approvals_linked_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_approvals
    ADD CONSTRAINT issue_approvals_linked_by_agent_id_agents_id_fk FOREIGN KEY (linked_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: issue_attachments issue_attachments_asset_id_assets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_attachments
    ADD CONSTRAINT issue_attachments_asset_id_assets_id_fk FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: issue_attachments issue_attachments_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_attachments
    ADD CONSTRAINT issue_attachments_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_attachments issue_attachments_issue_comment_id_issue_comments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_attachments
    ADD CONSTRAINT issue_attachments_issue_comment_id_issue_comments_id_fk FOREIGN KEY (issue_comment_id) REFERENCES public.issue_comments(id) ON DELETE SET NULL;


--
-- Name: issue_attachments issue_attachments_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_attachments
    ADD CONSTRAINT issue_attachments_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_comments issue_comments_author_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_comments
    ADD CONSTRAINT issue_comments_author_agent_id_agents_id_fk FOREIGN KEY (author_agent_id) REFERENCES public.agents(id);


--
-- Name: issue_comments issue_comments_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_comments
    ADD CONSTRAINT issue_comments_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_comments issue_comments_created_by_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_comments
    ADD CONSTRAINT issue_comments_created_by_run_id_heartbeat_runs_id_fk FOREIGN KEY (created_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issue_comments issue_comments_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_comments
    ADD CONSTRAINT issue_comments_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id);


--
-- Name: issue_documents issue_documents_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_documents
    ADD CONSTRAINT issue_documents_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_documents issue_documents_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_documents
    ADD CONSTRAINT issue_documents_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: issue_documents issue_documents_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_documents
    ADD CONSTRAINT issue_documents_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_execution_decisions issue_execution_decisions_actor_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_execution_decisions
    ADD CONSTRAINT issue_execution_decisions_actor_agent_id_agents_id_fk FOREIGN KEY (actor_agent_id) REFERENCES public.agents(id);


--
-- Name: issue_execution_decisions issue_execution_decisions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_execution_decisions
    ADD CONSTRAINT issue_execution_decisions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_execution_decisions issue_execution_decisions_created_by_run_id_heartbeat_runs_id_f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_execution_decisions
    ADD CONSTRAINT issue_execution_decisions_created_by_run_id_heartbeat_runs_id_f FOREIGN KEY (created_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issue_execution_decisions issue_execution_decisions_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_execution_decisions
    ADD CONSTRAINT issue_execution_decisions_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_inbox_archives issue_inbox_archives_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_inbox_archives
    ADD CONSTRAINT issue_inbox_archives_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_inbox_archives issue_inbox_archives_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_inbox_archives
    ADD CONSTRAINT issue_inbox_archives_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id);


--
-- Name: issue_labels issue_labels_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_labels
    ADD CONSTRAINT issue_labels_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: issue_labels issue_labels_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_labels
    ADD CONSTRAINT issue_labels_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_labels issue_labels_label_id_labels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_labels
    ADD CONSTRAINT issue_labels_label_id_labels_id_fk FOREIGN KEY (label_id) REFERENCES public.labels(id) ON DELETE CASCADE;


--
-- Name: issue_read_states issue_read_states_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_read_states
    ADD CONSTRAINT issue_read_states_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_read_states issue_read_states_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_read_states
    ADD CONSTRAINT issue_read_states_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id);


--
-- Name: issue_recovery_actions issue_recovery_actions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_recovery_actions
    ADD CONSTRAINT issue_recovery_actions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_recovery_actions issue_recovery_actions_owner_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_recovery_actions
    ADD CONSTRAINT issue_recovery_actions_owner_agent_id_agents_id_fk FOREIGN KEY (owner_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: issue_recovery_actions issue_recovery_actions_previous_owner_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_recovery_actions
    ADD CONSTRAINT issue_recovery_actions_previous_owner_agent_id_agents_id_fk FOREIGN KEY (previous_owner_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: issue_recovery_actions issue_recovery_actions_recovery_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_recovery_actions
    ADD CONSTRAINT issue_recovery_actions_recovery_issue_id_issues_id_fk FOREIGN KEY (recovery_issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: issue_recovery_actions issue_recovery_actions_return_owner_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_recovery_actions
    ADD CONSTRAINT issue_recovery_actions_return_owner_agent_id_agents_id_fk FOREIGN KEY (return_owner_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: issue_recovery_actions issue_recovery_actions_source_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_recovery_actions
    ADD CONSTRAINT issue_recovery_actions_source_issue_id_issues_id_fk FOREIGN KEY (source_issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_reference_mentions issue_reference_mentions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_reference_mentions
    ADD CONSTRAINT issue_reference_mentions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_reference_mentions issue_reference_mentions_source_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_reference_mentions
    ADD CONSTRAINT issue_reference_mentions_source_issue_id_issues_id_fk FOREIGN KEY (source_issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_reference_mentions issue_reference_mentions_target_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_reference_mentions
    ADD CONSTRAINT issue_reference_mentions_target_issue_id_issues_id_fk FOREIGN KEY (target_issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_relations issue_relations_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_relations
    ADD CONSTRAINT issue_relations_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_relations issue_relations_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_relations
    ADD CONSTRAINT issue_relations_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: issue_relations issue_relations_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_relations
    ADD CONSTRAINT issue_relations_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_relations issue_relations_related_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_relations
    ADD CONSTRAINT issue_relations_related_issue_id_issues_id_fk FOREIGN KEY (related_issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_thread_interactions issue_thread_interactions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_thread_interactions
    ADD CONSTRAINT issue_thread_interactions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_thread_interactions issue_thread_interactions_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_thread_interactions
    ADD CONSTRAINT issue_thread_interactions_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id);


--
-- Name: issue_thread_interactions issue_thread_interactions_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_thread_interactions
    ADD CONSTRAINT issue_thread_interactions_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id);


--
-- Name: issue_thread_interactions issue_thread_interactions_resolved_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_thread_interactions
    ADD CONSTRAINT issue_thread_interactions_resolved_by_agent_id_agents_id_fk FOREIGN KEY (resolved_by_agent_id) REFERENCES public.agents(id);


--
-- Name: issue_thread_interactions issue_thread_interactions_source_comment_id_issue_comments_id_f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_thread_interactions
    ADD CONSTRAINT issue_thread_interactions_source_comment_id_issue_comments_id_f FOREIGN KEY (source_comment_id) REFERENCES public.issue_comments(id) ON DELETE SET NULL;


--
-- Name: issue_thread_interactions issue_thread_interactions_source_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_thread_interactions
    ADD CONSTRAINT issue_thread_interactions_source_run_id_heartbeat_runs_id_fk FOREIGN KEY (source_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issue_tree_hold_members issue_tree_hold_members_active_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_hold_members
    ADD CONSTRAINT issue_tree_hold_members_active_run_id_heartbeat_runs_id_fk FOREIGN KEY (active_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issue_tree_hold_members issue_tree_hold_members_assignee_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_hold_members
    ADD CONSTRAINT issue_tree_hold_members_assignee_agent_id_agents_id_fk FOREIGN KEY (assignee_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: issue_tree_hold_members issue_tree_hold_members_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_hold_members
    ADD CONSTRAINT issue_tree_hold_members_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_tree_hold_members issue_tree_hold_members_hold_id_issue_tree_holds_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_hold_members
    ADD CONSTRAINT issue_tree_hold_members_hold_id_issue_tree_holds_id_fk FOREIGN KEY (hold_id) REFERENCES public.issue_tree_holds(id) ON DELETE CASCADE;


--
-- Name: issue_tree_hold_members issue_tree_hold_members_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_hold_members
    ADD CONSTRAINT issue_tree_hold_members_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_tree_hold_members issue_tree_hold_members_parent_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_hold_members
    ADD CONSTRAINT issue_tree_hold_members_parent_issue_id_issues_id_fk FOREIGN KEY (parent_issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: issue_tree_holds issue_tree_holds_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_holds
    ADD CONSTRAINT issue_tree_holds_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_tree_holds issue_tree_holds_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_holds
    ADD CONSTRAINT issue_tree_holds_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: issue_tree_holds issue_tree_holds_created_by_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_holds
    ADD CONSTRAINT issue_tree_holds_created_by_run_id_heartbeat_runs_id_fk FOREIGN KEY (created_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issue_tree_holds issue_tree_holds_released_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_holds
    ADD CONSTRAINT issue_tree_holds_released_by_agent_id_agents_id_fk FOREIGN KEY (released_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: issue_tree_holds issue_tree_holds_released_by_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_holds
    ADD CONSTRAINT issue_tree_holds_released_by_run_id_heartbeat_runs_id_fk FOREIGN KEY (released_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issue_tree_holds issue_tree_holds_root_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tree_holds
    ADD CONSTRAINT issue_tree_holds_root_issue_id_issues_id_fk FOREIGN KEY (root_issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_work_products issue_work_products_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_work_products
    ADD CONSTRAINT issue_work_products_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issue_work_products issue_work_products_created_by_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_work_products
    ADD CONSTRAINT issue_work_products_created_by_run_id_heartbeat_runs_id_fk FOREIGN KEY (created_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issue_work_products issue_work_products_execution_workspace_id_execution_workspaces; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_work_products
    ADD CONSTRAINT issue_work_products_execution_workspace_id_execution_workspaces FOREIGN KEY (execution_workspace_id) REFERENCES public.execution_workspaces(id) ON DELETE SET NULL;


--
-- Name: issue_work_products issue_work_products_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_work_products
    ADD CONSTRAINT issue_work_products_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE CASCADE;


--
-- Name: issue_work_products issue_work_products_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_work_products
    ADD CONSTRAINT issue_work_products_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: issue_work_products issue_work_products_runtime_service_id_workspace_runtime_servic; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_work_products
    ADD CONSTRAINT issue_work_products_runtime_service_id_workspace_runtime_servic FOREIGN KEY (runtime_service_id) REFERENCES public.workspace_runtime_services(id) ON DELETE SET NULL;


--
-- Name: issues issues_assignee_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_assignee_agent_id_agents_id_fk FOREIGN KEY (assignee_agent_id) REFERENCES public.agents(id);


--
-- Name: issues issues_checkout_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_checkout_run_id_heartbeat_runs_id_fk FOREIGN KEY (checkout_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issues issues_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: issues issues_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id);


--
-- Name: issues issues_execution_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_execution_run_id_heartbeat_runs_id_fk FOREIGN KEY (execution_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: issues issues_execution_workspace_id_execution_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_execution_workspace_id_execution_workspaces_id_fk FOREIGN KEY (execution_workspace_id) REFERENCES public.execution_workspaces(id) ON DELETE SET NULL;


--
-- Name: issues issues_goal_id_goals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_goal_id_goals_id_fk FOREIGN KEY (goal_id) REFERENCES public.goals(id);


--
-- Name: issues issues_parent_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_parent_id_issues_id_fk FOREIGN KEY (parent_id) REFERENCES public.issues(id);


--
-- Name: issues issues_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: issues issues_project_workspace_id_project_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_project_workspace_id_project_workspaces_id_fk FOREIGN KEY (project_workspace_id) REFERENCES public.project_workspaces(id) ON DELETE SET NULL;


--
-- Name: join_requests join_requests_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_requests
    ADD CONSTRAINT join_requests_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: join_requests join_requests_created_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_requests
    ADD CONSTRAINT join_requests_created_agent_id_agents_id_fk FOREIGN KEY (created_agent_id) REFERENCES public.agents(id);


--
-- Name: join_requests join_requests_invite_id_invites_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.join_requests
    ADD CONSTRAINT join_requests_invite_id_invites_id_fk FOREIGN KEY (invite_id) REFERENCES public.invites(id);


--
-- Name: labels labels_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: plugin_company_settings plugin_company_settings_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_company_settings
    ADD CONSTRAINT plugin_company_settings_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: plugin_company_settings plugin_company_settings_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_company_settings
    ADD CONSTRAINT plugin_company_settings_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_config plugin_config_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_config
    ADD CONSTRAINT plugin_config_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_database_namespaces plugin_database_namespaces_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_database_namespaces
    ADD CONSTRAINT plugin_database_namespaces_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_entities plugin_entities_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_entities
    ADD CONSTRAINT plugin_entities_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_job_runs plugin_job_runs_job_id_plugin_jobs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_job_runs
    ADD CONSTRAINT plugin_job_runs_job_id_plugin_jobs_id_fk FOREIGN KEY (job_id) REFERENCES public.plugin_jobs(id) ON DELETE CASCADE;


--
-- Name: plugin_job_runs plugin_job_runs_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_job_runs
    ADD CONSTRAINT plugin_job_runs_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_jobs plugin_jobs_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_jobs
    ADD CONSTRAINT plugin_jobs_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_logs plugin_logs_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_logs
    ADD CONSTRAINT plugin_logs_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_managed_resources plugin_managed_resources_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_managed_resources
    ADD CONSTRAINT plugin_managed_resources_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: plugin_managed_resources plugin_managed_resources_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_managed_resources
    ADD CONSTRAINT plugin_managed_resources_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_migrations plugin_migrations_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_migrations
    ADD CONSTRAINT plugin_migrations_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_state plugin_state_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_state
    ADD CONSTRAINT plugin_state_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_webhook_deliveries plugin_webhook_deliveries_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugin_webhook_deliveries
    ADD CONSTRAINT plugin_webhook_deliveries_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: principal_permission_grants principal_permission_grants_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.principal_permission_grants
    ADD CONSTRAINT principal_permission_grants_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: project_goals project_goals_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_goals
    ADD CONSTRAINT project_goals_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: project_goals project_goals_goal_id_goals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_goals
    ADD CONSTRAINT project_goals_goal_id_goals_id_fk FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE CASCADE;


--
-- Name: project_goals project_goals_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_goals
    ADD CONSTRAINT project_goals_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_workspaces project_workspaces_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_workspaces
    ADD CONSTRAINT project_workspaces_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: project_workspaces project_workspaces_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_workspaces
    ADD CONSTRAINT project_workspaces_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: projects projects_goal_id_goals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_goal_id_goals_id_fk FOREIGN KEY (goal_id) REFERENCES public.goals(id);


--
-- Name: projects projects_lead_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_lead_agent_id_agents_id_fk FOREIGN KEY (lead_agent_id) REFERENCES public.agents(id);


--
-- Name: routine_revisions routine_revisions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_revisions
    ADD CONSTRAINT routine_revisions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: routine_revisions routine_revisions_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_revisions
    ADD CONSTRAINT routine_revisions_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: routine_revisions routine_revisions_created_by_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_revisions
    ADD CONSTRAINT routine_revisions_created_by_run_id_heartbeat_runs_id_fk FOREIGN KEY (created_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: routine_revisions routine_revisions_restored_from_revision_id_routine_revisions_i; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_revisions
    ADD CONSTRAINT routine_revisions_restored_from_revision_id_routine_revisions_i FOREIGN KEY (restored_from_revision_id) REFERENCES public.routine_revisions(id) ON DELETE SET NULL;


--
-- Name: routine_revisions routine_revisions_routine_id_routines_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_revisions
    ADD CONSTRAINT routine_revisions_routine_id_routines_id_fk FOREIGN KEY (routine_id) REFERENCES public.routines(id) ON DELETE CASCADE;


--
-- Name: routine_runs routine_runs_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_runs
    ADD CONSTRAINT routine_runs_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: routine_runs routine_runs_linked_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_runs
    ADD CONSTRAINT routine_runs_linked_issue_id_issues_id_fk FOREIGN KEY (linked_issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: routine_runs routine_runs_routine_id_routines_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_runs
    ADD CONSTRAINT routine_runs_routine_id_routines_id_fk FOREIGN KEY (routine_id) REFERENCES public.routines(id) ON DELETE CASCADE;


--
-- Name: routine_runs routine_runs_trigger_id_routine_triggers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_runs
    ADD CONSTRAINT routine_runs_trigger_id_routine_triggers_id_fk FOREIGN KEY (trigger_id) REFERENCES public.routine_triggers(id) ON DELETE SET NULL;


--
-- Name: routine_triggers routine_triggers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_triggers
    ADD CONSTRAINT routine_triggers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: routine_triggers routine_triggers_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_triggers
    ADD CONSTRAINT routine_triggers_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: routine_triggers routine_triggers_routine_id_routines_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_triggers
    ADD CONSTRAINT routine_triggers_routine_id_routines_id_fk FOREIGN KEY (routine_id) REFERENCES public.routines(id) ON DELETE CASCADE;


--
-- Name: routine_triggers routine_triggers_secret_id_company_secrets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_triggers
    ADD CONSTRAINT routine_triggers_secret_id_company_secrets_id_fk FOREIGN KEY (secret_id) REFERENCES public.company_secrets(id) ON DELETE SET NULL;


--
-- Name: routine_triggers routine_triggers_updated_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routine_triggers
    ADD CONSTRAINT routine_triggers_updated_by_agent_id_agents_id_fk FOREIGN KEY (updated_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: routines routines_assignee_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_assignee_agent_id_agents_id_fk FOREIGN KEY (assignee_agent_id) REFERENCES public.agents(id);


--
-- Name: routines routines_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: routines routines_created_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_created_by_agent_id_agents_id_fk FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: routines routines_goal_id_goals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_goal_id_goals_id_fk FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE SET NULL;


--
-- Name: routines routines_parent_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_parent_issue_id_issues_id_fk FOREIGN KEY (parent_issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: routines routines_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: routines routines_updated_by_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routines
    ADD CONSTRAINT routines_updated_by_agent_id_agents_id_fk FOREIGN KEY (updated_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: secret_access_events secret_access_events_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_access_events
    ADD CONSTRAINT secret_access_events_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: secret_access_events secret_access_events_heartbeat_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_access_events
    ADD CONSTRAINT secret_access_events_heartbeat_run_id_heartbeat_runs_id_fk FOREIGN KEY (heartbeat_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: secret_access_events secret_access_events_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_access_events
    ADD CONSTRAINT secret_access_events_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: secret_access_events secret_access_events_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_access_events
    ADD CONSTRAINT secret_access_events_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE SET NULL;


--
-- Name: secret_access_events secret_access_events_secret_id_company_secrets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secret_access_events
    ADD CONSTRAINT secret_access_events_secret_id_company_secrets_id_fk FOREIGN KEY (secret_id) REFERENCES public.company_secrets(id) ON DELETE CASCADE;


--
-- Name: session session_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: workspace_operations workspace_operations_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_operations
    ADD CONSTRAINT workspace_operations_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: workspace_operations workspace_operations_execution_workspace_id_execution_workspace; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_operations
    ADD CONSTRAINT workspace_operations_execution_workspace_id_execution_workspace FOREIGN KEY (execution_workspace_id) REFERENCES public.execution_workspaces(id) ON DELETE SET NULL;


--
-- Name: workspace_operations workspace_operations_heartbeat_run_id_heartbeat_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_operations
    ADD CONSTRAINT workspace_operations_heartbeat_run_id_heartbeat_runs_id_fk FOREIGN KEY (heartbeat_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- Name: workspace_runtime_services workspace_runtime_services_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_runtime_services
    ADD CONSTRAINT workspace_runtime_services_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: workspace_runtime_services workspace_runtime_services_execution_workspace_id_execution_wor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_runtime_services
    ADD CONSTRAINT workspace_runtime_services_execution_workspace_id_execution_wor FOREIGN KEY (execution_workspace_id) REFERENCES public.execution_workspaces(id) ON DELETE SET NULL;


--
-- Name: workspace_runtime_services workspace_runtime_services_issue_id_issues_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_runtime_services
    ADD CONSTRAINT workspace_runtime_services_issue_id_issues_id_fk FOREIGN KEY (issue_id) REFERENCES public.issues(id) ON DELETE SET NULL;


--
-- Name: workspace_runtime_services workspace_runtime_services_owner_agent_id_agents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_runtime_services
    ADD CONSTRAINT workspace_runtime_services_owner_agent_id_agents_id_fk FOREIGN KEY (owner_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: workspace_runtime_services workspace_runtime_services_project_id_projects_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_runtime_services
    ADD CONSTRAINT workspace_runtime_services_project_id_projects_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: workspace_runtime_services workspace_runtime_services_project_workspace_id_project_workspa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_runtime_services
    ADD CONSTRAINT workspace_runtime_services_project_workspace_id_project_workspa FOREIGN KEY (project_workspace_id) REFERENCES public.project_workspaces(id) ON DELETE SET NULL;


--
-- Name: workspace_runtime_services workspace_runtime_services_started_by_run_id_heartbeat_runs_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_runtime_services
    ADD CONSTRAINT workspace_runtime_services_started_by_run_id_heartbeat_runs_id_ FOREIGN KEY (started_by_run_id) REFERENCES public.heartbeat_runs(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict p9Jm9JWAwuXowgti1nl0RQKeK4ShgdOGgqkeODLEH5DCrKrv9mxhV5nZAMXkVoZ

